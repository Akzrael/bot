# Security audit notes — corbeau

I went through every source file (not just the ones below) plus the full
`node_modules` dependency tree. Everything else was normal bot code
(moderation commands, autorole, greet messages, snipe, 8ball, cowsay, etc.)
using legitimate npm packages. No stealer, grabber, or webhook-exfiltration
code was found anywhere in the project.

## What was removed / changed

1. **`src/Commands/Perm 6/eval.js` — deleted.**
   This command let anyone on the hardcoded owner list run arbitrary
   JavaScript on the host (`eval(args.join(" "))`) via a Discord message.
   That's a full remote-code-execution backdoor into whatever machine
   runs the bot. Removed entirely.

2. **`config.js` — hardcoded bot token and owner ID removed.**
   The original file shipped with a real bot token and a Discord user ID
   baked in as the sole "owner" — meaning that account (not you) had
   privileged access, including (originally) the eval backdoor above.
   `config.js` now reads `BOT_TOKEN` and `OWNER_IDS` from environment
   variables instead. See `.env.example`.

3. **`json.sqlite` — deleted.**
   Just an empty leftover local database (`quick.db` auto-creates it on
   first run), removed for a clean slate.

4. **`package.json` — dropped the `fs` npm package.**
   `fs` is a Node.js built-in; the npm package by that name does nothing
   useful and is just dead weight. Added `dotenv` since `config.js` now
   needs it.

## Before you run it

1. Copy `.env.example` to `.env`.
2. Put your own bot token (from https://discord.com/developers/applications)
   in `BOT_TOKEN`.
3. Put your own Discord user ID in `OWNER_IDS` (comma-separate if you want
   more than one owner).
4. `npm install`
5. `node index.js`

No other backdoors, credentials, or suspicious network calls were found
in the rest of the codebase.
