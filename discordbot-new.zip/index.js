const { Client, Collection, EmbedBuilder, Partials } = require("discord.js");
const { GiveawaysManager } = require("discord-giveaways");
const fs = require("fs");

const client = new Client({
  intents: 3276799,
  partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction]
});
const {QuickDB} = require("quick.db");
const db = new QuickDB();
module.exports = db;

// Stockage fs-based dédié au système modmail (indépendant de quick.db)
if (!fs.existsSync('./modmail-db.json'))
  fs.writeFileSync('./modmail-db.json', '{}', 'utf-8');
client.dbData = require('./modmail-db.json');
client.db = (guildId) => {
  if (!client.dbData[guildId]) client.dbData[guildId] = {};
  return client.dbData[guildId];
};
client.saveDB = () => fs.writeFileSync('./modmail-db.json', JSON.stringify(client.dbData, null, 4));

// Giveaways
client.giveawaysManager = new GiveawaysManager(client, { default: { botsCanWin: false, reaction: '🎉', lastChance: false } });

client.commands = new Collection();
client.config = require('./config').clients;
client.footer = "Zeralada BOT";
client.snipeMap = new Collection();
client.backups = new Map();

(async () => { 
  client.prefix = await db.get("prefix") || "+";
  client.color = await db.get("color") || "#0037ff"; 
  client.template = new EmbedBuilder().setColor(client.color);
})();

require('./src/Structure/Handler/Events')(client);
require('./src/Structure/Handler/Commands')(client);

client.login(client.config.token);

// The confession approve/reject buttons are handled by an Events file
// (src/Events/Confession/messageCreate.js), not a Commands file, so they
// can't be looked up via client.commands like the routes below — it's
// required directly instead.
const confessionHandler = require('./src/Events/Confession/messageCreate.js');

// Panel buttons posted as their own standalone message (outside the config
// command's own local collector) need routing here by customId prefix.
const BUTTON_ROUTES = [
    { prefix: "antiraid_", command: "antiraid" },
    { prefix: "rules_", command: "setrules" },
    { prefix: "raidmode_", command: "raidmode" },
];

client.on("interactionCreate", async interaction => {
    try {
        if (interaction.isButton()) {
            if (interaction.customId.startsWith("confess_")) {
                await confessionHandler.handleInteraction(client, interaction);
                return;
            }

            const route = BUTTON_ROUTES.find(r => interaction.customId.startsWith(r.prefix));
            if (route) {
                const cmd = client.commands.get(route.command);
                if (cmd && cmd.handleButton) {
                    await cmd.handleButton(client, interaction);
                }
            }
        }

        if (interaction.isModalSubmit()) {
            if (interaction.customId.startsWith("antiraid_")) {
                const cmd = client.commands.get("antiraid");
                if (cmd && cmd.handleModal) {
                    await cmd.handleModal(client, interaction);
                }
            }
        }

        if (interaction.isStringSelectMenu()) {
            if (interaction.customId.startsWith("antiraid_")) {
                const cmd = client.commands.get("antiraid");
                if (cmd && cmd.handleSelect) {
                    await cmd.handleSelect(client, interaction);
                }
            }
        }
    } catch (error) {
        console.error("[GLOBAL INTERACTION ROUTER ERROR]", error);
    }
});


process.on('unhandledRejection', (reason, promise) => {
  console.error(promise, reason);
});

process.on("uncaughtException", (err, origin) => {
  console.error(err, origin);
});

process.on('uncaughtExceptionMonitor', (err, origin) => {
  console.error(err, origin);
});
