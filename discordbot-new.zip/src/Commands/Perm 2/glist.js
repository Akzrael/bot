const { EmbedBuilder } = require("discord.js")

exports.help = {
    name: 'list',
    description: "Affiche la liste des giveaways actifs.",
    perms: 2,
}

exports.run = async (client, message, args) => {

    let description = "";

    const giveaways = client.giveawaysManager.giveaways.filter(g => g.guildId === message.guild.id && !g.ended);
    await Promise.all(giveaways.map(async (x, i) => {
        description += `${i + 1}・[\`${x.prize}\`](https://discord.com/channels/${x.guildId}/${x.channelId}/${x.messageId}) (<t:${((x.endAt) / 1000).toFixed(0)}:R>)\n`
    }));

    const embed = new EmbedBuilder()
        .setTitle('Liste des giveaways du serveur')
        .setColor(client.color)
        .setDescription(description == "" ? "Aucun giveaway" : description)

    message.channel.send({ embeds: [embed] })
}
