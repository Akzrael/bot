const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType } = require("discord.js");

exports.help = {
    name: "voicemove",
    description: "Déplace un membre vers un autre salon vocal.",
    aliases: ["vmove", "vm"],
    usage: "<@user> <#salon_vocal>",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const target = message.mentions.members.first();
    if (!target) {
        return message.channel.send("`❌` Membre introuvable.");
    }

    if (!target.voice.channel) {
        return message.channel.send("`❌` Ce membre n'est pas dans un salon vocal.");
    }

    const destination = message.mentions.channels.first();
    if (!destination || destination.type !== ChannelType.GuildVoice) {
        return message.channel.send("`❌` Veuillez mentionner un salon vocal valide.");
    }

    if (!destination.permissionsFor(message.guild.members.me).has(["MoveMembers", "Connect"])) {
        return message.channel.send("`❌` Je n'ai pas les permissions nécessaires dans le salon de destination.");
    }

    try {
        const oldChannel = target.voice.channel;
        await target.voice.setChannel(destination, `VoiceMove par ${message.author.tag}`);
        await message.channel.send(`✅ **${target.user.tag}** déplacé de **${oldChannel.name}** vers **${destination.name}**.`);
    } catch (error) {
        console.error("[VOICEMOVE ERROR]", error);
        await message.channel.send("`❌` Impossible de déplacer ce membre.");
    }
};