const db = require("../../../index.js")
const { sendModLog } = require("../../../src/Structure/ModLog.js")

function generateCaseId() {
    return `case_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function createCase(db, guildId, data) {
    if (!db.sanctions) db.sanctions = [];
    const caseData = { id: generateCaseId(), timestamp: Date.now(), ...data };
    db.sanctions.push(caseData);
    return caseData;
}

exports.help = {
    name: 'warn',
    description: "Ajoute un avertissement à un utilisateur.",
    usage: "<@user/id> <raison>",
    example: "@Sadek Propos déplacés",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const embed = client.template;

    let member;
    if (message.mentions.members.first()) {
        member = message.mentions.members.first();
    } else if (args[0]) {
        member = message.guild.members.cache.get(args[0])
            || await message.guild.members.fetch(args[0]).catch(() => null);
    }

    if (!member) {
        embed.data.description = "`❌` Je n'ai pas trouvé cet utilisateur.";
        return message.reply({ embeds: [embed] });
    }

    embed.data.description = "`❌` Vous ne pouvez pas vous avertir vous même.";
    if (member.id === message.author.id) return message.reply({ embeds: [embed] });

    const reason = args.slice(1).join(" ");
    if (!reason) {
        embed.data.description = "`❌` Vous devez indiquer une raison.";
        return message.reply({ embeds: [embed] });
    }

    const key = `warns_${message.guild.id}_${member.id}`;
    const warns = await db.get(key) || [];

    warns.push({
        reason,
        moderator: message.author.id,
        timestamp: Date.now(),
    });

    await db.set(key, warns);

    // Create case
    const sanction = createCase(db, message.guild.id, {
        type: "warn",
        userId: member.id,
        modId: message.author.id,
        reason,
        guildId: message.guild.id
    });

    embed.data.description = `\`✅\` **${member.user.tag}** a été averti avec succès. (Avertissement n°${warns.length} | Cas #${sanction.id})\n**Raison :** ${reason}`;
    message.reply({ embeds: [embed] });

    member.send({ content: `Vous avez reçu un avertissement sur **${message.guild.name}**.\n**Raison :** ${reason}` }).catch(() => {});

    sendModLog(client, message.guild, {
        title: "⚠️ Avertissement",
        color: 0xFAA61A,
        fields: [
            { name: "Utilisateur", value: `${member.user.tag} (\`${member.id}\`)`, inline: true },
            { name: "Modérateur", value: `${message.author.tag}`, inline: true },
            { name: "Total avertissements", value: `${warns.length}`, inline: true },
            { name: "Raison", value: reason },
            { name: "Cas", value: sanction.id, inline: true },
        ],
    });
};
