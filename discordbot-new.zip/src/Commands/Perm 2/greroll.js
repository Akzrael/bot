exports.help = {
    name: 'reroll',
    usage: "<id>",
    description: "Reroll un giveaway terminé.",
    perms: 2,
}

exports.run = async (client, message, args) => {

    if (!args[0]) return message.channel.send("Veuillez indiquer l'ID du giveaway à reroll");

    client.giveawaysManager.reroll(args[0], {
        messages: {
            congrat: `🎉 Bien joué {winners}! Après un reroll vous avez gagné **{this.prize}**!`,
            error: 'Il n\'y a pas assez de participants pour faire un reroll'
        }
    }).catch(() => message.channel.send(`Aucun giveaway trouvé avec l'ID \`${args[0] || "rien"}\``))
}
