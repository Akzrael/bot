exports.help = {
    name: 'pause',
    usage: "<id>",
    description: "Met en pause un giveaway.",
    perms: 2,
}

exports.run = async (client, message, args) => {

    if (!args[0]) return message.channel.send("Veuillez indiquer l'ID du giveaway à mettre en pause");

    client.giveawaysManager.pause(args[0], {
        infiniteDurationText: "JAMAIS"
    })
        .then(() => message.channel.send(`Le giveaway avec l'ID \`${args[0] ?? "rien"}\` a été mis en pause`))
        .catch(() => message.channel.send(`Aucun giveaway trouvé avec l'ID \`${args[0] || "rien"}\``))
}
