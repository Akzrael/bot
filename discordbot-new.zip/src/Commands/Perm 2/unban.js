const {
    EmbedBuilder
  } = require("discord.js")
  const { sendModLog } = require("../../../src/Structure/ModLog.js")

  exports.help = {
    name: 'unban',
    aliases: ['deban'],
    description: "Permet de unban un utilisateur.",
    usage: "<id/all> [raison]",
    example: "382936822860218370 Deuxième chance",
    perms: 2,
  }

  exports.run = async (client, message, args) => {
    const embed = client.template

    let banList = await message.guild.bans.fetch()
    if (banList.size == 0) {
      embed.data.description = "`❌` Aucune personne n'est bannie."
      return message.reply({
        embeds: [embed]
      })
    }

    if (args[0] == "all") {

        function unbanUsers(guild, banList) {
          console.log("Unbanning users...");
            return new Promise((resolve) => {
              const unbannedUsers = [];
              const stillBannedUsers = [];
              let count = 0;
              const total = banList.size;

              banList.forEach(user => {
                guild.members.unban(user.user.id, `Unban en masse par ${message.author.tag}`)
                  .then(() => {
                    unbannedUsers.push(user.user);
                  })
                  .catch(() => {
                    stillBannedUsers.push(user);
                  })
                  .finally(() => {
                    count++;
                    if (count === total) {
                      resolve([unbannedUsers, stillBannedUsers]);
                    }
                  });
              });
            });
          }

          let embedUnbanAll = new EmbedBuilder()
            .setColor(client.color)
            .setTimestamp()
            .setFooter({
              text: client.footer,
              iconURL: client.user.displayAvatarURL()
            })

          await unbanUsers(message.guild, banList)
            .then(([unbannedUsers]) => {

              embedUnbanAll.addFields({
                  name: "Membre(s) débannis",
                  value: unbannedUsers.length > 0 ? unbannedUsers.map(user => user.tag).join("\n") : "*Aucune personne n'a été débannie.*"
              });

              message.reply({ embeds: [embedUnbanAll] }).catch(error => { console.error("[UNBAN ALL] reply failed:", error) })

              sendModLog(client, message.guild, {
                  title: "🔓 Unban en masse",
                  color: 0x57F287,
                  fields: [
                      { name: "Modérateur", value: `${message.author.tag}`, inline: true },
                      { name: "Nombre débanni", value: `${unbannedUsers.length}`, inline: true }
                  ]
              });
            })
            .catch(error => {
              console.error("[UNBAN ALL ERROR]", error);
              embedUnbanAll.setDescription("`❌` Une erreur est survenue.");
              message.reply({ embeds: [embedUnbanAll] });
            });

    } else {

      let userToUnban;
      if (args[0]) {
        userToUnban = await client.users.fetch(args[0]).catch(err => {})
      }

      embed.data.description = "`❌` Je n'ai pas trouvé cet utilisateur."
      if (!userToUnban) return message.reply({
        embeds: [embed]
      })

      embed.data.description = "`❌` Cet utilisateur n'est pas dans la liste des bannis."
      if (!banList.find(ban => ban.user.id === userToUnban.id)) return message.reply({
        embeds: [embed]
      })

      const reason = args.slice(1).join(" ") || "Aucune raison fournie";

      message.guild.members.unban(userToUnban.id, `${reason} (par ${message.author.tag})`)
        .then(() => {
          embed.data.description = `\`✅\` **${userToUnban.tag}** a été débanni avec succès.\n**Raison :** ${reason}`
          message.reply({
            embeds: [embed]
          })

          sendModLog(client, message.guild, {
              title: "🔓 Membre débanni",
              color: 0x57F287,
              fields: [
                  { name: "Utilisateur", value: `${userToUnban.tag} (\`${userToUnban.id}\`)`, inline: true },
                  { name: "Modérateur", value: `${message.author.tag}`, inline: true },
                  { name: "Raison", value: reason }
              ]
          });
        })
        .catch((error) => {
          console.error("[UNBAN ERROR]", error)
          embed.data.description = "`❌` Je n'ai pas pu débannir cet utilisateur."
          message.reply({
            embeds: [embed]
          })
        })

    }
  }
