const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require("discord.js");

exports.help = {
    name: "slowmode",
    description: "Définit le mode lent sur un salon.",
    aliases: ["slow"],
    usage: "<#salon> <secondes>",
    example: "#général 30",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const channel = message.mentions.channels.first();
    if (!channel || channel.type !== ChannelType.GuildText) {
        return message.channel.send("`❌` Salon textuel invalide.");
    }

    const seconds = parseInt(args[1]);
    if (isNaN(seconds) || seconds < 0 || seconds > 21600) {
        return message.channel.send("`❌` Secondes invalides (0-21600, 0 pour désactiver).");
    }

    if (!channel.permissionsFor(message.guild.members.me).has(PermissionFlagsBits.ManageChannels)) {
        return message.channel.send("`❌` Je n'ai pas la permission de gérer ce salon.");
    }

    try {
        await channel.setRateLimitPerUser(seconds, `Slowmode par ${message.author.tag}`);
        const embed = new EmbedBuilder()
            .setTitle(seconds === 0 ? "🟢 Slowmode désactivé" : "🟡 Slowmode activé")
            .setColor(seconds === 0 ? 0x57F287 : 0xFAA61A)
            .addFields(
                { name: "Salon", value: channel.toString(), inline: true },
                { name: "Délai", value: seconds === 0 ? "Désactivé" : `${seconds}s`, inline: true },
                { name: "Par", value: message.author.toString(), inline: true }
            );
        await message.channel.send({ embeds: [embed] });
    } catch (error) {
        console.error("[SLOWMODE ERROR]", error);
        await message.channel.send("`❌` Impossible de modifier le slowmode.");
    }
};