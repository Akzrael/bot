exports.help = {
    name: 'unpause',
    usage: "<id>",
    description: "Reprend un giveaway en pause.",
    perms: 2,
}

exports.run = async (client, message, args) => {

    if (!args[0]) return message.channel.send("Veuillez indiquer l'ID du giveaway à reprendre");

    client.giveawaysManager.unpause(args[0])
        .then(() => message.channel.send(`Le giveaway avec l'ID \`${args[0] ?? "rien"}\` a été remis en marche`))
        .catch(() => message.channel.send(`Aucun giveaway en pause trouvé avec l'ID \`${args[0] || "rien"}\``))
}
