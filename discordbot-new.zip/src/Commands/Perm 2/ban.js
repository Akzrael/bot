const { EmbedBuilder } = require("discord.js")
const db = require("../../../index.js")
const { sendModLog } = require("../../../src/Structure/ModLog.js")

function generateCaseId() {
    return `case_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function createCase(db, guildId, data) {
    if (!db.sanctions) db.sanctions = [];
    const caseData = { id: generateCaseId(), timestamp: Date.now(), ...data };
    db.sanctions.push(caseData);
    return caseData;
}

exports.help = {
    name: 'ban',
    description: "Permet de ban un Utilisateur.",
    usage: "<user/id> [raison]",
    example: "@Sadek Spam / 513066398847729696 Raid",
    perms: 2,
}

exports.run = async (client, message, args) => {
    const embed = client.template

    const banList = await message.guild.bans.fetch()

    if (args[0] == "list") {
      let embedList = new EmbedBuilder()
        .setTimestamp()
        .setFooter({text: client.footer, iconURL: client.user.displayAvatarURL()})
        .setColor(client.color)
        .addFields({
          name: "Liste des membres bannis",
          value: (banList.size > 0 ? banList.map(user => user.user.tag + " (`" + user.user.id + "`)").join("\n") : "*Aucun membre n'est bannis*")
        })

      return message.reply({
        embeds: [embedList]
      });

    }

    embed.data.description = "`❌` Je n'ai pas trouvé d'utilisateur à bannir."

    let userToBan;
    if (message.mentions.users.first()) {
      userToBan = message.mentions.users.first()
    } else {
      userToBan = await client.users.fetch(args[0]).catch(err => {})
    }
    if(!userToBan) return message.reply({embeds: [embed]})

    embed.data.description = "`❌` Vous ne pouvez pas vous bannir vous même."
    if(userToBan.id === message.author.id) return message.reply({embeds: [embed]})

    embed.data.description = "`❌` Ce membre est déjà banni."
    if(banList.find(ban => ban.user.id === userToBan.id)) return message.reply({
      embeds: [embed]
    })

    // Hierarchy check only applies if the user is still in the guild
    const targetMember = message.guild.members.cache.get(userToBan.id);
    if (targetMember) {
        embed.data.description = "`❌` Vous ne pouvez ban que les membres hiérarchiquement inferieurs à vous."
        if (message.member.roles.highest.position <= targetMember.roles.highest.position) return message.reply({embeds: [embed]})

        embed.data.description = "`❌` Je n'ai pas les permissions nécessaires pour bannir ce membre (rôle trop haut)."
        if (!targetMember.bannable) return message.reply({embeds: [embed]})
    }

    const reason = args.slice(1).join(" ") || "Aucune raison fournie";

    message.guild.members.ban(userToBan, {reason: `${reason} (par ${message.author.tag})`})
        .then(() => {
        // Create case
        const sanction = createCase(client.db(message.guild.id), message.guild.id, {
            type: "ban",
            userId: userToBan.id,
            modId: message.author.id,
            reason,
            guildId: message.guild.id
        });

        embed.data.description = `\`✅\` **${userToBan.tag}** a bien été banni avec succès.\n**Raison :** ${reason}\n**Cas :** #${sanction.id}`
        message.reply({embeds: [embed]})

        sendModLog(client, message.guild, {
            title: "🔨 Membre banni",
            color: 0xED4245,
            fields: [
                { name: "Utilisateur", value: `${userToBan.tag} (\`${userToBan.id}\`)`, inline: true },
                { name: "Modérateur", value: `${message.author.tag}`, inline: true },
                { name: "Raison", value: reason },
                { name: "Cas", value: sanction.id, inline: true }
            ]
        });
    })
        .catch(err => {
        console.error("[BAN ERROR]", err);
        embed.data.description = "`❌` Je ne peux pas bannir ce membre (utilisateur introuvable ou permissions insuffisantes)."
        return message.reply({embeds: [embed]})
    })
}
