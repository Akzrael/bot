const { sendModLog } = require("../../../src/Structure/ModLog.js")

exports.help = {
    name: "unmute",
    aliases: ["unto", "untimeout"],
    description: "Permet de unmute un utilisateur.",
    usage: "<@user> [raison]",
    example: "@Sadek",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const embed = client.template
    embed.data.description = "`❌` Je n'ai pas trouvé d'utilisateur à unmute."

    let member;
    if (message.mentions.members.first()) {
        member = message.mentions.members.first();
    } else {
        member = message.guild.members.cache.get(args[0])
            || await message.guild.members.fetch(args[0]).catch(() => null);
    }

    if(!member) return message.reply({embeds: [embed]})

    embed.data.description = "`❌` Ce membre n'est pas mute actuellement."
    if(!member.communicationDisabledUntilTimestamp || member.communicationDisabledUntilTimestamp < Date.now()) return message.reply({embeds: [embed]})

    const reason = args.slice(1).join(" ") || "Aucune raison fournie";

    member.timeout(null, `${reason} (par ${message.author.tag})`).then(() => {
        embed.data.description = "`✅` Membre unmute avec succès."
        message.reply({embeds: [embed]})

        sendModLog(client, message.guild, {
            title: "🔊 Membre unmute",
            color: 0x57F287,
            fields: [
                { name: "Utilisateur", value: `${member.user.tag} (\`${member.id}\`)`, inline: true },
                { name: "Modérateur", value: `${message.author.tag}`, inline: true },
                { name: "Raison", value: reason }
            ]
        });
    }).catch((error) => {
        console.error("[UNMUTE ERROR]", error)
        embed.data.description = "`❌` Je ne peux pas unmute ce membre."
        return message.reply({embeds: [embed]})
    })

}
