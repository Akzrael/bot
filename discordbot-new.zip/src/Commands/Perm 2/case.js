const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require("discord.js");

exports.help = {
    name: "case",
    description: "Affiche les détails d'une sanction.",
    usage: "<case_id>",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const caseId = args[0];
    if (!caseId) {
        return message.channel.send("`❌` Usage: `!case <case_id>`");
    }

    const db = client.db(message.guildId);
    const sanctions = db.sanctions || [];
    const sanction = sanctions.find(s => s.id === caseId);

    if (!sanction) {
        return message.channel.send("`❌` Sanction introuvable.");
    }

    const embed = new EmbedBuilder()
        .setTitle(`📋 Sanction #${sanction.id}`)
        .setColor(getColorByType(sanction.type))
        .addFields(
            { name: "Type", value: sanction.type, inline: true },
            { name: "Utilisateur", value: `<@${sanction.userId}> (\`${sanction.userId}\`)`, inline: true },
            { name: "Modérateur", value: `<@${sanction.modId}> (\`${sanction.modId}\`)`, inline: true },
            { name: "Raison", value: sanction.reason || "Aucune", inline: false },
            { name: "Date", value: `<t:${Math.floor(sanction.timestamp / 1000)}:F>`, inline: true }
        )
        .setTimestamp();

    if (sanction.duration) {
        embed.addFields({ name: "Durée", value: sanction.duration, inline: true });
    }

    await message.channel.send({ embeds: [embed] });
};

function getColorByType(type) {
    const colors = {
        warn: 0xFAA61A,
        mute: 0xED4245,
        ban: 0x992D22,
        kick: 0xF04747,
        tempban: 0xED4245,
        tempmute: 0xFAA61A
    };
    return colors[type] || 0x5865F2;
}