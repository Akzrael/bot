const ms = require("ms")
const { sendModLog } = require("../../../src/Structure/ModLog.js")

const MAX_TIMEOUT = 28 * 24 * 60 * 60 * 1000; // 28 jours, max autorisé par Discord

function generateCaseId() {
    return `case_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function createCase(db, guildId, data) {
    if (!db.sanctions) db.sanctions = [];
    const caseData = { id: generateCaseId(), timestamp: Date.now(), ...data };
    db.sanctions.push(caseData);
    return caseData;
}

exports.help = {
    name: "mute",
    aliases: ["to", "timeout"],
    description: "Permet de mute un utilisateur en l'excluant temporairement.",
    usage: "<@user> <temps> [raison]",
    example: "@Sadek 12h Spam",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const embed = client.template
    embed.data.description = "`❌` Je n'ai pas trouvé d'utilisateur à mute."

    let member;
    if (message.mentions.members.first()) {
        member = message.mentions.members.first();
    } else {
        member = message.guild.members.cache.get(args[0])
            || await message.guild.members.fetch(args[0]).catch(() => null);
    }

    if(!member) return message.reply({embeds: [embed]})

    embed.data.description = "`❌` Vous ne pouvez pas vous mute vous même."
    if(member.id === message.author.id) return message.reply({embeds: [embed]})

    embed.data.description = "`❌` Vous ne pouvez mute que les membres hiérarchiquement inferieurs à vous."
    if(message.member.roles.highest.position <= member.roles.highest.position) return message.reply({embeds: [embed]})

    embed.data.description = "`❌` Je n'ai pas les permissions nécessaires pour mute ce membre."
    if(!member.moderatable) return message.reply({embeds: [embed]})

    let duration;
    if (!args[1]) {
        duration = MAX_TIMEOUT;
    } else {
        duration = ms(args[1]);
    }

    embed.data.description = "`❌` Le temps indiqué est invalide."
    if(isNaN(duration) || duration <= 0) return message.reply({embeds: [embed]})

    if (duration > MAX_TIMEOUT) duration = MAX_TIMEOUT;

    const reason = args.slice(2).join(" ") || "Aucune raison fournie";
    const durationStr = ms(duration, { long: true });

    member.timeout(duration, `${reason} (par ${message.author.tag})`).then(() => {
        // Create case
        const sanction = createCase(client.db(message.guild.id), message.guild.id, {
            type: "mute",
            userId: member.id,
            modId: message.author.id,
            reason,
            duration: durationStr,
            guildId: message.guild.id
        });

        embed.data.description = `\`✅\` **${member.user.tag}** a été mute avec succès pour **${durationStr}**.\n**Raison :** ${reason}\n**Cas :** #${sanction.id}`
        message.reply({embeds: [embed]})

        sendModLog(client, message.guild, {
            title: "🔇 Membre mute",
            color: 0xFAA61A,
            fields: [
                { name: "Utilisateur", value: `${member.user.tag} (\`${member.id}\`)`, inline: true },
                { name: "Modérateur", value: `${message.author.tag}`, inline: true },
                { name: "Durée", value: durationStr, inline: true },
                { name: "Raison", value: reason },
                { name: "Cas", value: sanction.id, inline: true }
            ]
        });
    }).catch((error) => {
        console.error("[MUTE ERROR]", error)
        embed.data.description = "`❌` Je ne peux pas mute ce membre."
        return message.reply({embeds: [embed]})
    })

}
