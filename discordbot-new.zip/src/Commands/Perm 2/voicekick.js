const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, UserSelectMenuBuilder } = require("discord.js");

exports.help = {
    name: "voicekick",
    description: "Déconnecte un membre d'un salon vocal.",
    aliases: ["vkick", "vk"],
    usage: "<@user> [raison]",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const target = message.mentions.members.first();
    if (!target) {
        return message.channel.send("`❌` Utilisateur introuvable.");
    }

    if (!target.voice.channel) {
        return message.channel.send("`❌` Cet utilisateur n'est pas dans un salon vocal.");
    }

    if (!target.voice.channel.permissionsFor(message.guild.members.me).has("MoveMembers")) {
        return message.channel.send("`❌` Je n'ai pas la permission de déplacer des membres.");
    }

    const reason = args.slice(1).join(" ") || "Aucune raison fournie";

    try {
        await target.voice.disconnect(`VoiceKick: ${reason} (par ${message.author.tag})`);
        await message.channel.send(`✅ **${target.user.tag}** a été déconnecté de **${target.voice.channel.name}**.\nRaison: ${reason}`);
    } catch (error) {
        console.error("[VOICEKICK ERROR]", error);
        await message.channel.send("`❌` Impossible de déconnecter cet utilisateur.");
    }
};