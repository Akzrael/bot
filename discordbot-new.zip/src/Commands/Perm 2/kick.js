const { sendModLog } = require("../../../src/Structure/ModLog.js")

function generateCaseId() {
    return `case_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
}

function createCase(db, guildId, data) {
    if (!db.sanctions) db.sanctions = [];
    const caseData = { id: generateCaseId(), timestamp: Date.now(), ...data };
    db.sanctions.push(caseData);
    return caseData;
}

exports.help = {
    name: 'kick',
    description: "Permet de kick un utilisateur.",
    usage: "<user/id> [raison]",
    example: "@Sadek Spam | 513066398847729696 Raid",
    perms: 2,
}

exports.run = async (client, message, args) => {
    const embed = client.template
    embed.data.description = "`❌` Je n'ai pas trouvé d'utilisateur à expulser."

    let userToKick;
    if (message.mentions.members.first()) {
        userToKick = message.mentions.members.first();
    } else {
        userToKick = message.guild.members.cache.get(args[0])
            || await message.guild.members.fetch(args[0]).catch(() => null);
    }
    if(!userToKick) return message.reply({embeds: [embed]})

    embed.data.description = "`❌` Vous ne pouvez pas vous expulser vous même."
    if(userToKick.id === message.author.id) return message.reply({embeds: [embed]})

    embed.data.description = "`❌` Vous ne pouvez kick que les membres hiérarchiquement inferieurs à vous."
    if(message.member.roles.highest.position <= userToKick.roles.highest.position) return message.reply({embeds: [embed]})

    embed.data.description = "`❌` Je n'ai pas les permissions nécessaires pour expulser ce membre (rôle trop haut)."
    if(!userToKick.kickable) return message.reply({embeds: [embed]})

    const reason = args.slice(1).join(" ") || "Aucune raison fournie";

    userToKick.kick(`${reason} (par ${message.author.tag})`)
        .then(() => {
        // Create case
        const sanction = createCase(client.db(message.guild.id), message.guild.id, {
            type: "kick",
            userId: userToKick.id,
            modId: message.author.id,
            reason,
            guildId: message.guild.id
        });

        embed.data.description = `\`✅\` **${userToKick.user.tag}** a bien été expulsé avec succès.\n**Raison :** ${reason}\n**Cas :** #${sanction.id}`
        message.reply({embeds: [embed]})

        sendModLog(client, message.guild, {
            title: "👢 Membre expulsé",
            color: 0xFEE75C,
            fields: [
                { name: "Utilisateur", value: `${userToKick.user.tag} (\`${userToKick.id}\`)`, inline: true },
                { name: "Modérateur", value: `${message.author.tag}`, inline: true },
                { name: "Raison", value: reason },
                { name: "Cas", value: sanction.id, inline: true }
            ]
        });
    })
        .catch(err => {
        console.error("[KICK ERROR]", err);
        embed.data.description = "`❌` Je ne peux pas expulser ce membre."
        return message.reply({embeds: [embed]})
    })
}
