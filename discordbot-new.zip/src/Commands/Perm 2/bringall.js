const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType } = require("discord.js");

exports.help = {
    name: "bringall",
    description: "Ramène tous les membres d'un salon vocal vers un autre.",
    aliases: ["bring"],
    usage: "<#salon_source> <#salon_destination>",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const source = message.mentions.channels.first();
    const destination = message.mentions.channels.last();

    if (!source || source.type !== ChannelType.GuildVoice) {
        return message.channel.send("`❌` Salon source invalide (doit être vocal).");
    }

    if (!destination || destination.type !== ChannelType.GuildVoice) {
        return message.channel.send("`❌` Salon destination invalide (doit être vocal).");
    }

    if (source.id === destination.id) {
        return message.channel.send("`❌` Les salons source et destination sont identiques.");
    }

    if (!destination.permissionsFor(message.guild.members.me).has(["MoveMembers", "Connect"])) {
        return message.channel.send("`❌` Permissions insuffisantes dans le salon de destination.");
    }

    const members = source.members.filter(m => !m.user.bot);
    if (members.size === 0) {
        return message.channel.send("`❌` Aucun membre à déplacer dans ce salon.");
    }

    const waitMsg = await message.channel.send(`⏳ Déplacement de **${members.size}** membre(s)...`);

    let moved = 0;
    let failed = 0;

    for (const [, member] of members) {
        try {
            await member.voice.setChannel(destination, `BringAll par ${message.author.tag}`);
            moved++;
            await new Promise(r => setTimeout(r, 100));
        } catch (error) {
            failed++;
        }
    }

    const embed = new EmbedBuilder()
        .setTitle("📦 BringAll terminé")
        .setColor(failed === 0 ? 0x57F287 : 0xFAA61A)
        .addFields(
            { name: "Source", value: source.toString(), inline: true },
            { name: "Destination", value: destination.toString(), inline: true },
            { name: "Déplacés", value: moved.toString(), inline: true },
            { name: "Échecs", value: failed.toString(), inline: true }
        );

    await waitMsg.edit({ content: null, embeds: [embed] });
};