const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

exports.help = {
    name: "cases",
    description: "Affiche l'historique des sanctions d'un utilisateur.",
    usage: "[@user]",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const target = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!target) {
        return message.channel.send("`❌` Utilisateur introuvable.");
    }

    const db = client.db(message.guildId);
    const sanctions = db.sanctions || [];
    const userSanctions = sanctions.filter(s => s.userId === target.id).sort((a, b) => b.timestamp - a.timestamp);

    if (userSanctions.length === 0) {
        return message.channel.send(`✅ **${target.tag}** n'a aucune sanction.`);
    }

    const pageSize = 10;
    let page = 0;
    const totalPages = Math.ceil(userSanctions.length / pageSize);

    const buildEmbed = (page) => {
        const start = page * pageSize;
        const end = start + pageSize;
        const pageSanctions = userSanctions.slice(start, end);

        return new EmbedBuilder()
            .setTitle(`📋 Sanctions de ${target.tag}`)
            .setColor(0x5865F2)
            .setDescription(
                pageSanctions.map(s =>
                    `\`#${s.id}\` **${s.type}** — <t:${Math.floor(s.timestamp / 1000)}:R>\n` +
                    `> Raison: ${s.reason || "Aucune"}${s.duration ? ` | Durée: ${s.duration}` : ""}`
                ).join("\n\n")
            )
            .setFooter({ text: `Page ${page + 1}/${totalPages} • Total: ${userSanctions.length}` })
            .setTimestamp();
    };

    const buildComponents = (page) => {
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`cases_prev_${target.id}`)
                .setLabel("◀ Précédent")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(page === 0),
            new ButtonBuilder()
                .setCustomId(`cases_next_${target.id}`)
                .setLabel("Suivant ▶")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(page === totalPages - 1)
        );
        return [row];
    };

    const msg = await message.channel.send({ embeds: [buildEmbed(page)], components: buildComponents(page) });

    const collector = msg.createMessageComponentCollector({ time: 60000 });

    collector.on("collect", async interaction => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction.", flags: 64 });
        }

        if (interaction.customId === `cases_prev_${target.id}`) {
            page--;
        } else if (interaction.customId === `cases_next_${target.id}`) {
            page++;
        }

        await interaction.update({ embeds: [buildEmbed(page)], components: buildComponents(page) });
    });

    collector.on("end", () => msg.edit({ components: [] }).catch(() => {}));
};