const db = require("../../../index.js")
const { sendModLog } = require("../../../src/Structure/ModLog.js")

exports.help = {
    name: 'delwarn',
    aliases: ['unwarn', 'removewarn'],
    description: "Supprime un avertissement d'un utilisateur.",
    usage: "<@user/id> <numéro> ou <@user/id> all",
    example: "@Sadek 2",
    perms: 2,
};

exports.run = async (client, message, args) => {
    const embed = client.template;

    let targetId;
    if (message.mentions.users.first()) {
        targetId = message.mentions.users.first().id;
    } else {
        targetId = args[0];
    }

    if (!targetId) {
        embed.data.description = "`❌` Vous devez mentionner un utilisateur.";
        return message.reply({ embeds: [embed] });
    }

    const key = `warns_${message.guild.id}_${targetId}`;
    const warns = await db.get(key) || [];

    if (warns.length === 0) {
        embed.data.description = "`❌` Cet utilisateur n'a aucun avertissement.";
        return message.reply({ embeds: [embed] });
    }

    if (args[1] === "all") {
        await db.delete(key);
        embed.data.description = `\`✅\` ${warns.length} avertissement(s) supprimé(s).`;
        message.reply({ embeds: [embed] });

        sendModLog(client, message.guild, {
            title: "🗑️ Avertissements réinitialisés",
            color: 0x57F287,
            fields: [
                { name: "Utilisateur", value: `<@${targetId}>`, inline: true },
                { name: "Modérateur", value: `${message.author.tag}`, inline: true },
            ],
        });
        return;
    }

    const index = Number(args[1]) - 1;
    if (isNaN(index) || index < 0 || index >= warns.length) {
        embed.data.description = `\`❌\` Numéro invalide. Cet utilisateur a ${warns.length} avertissement(s).`;
        return message.reply({ embeds: [embed] });
    }

    const [removed] = warns.splice(index, 1);
    await db.set(key, warns);

    embed.data.description = `\`✅\` Avertissement supprimé : *${removed.reason}*`;
    message.reply({ embeds: [embed] });

    sendModLog(client, message.guild, {
        title: "🗑️ Avertissement supprimé",
        color: 0x57F287,
        fields: [
            { name: "Utilisateur", value: `<@${targetId}>`, inline: true },
            { name: "Modérateur", value: `${message.author.tag}`, inline: true },
            { name: "Raison supprimée", value: removed.reason },
        ],
    });
};
