const { EmbedBuilder } = require("discord.js");

exports.help = {
    name: "backup-list",
    description: "Liste toutes les sauvegardes du serveur.",
    perms: 6,
};

exports.run = async (client, message) => {
    const backups = client.backups?.get(message.guild.id) || [];

    if (backups.length === 0) {
        return message.channel.send("`❌` Aucune sauvegarde trouvée pour ce serveur.");
    }

    const embed = new EmbedBuilder()
        .setTitle("💾 Liste des sauvegardes")
        .setColor(0x5865F2)
        .setDescription(
            backups.map((b, i) =>
                `\`${i + 1}.\` **${b.name}** (${b.id})\n` +
                `   Rôles: ${b.roles.length} | Catégories: ${b.categories.length} | Salons: ${b.channels.length} | Émojis: ${b.emojis.length}\n` +
                `   Créé le: <t:${Math.floor(b.createdAt / 1000)}:F>`
            ).join("\n\n")
        )
        .setFooter({ text: `Total: ${backups.length} sauvegarde(s)` });

    await message.channel.send({ embeds: [embed] });
};