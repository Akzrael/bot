const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

exports.help = {
    name: "backup-delete",
    description: "Supprime une sauvegarde.",
    usage: "<backup_id>",
    perms: 6,
};

exports.run = async (client, message, args) => {
    const backupId = args[0];
    if (!backupId) {
        return message.channel.send("`❌` Usage: `!backup-delete <backup_id>`");
    }

    const backups = client.backups?.get(message.guild.id) || [];
    const index = backups.findIndex(b => b.id === backupId);

    if (index === -1) {
        return message.channel.send("`❌` Sauvegarde introuvable.");
    }

    const backup = backups[index];

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`backup_delete_confirm_${backupId}`)
            .setLabel("Confirmer la suppression")
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId(`backup_delete_cancel_${backupId}`)
            .setLabel("Annuler")
            .setStyle(ButtonStyle.Secondary)
    );

    const embed = new EmbedBuilder()
        .setTitle("⚠️ Confirmer la suppression")
        .setDescription(`Êtes-vous sûr de vouloir supprimer la sauvegarde **${backup.name}** ?\nCette action est irréversible.`)
        .setColor(0xED4245);

    const msg = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = msg.createMessageComponentCollector({ time: 30000 });

    collector.on("collect", async interaction => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction.", flags: 64 });
        }

        if (interaction.customId === `backup_delete_confirm_${backupId}`) {
            backups.splice(index, 1);
            client.backups.set(message.guild.id, backups);
            await interaction.update({ content: `✅ Sauvegarde **${backup.name}** supprimée.`, embeds: [], components: [] });
        } else {
            await interaction.update({ content: "❌ Suppression annulée.", embeds: [], components: [] });
        }
        collector.stop();
    });

    collector.on("end", () => {
        msg.edit({ components: [] }).catch(() => {});
    });
};