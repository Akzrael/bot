const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType,
    PermissionFlagsBits
} = require("discord.js");

exports.help = {
    name: "backup-load",
    description: "Restaure une sauvegarde (⚠️ DANGEREUX - écrase la configuration actuelle).",
    usage: "<backup_id>",
    perms: 6,
};

exports.run = async (client, message, args) => {
    const backupId = args[0];
    if (!backupId) {
        return message.channel.send("`❌` Usage: `!backup-load <backup_id>`");
    }

    const backups = client.backups?.get(message.guild.id) || [];
    const backup = backups.find(b => b.id === backupId);

    if (!backup) {
        return message.channel.send("`❌` Sauvegarde introuvable.");
    }

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`backup_load_confirm_${backupId}`)
            .setLabel("⚠️ CONFIRMER LA RESTAURATION")
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId(`backup_load_cancel_${backupId}`)
            .setLabel("Annuler")
            .setStyle(ButtonStyle.Secondary)
    );

    const embed = new EmbedBuilder()
        .setTitle("⚠️ RESTAURATION DE SAUVEGARDE - DANGER")
        .setDescription(
            `**Cette action va ÉCRASER la configuration actuelle du serveur.**\n\n` +
            `Sauvegarde: **${backup.name}**\n` +
            `Rôles: ${backup.roles.length} | Catégories: ${backup.categories.length} | Salons: ${backup.channels.length}\n\n` +
            `❌ Tous les salons/catégories/rôles actuels seront SUPPRIMÉS\n` +
            `❌ Les permissions seront réinitialisées\n` +
            `❌ Les émojis seront remplacés\n\n` +
            `**Êtes-vous ABSOLUMENT sûr ?**`
        )
        .setColor(0xED4245);

    const msg = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = msg.createMessageComponentCollector({ time: 60000 });

    collector.on("collect", async interaction => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction.", flags: 64 });
        }

        if (interaction.customId === `backup_load_confirm_${backupId}`) {
            await interaction.update({ content: "⏳ Restauration en cours...", embeds: [], components: [] });

            try {
                await restoreBackup(message.guild, backup);
                await interaction.followUp({ content: `✅ Sauvegarde **${backup.name}** restaurée avec succès !` });
            } catch (error) {
                console.error("[BACKUP LOAD ERROR]", error);
                await interaction.followUp({ content: "`❌` Erreur lors de la restauration." });
            }
        } else {
            await interaction.update({ content: "❌ Restauration annulée.", embeds: [], components: [] });
        }
        collector.stop();
    });

    collector.on("end", () => {
        msg.edit({ components: [] }).catch(() => {});
    });
};

async function restoreBackup(guild, backup) {
    await deleteAllChannels(guild);
    await deleteAllRoles(guild);
    await deleteAllEmojis(guild);

    const createdRoles = new Map();
    const createdCategories = new Map();

    for (const roleData of backup.roles) {
        try {
            const role = await guild.roles.create({
                name: roleData.name,
                color: roleData.color,
                hoist: roleData.hoist,
                position: roleData.position,
                permissions: roleData.permissions,
                mentionable: roleData.mentionable,
                reason: `Backup restore: ${backup.name}`
            });
            createdRoles.set(roleData.name, role);
        } catch (error) {
            console.error(`[BACKUP RESTORE] Failed to create role ${roleData.name}:`, error);
        }
    }

    for (const catData of backup.categories) {
        try {
            const overwrites = await deserializeOverwrites(guild, catData.permissionOverwrites, createdRoles);
            const category = await guild.channels.create({
                name: catData.name,
                type: ChannelType.GuildCategory,
                position: catData.position,
                permissionOverwrites: overwrites,
                reason: `Backup restore: ${backup.name}`
            });
            createdCategories.set(catData.name, category);
        } catch (error) {
            console.error(`[BACKUP RESTORE] Failed to create category ${catData.name}:`, error);
        }
    }

    for (const channelData of backup.channels) {
        try {
            const parent = channelData.parent ? createdCategories.get(channelData.parent) : null;
            const overwrites = await deserializeOverwrites(guild, channelData.permissionOverwrites, createdRoles);

            const createOptions = {
                name: channelData.name,
                type: channelData.type,
                topic: channelData.topic,
                nsfw: channelData.nsfw,
                bitrate: channelData.bitrate,
                userLimit: channelData.userLimit,
                parent: parent,
                position: channelData.position,
                permissionOverwrites: overwrites,
                reason: `Backup restore: ${backup.name}`
            };

            await guild.channels.create(createOptions);
        } catch (error) {
            console.error(`[BACKUP RESTORE] Failed to create channel ${channelData.name}:`, error);
        }
    }

    for (const emojiData of backup.emojis) {
        try {
            await guild.emojis.create({
                attachment: emojiData.url,
                name: emojiData.name,
                reason: `Backup restore: ${backup.name}`
            });
        } catch (error) {
            console.error(`[BACKUP RESTORE] Failed to create emoji ${emojiData.name}:`, error);
        }
    }
}

async function deleteAllChannels(guild) {
    const channels = guild.channels.cache.filter(c => c.type !== ChannelType.GuildCategory);
    for (const [, channel] of channels) {
        await channel.delete("Backup restore").catch(() => {});
    }
    const categories = guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory);
    for (const [, cat] of categories) {
        await cat.delete("Backup restore").catch(() => {});
    }
}

async function deleteAllRoles(guild) {
    const roles = guild.roles.cache.filter(r => !r.managed && r.id !== guild.id);
    for (const [, role] of roles) {
        await role.delete("Backup restore").catch(() => {});
    }
}

async function deleteAllEmojis(guild) {
    for (const [, emoji] of guild.emojis.cache) {
        await emoji.delete("Backup restore").catch(() => {});
    }
}

async function deserializeOverwrites(guild, overwrites, createdRoles) {
    const result = [];
    for (const ow of overwrites) {
        let target = guild.roles.cache.get(ow.id) || createdRoles.get(ow.id);
        if (!target) continue;

        result.push({
            id: target.id,
            allow: ow.allow,
            deny: ow.deny
        });
    }
    return result;
}