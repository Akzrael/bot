const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType,
    PermissionFlagsBits
} = require("discord.js");

exports.help = {
    name: "backup-create",
    description: "Crée une sauvegarde complète du serveur (rôles, salons, catégories, permissions, émojis).",
    perms: 6,
};

exports.run = async (client, message, args) => {
    const guild = message.guild;
    const backupName = args.join(" ") || `Backup-${Date.now()}`;

    const waitMsg = await message.channel.send("⏳ Création de la sauvegarde en cours...");

    try {
        const backup = await createBackup(guild, backupName);
        
        const backups = client.backups || new Map();
        if (!backups.has(guild.id)) backups.set(guild.id, []);
        backups.get(guild.id).push(backup);
        client.backups = backups;

        await waitMsg.edit({
            content: `✅ Sauvegarde **${backup.name}** créée avec succès !`,
            embeds: [buildBackupEmbed(backup)]
        });

    } catch (error) {
        console.error("[BACKUP CREATE ERROR]", error);
        await waitMsg.edit({ content: "`❌` Erreur lors de la création de la sauvegarde." });
    }
};

async function createBackup(guild, name) {
    const roles = [];
    const channels = [];
    const categories = [];
    const emojis = [];

    for (const [, role] of guild.roles.cache) {
        if (role.managed || role.id === guild.id) continue;
        roles.push({
            name: role.name,
            color: role.color,
            hoist: role.hoist,
            position: role.position,
            permissions: role.permissions.bitfield.toString(),
            mentionable: role.mentionable
        });
    }

    for (const [, channel] of guild.channels.cache) {
        if (channel.type === ChannelType.GuildCategory) {
            categories.push({
                name: channel.name,
                position: channel.position,
                permissionOverwrites: serializeOverwrites(channel.permissionOverwrites)
            });
        } else {
            channels.push({
                name: channel.name,
                type: channel.type,
                topic: channel.topic || null,
                nsfw: channel.nsfw,
                bitrate: channel.bitrate || null,
                userLimit: channel.userLimit || null,
                parent: channel.parent?.name || null,
                position: channel.position,
                permissionOverwrites: serializeOverwrites(channel.permissionOverwrites)
            });
        }
    }

    for (const [, emoji] of guild.emojis.cache) {
        emojis.push({
            name: emoji.name,
            url: emoji.url,
            animated: emoji.animated
        });
    }

    return {
        id: `backup_${Date.now()}`,
        name: name,
        guildId: guild.id,
        guildName: guild.name,
        createdAt: Date.now(),
        roles,
        channels,
        categories,
        emojis,
        icon: guild.iconURL() || null
    };
}

function serializeOverwrites(overwrites) {
    const result = [];
    for (const [, overwrite] of overwrites) {
        result.push({
            id: overwrite.id,
            type: overwrite.type,
            allow: overwrite.allow.toArray(),
            deny: overwrite.deny.toArray()
        });
    }
    return result;
}

function buildBackupEmbed(backup) {
    return new EmbedBuilder()
        .setTitle("💾 Sauvegarde créée")
        .setColor(0x57F287)
        .addFields(
            { name: "Nom", value: backup.name, inline: true },
            { name: "Serveur", value: backup.guildName, inline: true },
            { name: "Date", value: `<t:${Math.floor(backup.createdAt / 1000)}:F>`, inline: true },
            { name: "Rôles", value: backup.roles.length.toString(), inline: true },
            { name: "Catégories", value: backup.categories.length.toString(), inline: true },
            { name: "Salons", value: backup.channels.length.toString(), inline: true },
            { name: "Émojis", value: backup.emojis.length.toString(), inline: true }
        )
        .setThumbnail(backup.icon)
        .setTimestamp();
}