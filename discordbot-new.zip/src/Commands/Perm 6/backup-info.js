const { EmbedBuilder } = require("discord.js");

exports.help = {
    name: "backup-info",
    description: "Affiche les détails d'une sauvegarde.",
    usage: "<backup_id>",
    perms: 6,
};

exports.run = async (client, message, args) => {
    const backupId = args[0];
    if (!backupId) {
        return message.channel.send("`❌` Usage: `!backup-info <backup_id>`");
    }

    const backups = client.backups?.get(message.guild.id) || [];
    const backup = backups.find(b => b.id === backupId);

    if (!backup) {
        return message.channel.send("`❌` Sauvegarde introuvable.");
    }

    const embed = new EmbedBuilder()
        .setTitle(`💾 Détails: ${backup.name}`)
        .setColor(0x5865F2)
        .addFields(
            { name: "ID", value: `\`${backup.id}\``, inline: true },
            { name: "Serveur", value: backup.guildName, inline: true },
            { name: "Créé le", value: `<t:${Math.floor(backup.createdAt / 1000)}:F>`, inline: true },
            { name: "Rôles", value: backup.roles.length.toString(), inline: true },
            { name: "Catégories", value: backup.categories.length.toString(), inline: true },
            { name: "Salons", value: backup.channels.length.toString(), inline: true },
            { name: "Émojis", value: backup.emojis.length.toString(), inline: true }
        )
        .setThumbnail(backup.icon)
        .setTimestamp();

    await message.channel.send({ embeds: [embed] });
};