const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const db = require("../../../index.js");

exports.help = {
    name: "level",
    description: "Affiche votre niveau ou celui d'un membre.",
    usage: "[@user]",
    perms: 1,
};

exports.run = async (client, message, args) => {
    const target = message.mentions.users.first() || (args[0] ? await client.users.fetch(args[0]).catch(() => null) : message.author);
    if (!target) {
        return message.channel.send("`❌` Utilisateur introuvable.");
    }

    // Level config (enabled, xpPerMessage, etc.) lives in the fs-based client.db() store.
    const guildDb = client.db(message.guildId);
    if (!guildDb.level || !guildDb.level.enabled) {
        return message.channel.send("`❌` Le système de niveaux n'est pas activé.");
    }

    // Per-user XP data lives in quick.db, same as Events/Level/messageCreate.js.
    const userKey = `level_${message.guild.id}_${target.id}`;
    const userData = await db.get(userKey) || { xp: 0, level: 1, messages: 0 };

    const xpForNext = calculateXpForLevel(userData.level + 1) - userData.xp;
    const xpForCurrent = calculateXpForLevel(userData.level);
    const xpForNextLevel = calculateXpForLevel(userData.level + 1);
    const progressXp = userData.xp - xpForCurrent;
    const neededXp = xpForNextLevel - xpForCurrent;
    const progress = Math.min(100, Math.max(0, (progressXp / neededXp) * 100));

    const barLength = 20;
    const filled = Math.round((progress / 100) * barLength);
    const bar = "█".repeat(filled) + "░".repeat(barLength - filled);

    const embed = new EmbedBuilder()
        .setTitle(`📊 Niveau de ${target.tag}`)
        .setColor(0x5865F2)
        .setThumbnail(target.displayAvatarURL())
        .addFields(
            { name: "Niveau", value: `\`${userData.level}\``, inline: true },
            { name: "XP Total", value: `\`${userData.xp}\``, inline: true },
            { name: "Messages", value: `\`${userData.messages || 0}\``, inline: true },
            { name: `Progression vers niveau ${userData.level + 1}`, value: `\`${progressXp}/${neededXp}\`\n\`${bar}\` ${progress.toFixed(1)}%`, inline: false }
        )
        .setTimestamp();

    await message.channel.send({ embeds: [embed] });
};

function calculateLevel(xp) {
    return Math.floor(0.1 * Math.sqrt(xp)) + 1;
}

function calculateXpForLevel(level) {
    return Math.pow((level - 1) / 0.1, 2);
}
