const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const db = require("../../../index.js");

exports.help = {
    name: "inviteboard",
    description: "Affiche le classement des invitations du serveur.",
    aliases: ["invitetop", "invitesleaderboard"],
    perms: 1,
};

exports.run = async (client, message) => {
    const guild = message.guild;

    const all = await db.all();
    const rows = all.filter(row => row.id.startsWith(`invites_${guild.id}_`));
    if (rows.length === 0) {
        return message.channel.send("`❌` Aucune donnée d'invitation trouvée.");
    }

    const entries = [];
    for (const row of rows) {
        const userId = row.id.replace(`invites_${guild.id}_`, "");
        const data = row.value || {};
        const total = (data.regular || 0) - (data.leaves || 0) + (data.bonus || 0);
        if (total > 0) {
            entries.push({ userId, total, regular: data.regular || 0, leaves: data.leaves || 0 });
        }
    }

    entries.sort((a, b) => b.total - a.total);
    const top10 = entries.slice(0, 10);

    const embed = new EmbedBuilder()
        .setTitle("🏆 Classement des invitations")
        .setColor(0x5865F2)
        .setDescription(
            top10.map((e, i) => {
                const user = guild.members.cache.get(e.userId) || { user: { tag: "Utilisateur inconnu" } };
                return `\`${i + 1}.\` ${user.user?.tag || "Inconnu"} — **${e.total}** (➕${e.regular} ➖${e.leaves})`;
            }).join("\n") || "Aucun invité"
        )
        .setFooter({ text: `Total: ${entries.length} membres ont invité` })
        .setTimestamp();

    await message.channel.send({ embeds: [embed] });
};
