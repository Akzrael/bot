const { EmbedBuilder } = require("discord.js");

exports.help = {
    name: 'userinfo',
    aliases: ['whois', 'ui'],
    description: "Affiche les informations d'un utilisateur.",
    usage: "[@user/id]",
    example: "@Sadek",
    perms: 1,
};

exports.run = async (client, message, args) => {
    const embed = client.template;

    let member;
    if (message.mentions.members.first()) {
        member = message.mentions.members.first();
    } else if (args[0]) {
        member = message.guild.members.cache.get(args[0])
            || await message.guild.members.fetch(args[0]).catch(() => null);
    } else {
        member = message.member;
    }

    if (!member) {
        embed.data.description = "`❌` Je n'ai pas trouvé cet utilisateur sur ce serveur.";
        return message.reply({ embeds: [embed] });
    }

    const user = member.user;

    const roles = member.roles.cache
        .filter(r => r.id !== message.guild.id)
        .sort((a, b) => b.position - a.position)
        .map(r => `${r}`);

    const statusMap = {
        online: "🟢 En ligne",
        idle: "🌙 Absent",
        dnd: "⛔ Ne pas déranger",
        offline: "⚫ Hors ligne",
    };
    const status = statusMap[member.presence?.status] || "⚫ Hors ligne";

    const infoEmbed = new EmbedBuilder()
        .setColor(member.displayHexColor && member.displayHexColor !== "#000000" ? member.displayHexColor : (client.color || 0x5865F2))
        .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() })
        .setThumbnail(user.displayAvatarURL({ size: 256 }))
        .addFields(
            { name: "ID", value: `\`${user.id}\``, inline: true },
            { name: "Statut", value: status, inline: true },
            { name: "Bot", value: user.bot ? "Oui" : "Non", inline: true },
            { name: "Compte créé", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
            { name: "A rejoint le serveur", value: member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : "Inconnu", inline: true },
            { name: "Rôle le plus haut", value: member.roles.highest ? `${member.roles.highest}` : "Aucun", inline: true },
            { name: `Rôles [${roles.length}]`, value: roles.length > 0 ? (roles.length > 15 ? roles.slice(0, 15).join(" ") + `... (+${roles.length - 15})` : roles.join(" ")) : "Aucun" }
        )
        .setTimestamp()
        .setFooter({ text: client.footer, iconURL: client.user.displayAvatarURL() });

    if (member.communicationDisabledUntilTimestamp && member.communicationDisabledUntilTimestamp > Date.now()) {
        infoEmbed.addFields({ name: "🔇 Mute jusqu'à", value: `<t:${Math.floor(member.communicationDisabledUntilTimestamp / 1000)}:R>` });
    }

    return message.reply({ embeds: [infoEmbed] });
};
