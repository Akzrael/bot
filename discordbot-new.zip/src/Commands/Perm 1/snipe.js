const { EmbedBuilder } = require("discord.js");

exports.help = {
    name: "snipe",
    description: "Permet de voir le dernier message supprimé.",
    perms: 1,
    usage: "<nombre>",
    example: "12"
};

exports.run = async (client, message, args) => {
    const snipeMap = client.snipeMap;

    const errorEmbed = client.template;
    errorEmbed.data.description = "`❌` Il n'y a aucun message supprimé à snipe.";

    if (!snipeMap) {
        return message.reply({ embeds: [errorEmbed] });
    }

    const snipes = snipeMap.get(message.channel.id);

    if (!snipes || snipes.length === 0) {
        return message.reply({ embeds: [errorEmbed] });
    }

    let number = 1;

    if (args[0] && /^\d+$/.test(args[0])) {
        number = parseInt(args[0], 10);
    }

    // Snipe 1 = newest
    // Snipe 2 = second newest
    // etc.
    if (number < 1) number = 1;
    if (number > snipes.length) number = snipes.length;

    const snipe = snipes[number - 1];

    const embed = new EmbedBuilder()
        .setColor(client.color)
        .setTimestamp()
        .setFooter({
            text: `Snipe ${number}/${snipes.length}`
        });

    if (snipe.author) {
        embed.setAuthor({
            name: snipe.author.tag || "Utilisateur inconnu",
            iconURL: typeof snipe.author.displayAvatarURL === "function"
                ? snipe.author.displayAvatarURL()
                : undefined
        });
    }

    if (snipe.content) {
        embed.addFields({
            name: "Contenu du message",
            value: snipe.content.slice(0, 1024),
            inline: false
        });
    }

    if (snipe.image) {
        embed.setImage(snipe.image);
    }

    if (!snipe.content && !snipe.image) {
        embed.setDescription("`📎` Le message supprimé ne contenait aucun texte.");
    }

    return message.reply({
        embeds: [embed]
    });
};
