const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const db = require("../../../index.js");

exports.help = {
    name: "invites",
    description: "Affiche le classement des invitations ou vos propres stats.",
    usage: "[@user]",
    perms: 1,
};

exports.run = async (client, message, args) => {
    const target = message.mentions.users.first() || (args[0] ? await client.users.fetch(args[0]).catch(() => null) : message.author);

    if (!target) {
        return message.channel.send("`❌` Utilisateur introuvable.");
    }

    const data = await db.get(`invites_${message.guild.id}_${target.id}`) || { regular: 0, leaves: 0, fake: 0, bonus: 0 };
    const total = (data.regular || 0) - (data.leaves || 0) + (data.bonus || 0);

    const embed = new EmbedBuilder()
        .setTitle(`📨 Invitations de ${target.tag}`)
        .setColor(0x5865F2)
        .addFields(
            { name: "Rejoints", value: (data.regular || 0).toString(), inline: true },
            { name: "Partis", value: (data.leaves || 0).toString(), inline: true },
            { name: "Bonus", value: (data.bonus || 0).toString(), inline: true },
            { name: "Total", value: total.toString(), inline: true }
        )
        .setThumbnail(target.displayAvatarURL())
        .setTimestamp();

    await message.channel.send({ embeds: [embed] });
};
