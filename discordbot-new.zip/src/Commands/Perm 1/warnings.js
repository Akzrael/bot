const { EmbedBuilder } = require("discord.js");
const db = require("../../../index.js")

exports.help = {
    name: 'warnings',
    aliases: ['warns'],
    description: "Affiche les avertissements d'un utilisateur (les vôtres par défaut).",
    usage: "[@user/id]",
    example: "@Sadek",
    perms: 1,
};

exports.run = async (client, message, args) => {
    const embed = client.template;

    let targetId;
    if (message.mentions.users.first()) {
        targetId = message.mentions.users.first().id;
    } else if (args[0]) {
        targetId = args[0];
    } else {
        targetId = message.author.id;
    }

    // Non-staff can only check their own warnings
    if (targetId !== message.author.id) {
        const perms = await db.get(`perms_${message.guild.id}`) || { perms2: [], perms3: [] };
        const owner = await message.guild.fetchOwner();
        const isStaff = client.config.owners.includes(message.author.id)
            || message.author.id === owner.id
            || perms.perms2.includes(message.author.id)
            || perms.perms3.includes(message.author.id);

        if (!isStaff) {
            embed.data.description = "`❌` Vous ne pouvez consulter que vos propres avertissements.";
            return message.reply({ embeds: [embed] });
        }
    }

    const user = await client.users.fetch(targetId).catch(() => null);
    if (!user) {
        embed.data.description = "`❌` Utilisateur introuvable.";
        return message.reply({ embeds: [embed] });
    }

    const warns = await db.get(`warns_${message.guild.id}_${targetId}`) || [];

    const infoEmbed = new EmbedBuilder()
        .setColor(client.color || 0x5865F2)
        .setAuthor({ name: `Avertissements de ${user.tag}`, iconURL: user.displayAvatarURL() })
        .setFooter({ text: client.footer, iconURL: client.user.displayAvatarURL() })
        .setTimestamp();

    if (warns.length === 0) {
        infoEmbed.setDescription("Aucun avertissement.");
    } else {
        infoEmbed.setDescription(
            warns.map((w, i) => `**#${i + 1}** — ${w.reason}\n<t:${Math.floor(w.timestamp / 1000)}:R> par <@${w.moderator}>`).join("\n\n")
        );
    }

    return message.reply({ embeds: [infoEmbed] });
};
