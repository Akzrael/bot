const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const db = require("../../../index.js");

exports.help = {
    name: "leaderboard",
    description: "Affiche le classement des niveaux du serveur.",
    aliases: ["lb", "leveltop", "ranktop"],
    perms: 1,
};

exports.run = async (client, message) => {
    // Level config lives in the fs-based client.db() store.
    const guildDb = client.db(message.guildId);
    if (!guildDb.level || !guildDb.level.enabled) {
        return message.channel.send("`❌` Le système de niveaux n'est pas activé.");
    }

    const guild = message.guild;

    // Per-user XP data lives in quick.db, same as Events/Level/messageCreate.js.
    const all = await db.all();
    const rows = all.filter(row => row.id.startsWith(`level_${guild.id}_`));

    if (rows.length === 0) {
        return message.channel.send("`❌` Aucune donnée de niveau trouvée.");
    }

    const entries = [];
    for (const row of rows) {
        const userId = row.id.replace(`level_${guild.id}_`, "");
        const data = row.value || {};
        if (data.xp > 0) {
            entries.push({ userId, xp: data.xp, level: data.level, messages: data.messages || 0 });
        }
    }

    entries.sort((a, b) => b.xp - a.xp);
    const top10 = entries.slice(0, 10);

    const embed = new EmbedBuilder()
        .setTitle("🏆 Classement des niveaux")
        .setColor(0x5865F2)
        .setDescription(
            top10.map((e, i) => {
                const member = guild.members.cache.get(e.userId);
                return `\`${i + 1}.\` ${member?.user?.tag || "Inconnu"} — **Niv. ${e.level}** (${e.xp} XP)`;
            }).join("\n") || "Aucun niveau"
        )
        .setFooter({ text: `Total: ${entries.length} membres classés` })
        .setTimestamp();

    await message.channel.send({ embeds: [embed] });
};
