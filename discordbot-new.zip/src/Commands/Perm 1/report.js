const { EmbedBuilder } = require("discord.js");
const db = require("../../../index.js")

exports.help = {
    name: 'report',
    description: "Signale un utilisateur au staff du serveur.",
    usage: "<@user/id> <raison>",
    example: "@Sadek Il spam les salons",
    perms: 1,
    cooldown: 30,
};

exports.run = async (client, message, args) => {
    const embed = client.template;

    let target;
    if (message.mentions.users.first()) {
        target = message.mentions.users.first();
    } else if (args[0]) {
        target = await client.users.fetch(args[0]).catch(() => null);
    }

    if (!target) {
        embed.data.description = "`❌` Vous devez mentionner l'utilisateur à signaler.";
        return message.reply({ embeds: [embed] });
    }

    embed.data.description = "`❌` Vous ne pouvez pas vous signaler vous même.";
    if (target.id === message.author.id) return message.reply({ embeds: [embed] });

    const reason = args.slice(1).join(" ");
    if (!reason) {
        embed.data.description = "`❌` Vous devez expliquer la raison de votre signalement.";
        return message.reply({ embeds: [embed] });
    }

    const reportChannelId = await db.get(`reportchannel_${message.guild.id}`) || await db.get(`modlog_${message.guild.id}`);

    if (!reportChannelId) {
        embed.data.description = "`❌` Le système de signalement n'est pas configuré sur ce serveur. Contactez un administrateur.";
        return message.reply({ embeds: [embed] });
    }

    const channel = message.guild.channels.cache.get(reportChannelId);
    if (!channel || !channel.isTextBased()) {
        embed.data.description = "`❌` Le salon de signalement configuré est introuvable.";
        return message.reply({ embeds: [embed] });
    }

    const reportEmbed = new EmbedBuilder()
        .setColor(0xED4245)
        .setTitle("🚩 Nouveau signalement")
        .addFields(
            { name: "Utilisateur signalé", value: `${target.tag} (\`${target.id}\`)`, inline: true },
            { name: "Signalé par", value: `${message.author.tag} (\`${message.author.id}\`)`, inline: true },
            { name: "Salon", value: `${message.channel}`, inline: true },
            { name: "Raison", value: reason }
        )
        .setTimestamp()
        .setFooter({ text: client.footer, iconURL: client.user.displayAvatarURL() });

    await channel.send({ embeds: [reportEmbed] }).catch(() => {});

    // Delete the report from the origin channel to keep it discreet
    message.delete().catch(() => {});

    const confirmEmbed = client.template;
    confirmEmbed.data.description = "`✅` Votre signalement a bien été transmis au staff.";
    message.channel.send({ embeds: [confirmEmbed] }).then(m => {
        setTimeout(() => m.delete().catch(() => {}), 5000);
    }).catch(() => {});
};
