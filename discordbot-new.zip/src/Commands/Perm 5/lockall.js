const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require("discord.js");

exports.help = {
    name: "lockall",
    description: "Verrouille tous les salons textuels du serveur.",
    aliases: ["lockdown"],
    perms: 5,
};

exports.run = async (client, message) => {
    if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return message.reply({ content: "❌ Permission Administrateur requise.", flags: 64 });
    }

    const guild = message.guild;
    const waitMsg = await message.reply("🔒 **Verrouillage de tous les salons en cours...**");

    let locked = 0;
    let failed = 0;

    for (const [, channel] of guild.channels.cache) {
        if (channel.type !== ChannelType.GuildText) continue;

        const overwrite = channel.permissionOverwrites.cache.get(guild.id);
        if (overwrite && overwrite.deny.has(PermissionFlagsBits.SendMessages)) continue;

        try {
            await channel.permissionOverwrites.edit(guild.id, {
                SendMessages: false,
                AddReactions: false
            }, `LockAll par ${message.author.tag}`);
            locked++;
        } catch (error) {
            failed++;
        }
    }

    const embed = new EmbedBuilder()
        .setTitle("🔒 LockAll terminé")
        .setColor(0xED4245)
        .addFields(
            { name: "Salons verrouillés", value: locked.toString(), inline: true },
            { name: "Échecs", value: failed.toString(), inline: true },
            { name: "Par", value: message.author.toString(), inline: true }
        );

    await waitMsg.edit({ content: null, embeds: [embed] });
};