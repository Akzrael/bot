const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, RoleSelectMenuBuilder } = require("discord.js");

exports.help = {
    name: "massrole",
    description: "Ajoute un rôle à tous les membres du serveur.",
    aliases: ["mrole", "addroleall"],
    usage: "<@role> [raison]",
    perms: 5,
};

exports.run = async (client, message, args) => {
    const role = message.mentions.roles.first();
    if (!role) {
        return message.channel.send("`❌` Rôle invalide.");
    }

    if (role.managed) {
        return message.channel.send("`❌` Impossible d'ajouter un rôle géré par une intégration (bot).");
    }

    if (role.position >= message.guild.members.me.roles.highest.position) {
        return message.channel.send("`❌` Ce rôle est trop haut dans la hiérarchie.");
    }

    const reason = args.slice(1).join(" ") || `MassRole par ${message.author.tag}`;

    const members = message.guild.members.cache.filter(m => !m.user.bot && !m.roles.cache.has(role.id));
    if (members.size === 0) {
        return message.channel.send("`❌` Tous les membres ont déjà ce rôle.");
    }

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("massrole_confirm")
            .setLabel(`✅ Confirmer (${members.size} membres)`)
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId("massrole_cancel")
            .setLabel("❌ Annuler")
            .setStyle(ButtonStyle.Secondary)
    );

    const embed = new EmbedBuilder()
        .setTitle("⚠️ Confirmation MassRole")
        .setColor(0xED4245)
        .setDescription(
            `**Rôle :** ${role}\n` +
            `**Membres concernés :** ${members.size}\n` +
            `**Raison :** ${reason}\n\n` +
            `⚠️ Cette action ajoutera le rôle à **tous** les membres sans ce rôle.`
        );

    const msg = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = msg.createMessageComponentCollector({ time: 30000 });

    collector.on("collect", async interaction => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction.", flags: 64 });
        }

        if (interaction.customId === "massrole_confirm") {
            await interaction.update({ content: "⏳ Ajout du rôle en cours...", components: [], embeds: [] });

            let added = 0;
            let failed = 0;

            for (const [, member] of members) {
                try {
                    await member.roles.add(role, reason);
                    added++;
                    await new Promise(r => setTimeout(r, 100));
                } catch (error) {
                    failed++;
                }
            }

            const resultEmbed = new EmbedBuilder()
                .setTitle("✅ MassRole terminé")
                .setColor(failed === 0 ? 0x57F287 : 0xFAA61A)
                .addFields(
                    { name: "Rôle", value: role.toString(), inline: true },
                    { name: "Ajoutés", value: added.toString(), inline: true },
                    { name: "Échecs", value: failed.toString(), inline: true }
                );

            await interaction.followUp({ embeds: [resultEmbed] });
        } else {
            await interaction.update({ content: "❌ Annulé.", components: [], embeds: [] });
        }
        collector.stop();
    });

    collector.on("end", () => msg.edit({ components: [] }).catch(() => {}));
};