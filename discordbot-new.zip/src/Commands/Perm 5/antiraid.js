const {
    EmbedBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    ActionRowBuilder,
    ComponentType,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require("discord.js");

const db = require("../../../index.js");
const { getVectorConfig, VECTORS, getAllVectors } = require("../../../src/Structure/AntiNuke.js");

exports.help = {
    name: "antiraid",
    description: "Configure le système AntiRaid (protection contre les raids).",
    perms: 5,
};

// Config lives at quick.db key antiraid_<guildId>, shape { enabled, protections: { [vector]: {enabled,threshold,window,action} } }.
// This MUST stay in sync with AntiNuke.js's getVectorConfig(), which reads from the exact same key —
// the config UI writing anywhere else (e.g. the fs-based client.db() store) makes every toggle a no-op.
async function loadConfig(guildId) {
    return await db.get(`antiraid_${guildId}`) || { enabled: false, protections: {} };
}

async function saveConfig(guildId, config) {
    await db.set(`antiraid_${guildId}`, config);
}

exports.run = async (client, message) => {
    const config = await loadConfig(message.guildId);

    const embed = buildMainEmbed(config);
    const components = buildMainComponents();

    const msg = await message.channel.send({ embeds: [embed], components });
    const collector = msg.createMessageComponentCollector({ time: 300000 });

    collector.on("collect", async interaction => {
        if (interaction.user.id !== message.author.id)
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction.", flags: 64 });

        await handleInteraction(client, interaction, message.guildId, msg, message.guild);
    });

    collector.on("end", () => msg.edit({ components: [] }).catch(() => {}));
};

function buildMainEmbed(config) {
    const vectors = getAllVectors();
    const protections = config.protections || {};

    return new EmbedBuilder()
        .setTitle("🛡️ Configuration AntiRaid")
        .setColor(0xED4245)
        .setDescription("Sélectionnez un vecteur à configurer ou activez/désactivez la protection globale.")
        .addFields(
            { name: "Protection Globale", value: config.enabled ? "`✅ Activée`" : "`❌ Désactivée`", inline: true },
            { name: "Vecteurs Configurés", value: vectors.map(v => {
                const p = protections[v];
                return p?.enabled ? `✅ ${v}` : `❌ ${v}`;
            }).join(" | ") || "Aucun", inline: false }
        );
}

function buildMainComponents() {
    const vectors = getAllVectors();
    const options = vectors.map(v => ({
        label: v.replace(/_/g, " "),
        value: `vector_${v}`,
        emoji: getVectorEmoji(v)
    }));

    const chunks = [];
    for (let i = 0; i < options.length; i += 25) {
        chunks.push(options.slice(i, i + 25));
    }

    const rows = chunks.map((chunk, i) => new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId(`antiraid_vector_${i}`)
            .setPlaceholder(`Vecteurs ${i + 1}`)
            .addOptions(chunk)
    ));

    rows.push(new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId("antiraid_global")
            .setPlaceholder("Actions globales")
            .addOptions(
                { label: "Activer/Désactiver la protection globale", value: "toggle_global", emoji: "🔘" }
            )
    ));

    return rows;
}

function getVectorEmoji(vector) {
    const emojis = {
        join_rate: "👥",
        channel_create: "📝",
        channel_delete: "🗑️",
        role_create: "🎭",
        role_delete: "🗑️",
        role_update: "✏️",
        webhook_update: "🪝",
        mass_ban: "🔨",
        mass_kick: "👢",
        anti_invite: "🔗",
        anti_link: "🔗",
        anti_everyone: "📢",
        anti_mention: "📍",
        anti_spam: "💬",
        bot_add: "🤖"
    };
    return emojis[vector] || "⚙️";
}

async function handleInteraction(client, interaction, guildId, msg, guild) {
    if (!interaction.isStringSelectMenu()) return;
    const value = interaction.values[0];

    if (value.startsWith("vector_")) {
        const vector = value.slice(7);
        await showVectorConfig(interaction, guildId, vector, msg, guild);
        return;
    }

    const config = await loadConfig(guildId);

    if (value === "toggle_global") {
        config.enabled = !config.enabled;
        await saveConfig(guildId, config);
        await interaction.update({ embeds: [buildMainEmbed(config)], components: buildMainComponents() });
        return;
    }

    if (value === "back") {
        await interaction.update({ embeds: [buildMainEmbed(config)], components: buildMainComponents() });
        return;
    }

    if (value.startsWith("toggle_")) {
        const vector = value.slice(7);
        config.protections = config.protections || {};
        const p = { ...VECTORS[vector], ...(config.protections[vector] || {}) };
        p.enabled = !p.enabled;
        config.protections[vector] = p;
        await saveConfig(guildId, config);
        await showVectorConfig(interaction, guildId, vector, msg, guild);
        return;
    }

    if (value.startsWith("edit_threshold_")) {
        const vector = value.slice(15);
        await showThresholdModal(interaction, vector);
        return;
    }

    if (value.startsWith("edit_window_")) {
        const vector = value.slice(12);
        await showWindowModal(interaction, vector);
        return;
    }

    if (value.startsWith("edit_action_")) {
        const vector = value.slice(12);
        await showActionSelect(interaction, vector);
        return;
    }
}

async function showVectorConfig(interaction, guildId, vector, msg, guild) {
    const config = await getVectorConfig(guildId, vector);
    const defaults = VECTORS[vector] || {};

    const embed = new EmbedBuilder()
        .setTitle(`🛡️ ${vector.replace(/_/g, " ")}`)
        .setColor(config.enabled ? 0x57F287 : 0xED4245)
        .addFields(
            { name: "Statut", value: config.enabled ? "`✅ Activé`" : "`❌ Désactivé`", inline: true },
            { name: "Seuil", value: `\`${config.threshold}\``, inline: true },
            { name: "Fenêtre", value: `\`${config.window}s\``, inline: true },
            { name: "Action", value: `\`${config.action}\``, inline: true },
            { name: "Défaut", value: `Seuil: ${defaults.threshold} | Fenêtre: ${defaults.window}s | Action: ${defaults.action}`, inline: false }
        );

    const components = [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`antiraid_toggle_${vector}`)
                .setLabel(config.enabled ? "Désactiver" : "Activer")
                .setStyle(config.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
        ),
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`antiraid_editthreshold_${vector}`)
                .setLabel("Modifier seuil")
                .setStyle(ButtonStyle.Primary)
                .setEmoji("🔢"),
            new ButtonBuilder()
                .setCustomId(`antiraid_editwindow_${vector}`)
                .setLabel("Modifier fenêtre")
                .setStyle(ButtonStyle.Primary)
                .setEmoji("⏱️"),
            new ButtonBuilder()
                .setCustomId(`antiraid_editaction_${vector}`)
                .setLabel("Modifier action")
                .setStyle(ButtonStyle.Primary)
                .setEmoji("⚡")
        ),
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("antiraid_back")
                .setLabel("Retour")
                .setStyle(ButtonStyle.Secondary)
        )
    ];

    await interaction.update({ embeds: [embed], components });
}

async function showThresholdModal(interaction, vector) {
    const modal = new ModalBuilder()
        .setCustomId(`antiraid_threshold_${vector}`)
        .setTitle(`Seuil pour ${vector}`.slice(0, 45))
        .addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("threshold")
                    .setLabel("Seuil (nombre d'actions)")
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder("3")
                    .setRequired(true)
                    .setMinLength(1)
                    .setMaxLength(3)
            )
        );
    await interaction.showModal(modal);
}

async function showWindowModal(interaction, vector) {
    const modal = new ModalBuilder()
        .setCustomId(`antiraid_window_${vector}`)
        .setTitle(`Fenêtre pour ${vector}`.slice(0, 45))
        .addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("window")
                    .setLabel("Fenêtre en secondes")
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder("10")
                    .setRequired(true)
                    .setMinLength(1)
                    .setMaxLength(4)
            )
        );
    await interaction.showModal(modal);
}

async function showActionSelect(interaction, vector) {
    const select = new StringSelectMenuBuilder()
        .setCustomId(`antiraid_action_${vector}`)
        .setPlaceholder("Choisir l'action")
        .addOptions(
            { label: "Ban", value: "ban", emoji: "🔨", description: "Bannir l'utilisateur" },
            { label: "Kick", value: "kick", emoji: "👢", description: "Expulser l'utilisateur" },
            { label: "Strip Roles", value: "strip", emoji: "🧹", description: "Retirer tous les rôles" }
        );

    await interaction.update({
        embeds: [new EmbedBuilder().setTitle("Choisir l'action").setColor(0x5865F2)],
        components: [new ActionRowBuilder().addComponents(select)]
    });
}

// Buttons on the per-vector config screen (toggle/edit threshold/edit window/back)
// go through this, since they're plain buttons rather than the top-level select menu.
exports.handleButton = async (client, interaction) => {
    if (!interaction.customId.startsWith("antiraid_")) return;
    const guildId = interaction.guildId;

    if (interaction.customId === "antiraid_back") {
        const config = await loadConfig(guildId);
        return interaction.update({ embeds: [buildMainEmbed(config)], components: buildMainComponents() });
    }

    if (interaction.customId.startsWith("antiraid_toggle_")) {
        const vector = interaction.customId.slice(16);
        const config = await loadConfig(guildId);
        config.protections = config.protections || {};
        const p = { ...VECTORS[vector], ...(config.protections[vector] || {}) };
        p.enabled = !p.enabled;
        config.protections[vector] = p;
        await saveConfig(guildId, config);
        return showVectorConfig(interaction, guildId, vector, null, interaction.guild);
    }

    if (interaction.customId.startsWith("antiraid_editthreshold_")) {
        const vector = interaction.customId.slice(24);
        return showThresholdModal(interaction, vector);
    }

    if (interaction.customId.startsWith("antiraid_editwindow_")) {
        const vector = interaction.customId.slice(21);
        return showWindowModal(interaction, vector);
    }

    if (interaction.customId.startsWith("antiraid_editaction_")) {
        const vector = interaction.customId.slice(21);
        return showActionSelect(interaction, vector);
    }
};

// Handle modal submissions (threshold / window)
exports.handleModal = async (client, interaction) => {
    const guildId = interaction.guildId;

    if (interaction.customId.startsWith("antiraid_threshold_")) {
        const vector = interaction.customId.slice(19);
        const threshold = parseInt(interaction.fields.getTextInputValue("threshold"));
        if (isNaN(threshold) || threshold < 1 || threshold > 100)
            return interaction.reply({ content: "❌ Seuil invalide (1-100).", flags: 64 });

        const config = await loadConfig(guildId);
        config.protections = config.protections || {};
        config.protections[vector] = { ...VECTORS[vector], ...(config.protections[vector] || {}), threshold };
        await saveConfig(guildId, config);
        return interaction.reply({ content: `✅ Seuil mis à jour: ${threshold}`, flags: 64 });
    }

    if (interaction.customId.startsWith("antiraid_window_")) {
        const vector = interaction.customId.slice(16);
        const window = parseInt(interaction.fields.getTextInputValue("window"));
        if (isNaN(window) || window < 1 || window > 3600)
            return interaction.reply({ content: "❌ Fenêtre invalide (1-3600s).", flags: 64 });

        const config = await loadConfig(guildId);
        config.protections = config.protections || {};
        config.protections[vector] = { ...VECTORS[vector], ...(config.protections[vector] || {}), window };
        await saveConfig(guildId, config);
        return interaction.reply({ content: `✅ Fenêtre mise à jour: ${window}s`, flags: 64 });
    }
};

// Handle the action select (ban/kick/strip)
exports.handleSelect = async (client, interaction) => {
    if (!interaction.customId.startsWith("antiraid_action_")) return;

    const guildId = interaction.guildId;
    const vector = interaction.customId.slice(16);
    const action = interaction.values[0];

    const config = await loadConfig(guildId);
    config.protections = config.protections || {};
    config.protections[vector] = { ...VECTORS[vector], ...(config.protections[vector] || {}), action };
    await saveConfig(guildId, config);

    await showVectorConfig(interaction, guildId, vector, null, interaction.guild);
};
