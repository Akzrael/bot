const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType, Message } = require("discord.js");
const antiraidDb = require("../../../index.js");
const { VECTORS, getAllVectors } = require("../../../src/Structure/AntiNuke.js");

exports.help = {
    name: "raidmode",
    description: "Mode panique - verrouille le serveur instantanément.",
    aliases: ["panic", "lockdown", "secur"],
    perms: 5,
};

// The panic-mode buttons are posted as their own standalone message and get
// routed here later by a click, not by the command that posted them — so
// every handler below has to work whether it's driven by a Message (typed
// command) or an Interaction (button click). This pair normalizes that.
function getAuthorId(ctx) {
    return ctx instanceof Message ? ctx.author.id : ctx.user.id;
}

function getAuthorMention(ctx) {
    return ctx instanceof Message ? ctx.author.toString() : ctx.user.toString();
}

async function replyEditable(ctx, options) {
    if (ctx instanceof Message) {
        return await ctx.reply(options);
    }
    if (ctx.deferred || ctx.replied) {
        return await ctx.followUp(options);
    }
    await ctx.reply(options);
    return await ctx.fetchReply();
}

exports.run = async (client, message, args) => {
    const subCommand = args[0];

    if (subCommand === "on" || subCommand === "enable" || subCommand === "activate") {
        await enableRaidMode(client, message);
    } else if (subCommand === "off" || subCommand === "disable" || subCommand === "deactivate") {
        await disableRaidMode(client, message);
    } else if (subCommand === "status") {
        await showStatus(client, message);
    } else {
        const embed = new EmbedBuilder()
            .setTitle("🛡️ Raid Mode (Mode Panique)")
            .setColor(0xED4245)
            .setDescription(
                "**Verrouille instantanément le serveur en cas de raid.**\n\n" +
                "**Sous-commandes :**\n" +
                "`raidmode on` — Active le mode panique\n" +
                "`raidmode off` — Désactive le mode panique\n" +
                "`raidmode status` — Affiche l'état actuel"
            );

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("raidmode_on")
                .setLabel("🔴 ACTIVER MODE PANIQUE")
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId("raidmode_off")
                .setLabel("🟢 DÉSACTIVER")
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId("raidmode_status")
                .setLabel("📊 Statut")
                .setStyle(ButtonStyle.Secondary)
        );

        await message.channel.send({ embeds: [embed], components: [row] });
    }
};

async function enableRaidMode(client, ctx) {
    if (!ctx.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return replyEditable(ctx, { content: "❌ Permission Administrateur requise.", flags: 64 });
    }

    const guild = ctx.guild;
    const db = client.db(guild.id);

    const waitMsg = await replyEditable(ctx, { content: "🔴 **Activation du mode panique en cours...**" });

    try {
        db.raidMode = db.raidMode || {};
        const previousState = {
            channelLocks: [],
            roleLocks: [],
            timestamp: Date.now(),
            activatedBy: getAuthorId(ctx)
        };

        for (const [, channel] of guild.channels.cache) {
            if (channel.type === ChannelType.GuildText) {
                const overwrite = channel.permissionOverwrites.cache.get(guild.id);
                if (overwrite && overwrite.deny.has(PermissionFlagsBits.SendMessages)) continue;

                try {
                    await channel.permissionOverwrites.edit(guild.id, {
                        SendMessages: false,
                        AddReactions: false
                    }, "Raid Mode: Verrouillage");
                    previousState.channelLocks.push(channel.id);
                } catch (error) {}
            }
        }

        const mutedRole = guild.roles.cache.find(r => r.name.toLowerCase().includes("mute") || r.name.toLowerCase().includes("silence"));
        if (mutedRole) {
            for (const [, channel] of guild.channels.cache) {
                if (channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildVoice) {
                    try {
                        await channel.permissionOverwrites.edit(mutedRole.id, {
                            SendMessages: false,
                            Speak: false,
                            Connect: false
                        }, "Raid Mode: Rôle mute");
                        previousState.roleLocks.push({ channel: channel.id, role: mutedRole.id });
                    } catch (error) {}
                }
            }
        }

        db.raidMode.previousState = previousState;
        db.raidMode.active = true;
        client.saveDB();

        // Force-enable every AntiNuke protection vector for the duration of the panic.
        // This has to write to the SAME quick.db key AntiNuke.js reads from
        // (antiraid_<guildId>) — writing to client.db() here would be a silent no-op.
        const raidConfig = await antiraidDb.get(`antiraid_${guild.id}`) || { enabled: false, protections: {} };
        raidConfig.enabled = true;
        raidConfig.protections = raidConfig.protections || {};
        for (const vector of getAllVectors()) {
            raidConfig.protections[vector] = { ...VECTORS[vector], ...(raidConfig.protections[vector] || {}), enabled: true };
        }
        await antiraidDb.set(`antiraid_${guild.id}`, raidConfig);

        const embed = new EmbedBuilder()
            .setTitle("🔴 MODE PANIQUE ACTIVÉ")
            .setColor(0xED4245)
            .setDescription(
                `**Serveur verrouillé par ${getAuthorMention(ctx)}**\n\n` +
                `• ${previousState.channelLocks.length} salons textuels verrouillés\n` +
                `• ${previousState.roleLocks.length} permissions de rôle modifiées\n` +
                `• Toutes les protections AntiNuke activées\n` +
                `• Personne ne peut parler (sauf staff)`
            )
            .setTimestamp();

        await waitMsg.edit({ content: null, embeds: [embed] });

    } catch (error) {
        console.error("[RAIDMODE] Error enabling:", error);
        await waitMsg.edit({ content: "`❌` Erreur lors de l'activation." });
    }
}

async function disableRaidMode(client, ctx) {
    if (!ctx.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return replyEditable(ctx, { content: "❌ Permission Administrateur requise.", flags: 64 });
    }

    const guild = ctx.guild;
    const db = client.db(guild.id);

    if (!db.raidMode?.active) {
        return replyEditable(ctx, { content: "`❌` Le mode panique n'est pas actif.", flags: 64 });
    }

    const waitMsg = await replyEditable(ctx, { content: "🟢 **Désactivation du mode panique en cours...**" });

    try {
        const previousState = db.raidMode.previousState;
        let restored = 0;

        for (const channelId of previousState?.channelLocks || []) {
            const channel = guild.channels.cache.get(channelId);
            if (channel) {
                try {
                    await channel.permissionOverwrites.edit(guild.id, {
                        SendMessages: null,
                        AddReactions: null
                    }, "Raid Mode: Déverrouillage");
                    restored++;
                } catch (error) {}
            }
        }

        for (const lock of previousState?.roleLocks || []) {
            const channel = guild.channels.cache.get(lock.channel);
            const role = guild.roles.cache.get(lock.role);
            if (channel && role) {
                try {
                    await channel.permissionOverwrites.edit(role.id, {
                        SendMessages: null,
                        Speak: null,
                        Connect: null
                    }, "Raid Mode: Déverrouillage rôle");
                } catch (error) {}
            }
        }

        db.raidMode.active = false;
        db.raidMode.previousState = null;
        client.saveDB();

        const embed = new EmbedBuilder()
            .setTitle("🟢 MODE PANIQUE DÉSACTIVÉ")
            .setColor(0x57F287)
            .setDescription(
                `**Serveur déverrouillé par ${getAuthorMention(ctx)}**\n\n` +
                `• ${restored} salons restaurés\n` +
                `• Permissions de rôle restaurées`
            )
            .setTimestamp();

        await waitMsg.edit({ content: null, embeds: [embed] });

    } catch (error) {
        console.error("[RAIDMODE] Error disabling:", error);
        await waitMsg.edit({ content: "`❌` Erreur lors de la désactivation." });
    }
}

async function showStatus(client, ctx) {
    const db = client.db(ctx.guild.id);
    const active = db.raidMode?.active || false;
    const state = db.raidMode?.previousState;

    const embed = new EmbedBuilder()
        .setTitle("📊 Statut Raid Mode")
        .setColor(active ? 0xED4245 : 0x57F287)
        .addFields(
            { name: "État", value: active ? "`🔴 ACTIF`" : "`🟢 INACTIF`", inline: true },
            { name: "Salons verrouillés", value: state?.channelLocks?.length?.toString() || "0", inline: true },
            { name: "Rôles modifiés", value: state?.roleLocks?.length?.toString() || "0", inline: true },
            { name: "Activé par", value: state?.activatedBy ? `<@${state.activatedBy}>` : "Inconnu", inline: true },
            { name: "Depuis", value: state?.timestamp ? `<t:${Math.floor(state.timestamp / 1000)}:R>` : "Inconnu", inline: true }
        );

    await replyEditable(ctx, { embeds: [embed] });
}

module.exports.handleButton = async (client, interaction) => {
    if (!interaction.isButton()) return;
    if (!interaction.customId.startsWith("raidmode_")) return;

    const action = interaction.customId.replace("raidmode_", "");
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: "❌ Permission Administrateur requise.", flags: 64 });
    }

    if (action === "on") await enableRaidMode(client, interaction);
    else if (action === "off") await disableRaidMode(client, interaction);
    else if (action === "status") await showStatus(client, interaction);
};
