const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, RoleSelectMenuBuilder } = require("discord.js");

exports.help = {
    name: "unmassrole",
    description: "Retire un rôle à tous les membres du serveur.",
    aliases: ["umrole", "removeroleall"],
    usage: "<@role> [raison]",
    perms: 5,
};

exports.run = async (client, message, args) => {
    const role = message.mentions.roles.first();
    if (!role) {
        return message.channel.send("`❌` Rôle invalide.");
    }

    if (role.managed) {
        return message.channel.send("`❌` Impossible de retirer un rôle géré par une intégration (bot).");
    }

    if (role.position >= message.guild.members.me.roles.highest.position) {
        return message.channel.send("`❌` Ce rôle est trop haut dans la hiérarchie.");
    }

    const reason = args.slice(1).join(" ") || `UnMassRole par ${message.author.tag}`;

    const members = message.guild.members.cache.filter(m => !m.user.bot && m.roles.cache.has(role.id));
    if (members.size === 0) {
        return message.channel.send("`❌` Aucun membre n'a ce rôle.");
    }

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("unmassrole_confirm")
            .setLabel(`✅ Confirmer (${members.size} membres)`)
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId("unmassrole_cancel")
            .setLabel("❌ Annuler")
            .setStyle(ButtonStyle.Secondary)
    );

    const embed = new EmbedBuilder()
        .setTitle("⚠️ Confirmation UnMassRole")
        .setColor(0xED4245)
        .setDescription(
            `**Rôle :** ${role}\n` +
            `**Membres concernés :** ${members.size}\n` +
            `**Raison :** ${reason}\n\n` +
            `⚠️ Cette action retirera le rôle à **tous** les membres qui l'ont.`
        );

    const msg = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = msg.createMessageComponentCollector({ time: 30000 });

    collector.on("collect", async interaction => {
        if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction.", flags: 64 });
        }

        if (interaction.customId === "unmassrole_confirm") {
            await interaction.update({ content: "⏳ Retrait du rôle en cours...", components: [], embeds: [] });

            let removed = 0;
            let failed = 0;

            for (const [, member] of members) {
                try {
                    await member.roles.remove(role, reason);
                    removed++;
                    await new Promise(r => setTimeout(r, 100));
                } catch (error) {
                    failed++;
                }
            }

            const resultEmbed = new EmbedBuilder()
                .setTitle("✅ UnMassRole terminé")
                .setColor(failed === 0 ? 0x57F287 : 0xFAA61A)
                .addFields(
                    { name: "Rôle", value: role.toString(), inline: true },
                    { name: "Retirés", value: removed.toString(), inline: true },
                    { name: "Échecs", value: failed.toString(), inline: true }
                );

            await interaction.followUp({ embeds: [resultEmbed] });
        } else {
            await interaction.update({ content: "❌ Annulé.", components: [], embeds: [] });
        }
        collector.stop();
    });

    collector.on("end", () => msg.edit({ components: [] }).catch(() => {}));
};