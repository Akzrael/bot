const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require("discord.js");

exports.help = {
    name: "unlockall",
    description: "Déverrouille tous les salons textuels du serveur.",
    aliases: ["unlockdown"],
    perms: 5,
};

exports.run = async (client, message) => {
    if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return message.reply({ content: "❌ Permission Administrateur requise.", flags: 64 });
    }

    const guild = message.guild;
    const waitMsg = await message.reply("🔓 **Déverrouillage de tous les salons en cours...**");

    let unlocked = 0;
    let failed = 0;

    for (const [, channel] of guild.channels.cache) {
        if (channel.type !== ChannelType.GuildText) continue;

        const overwrite = channel.permissionOverwrites.cache.get(guild.id);
        if (!overwrite || (!overwrite.deny.has(PermissionFlagsBits.SendMessages) && !overwrite.deny.has(PermissionFlagsBits.AddReactions))) continue;

        try {
            await channel.permissionOverwrites.edit(guild.id, {
                SendMessages: null,
                AddReactions: null
            }, `UnlockAll par ${message.author.tag}`);
            unlocked++;
        } catch (error) {
            failed++;
        }
    }

    const embed = new EmbedBuilder()
        .setTitle("🔓 UnlockAll terminé")
        .setColor(0x57F287)
        .addFields(
            { name: "Salons déverrouillés", value: unlocked.toString(), inline: true },
            { name: "Échecs", value: failed.toString(), inline: true },
            { name: "Par", value: message.author.toString(), inline: true }
        );

    await waitMsg.edit({ content: null, embeds: [embed] });
};