const {
    EmbedBuilder
  } = require("discord.js")
  const db = require("../../../index.js")
  
  exports.help = {
    name: 'whitelist',
    description: "Te permet de configurer la whitelist du bot.",
    aliases: ["wl"],
    usage: "<add/remove/list/clear/setrole> <user/role || id>",
    example: "add @user",
    perms: 5
  }

  async function ensureWhitelistRole(guild, roleId) {
    let role = roleId ? guild.roles.cache.get(roleId) : null;
    if (!role) {
      role = await guild.roles.create({
        name: "Whitelist",
        color: 0x95a5a6,
        reason: "Rôle créé automatiquement pour la whitelist"
      });
    }
    return role;
  }
  
  exports.run = async (client, message, args) => {
    const embed = client.template
  
    embed.data.description = "`❌` Vous devez spécifier un des arguments suivants: `add`, `remove`, `list`, `clear` et `setrole`."
    if (!args[0]) return message.reply({
      embeds: [embed]
    })
  
    const whitelist = await db.get(`whitelist_${message.guild.id}`) || []
    let roleId = await db.get(`whitelist_role_${message.guild.id}`)
  
    const wlEmbed = new EmbedBuilder()
    wlEmbed.setColor(client.color)
  
    switch (args[0]) {
      case "list":
        wlEmbed.addFields({
          name: "`📝` Liste des membres whitelistés" + (roleId ? ` (rôle lié: <@&${roleId}>)` : ""),
          value: whitelist.map(m => `<@${m}> (\`${m}\`) `).join("\n") || "*Aucun membre n'est whitelisté.*"
        })
  
        message.reply({
          embeds: [wlEmbed]
        })
        break;

      case "setrole":
        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1])

        embed.data.description = "`❌` Vous devez mentionner un rôle après la commande."
        if (!role) return message.reply({ embeds: [embed] })

        await db.set(`whitelist_role_${message.guild.id}`, role.id)
        embed.data.description = `\`✅\` Le rôle ${role} est maintenant lié à la whitelist.`
        message.reply({ embeds: [embed] })
        break;
  
      case "add":
        embed.data.description = "`❌` Vous devez spécifier mentionner un utiilisateur après la commande."
        if (!args[1]) return message.reply({
          embeds: [embed]
        })
  
        let userToWl;
        if (message.mentions.members.first()) {
          userToWl = message.mentions.members.first().user;
        }
        else {
          userToWl = await client.users.fetch(args[1])
        }
        embed.data.description = "`❌` Utilisateur introuvable ou invalde."
        if (!userToWl) return message.reply({
          embeds: [embed]
        })
  
        db.push(`whitelist_${message.guild.id}`, userToWl.id)
        embed.data.description = "`✅` Membre whitelisté avec succès."

        try {
          const wlRole = await ensureWhitelistRole(message.guild, roleId)
          if (wlRole.id !== roleId) {
            roleId = wlRole.id
            await db.set(`whitelist_role_${message.guild.id}`, roleId)
          }
          const memberToWl = message.guild.members.cache.get(userToWl.id)
          if (memberToWl) {
            await memberToWl.roles.add(wlRole)
            embed.data.description += `\n\`ℹ️\` Rôle ${wlRole} attribué.`
          }
        } catch (e) {
          embed.data.description += "\n`⚠️` Je n'ai pas pu créer/attribuer le rôle lié (vérifiez mes permissions)."
        }

        message.reply({
          embeds: [embed]
        })
  
        break;
  
      case "remove":
        embed.data.description = "`❌` Vous devez spécifier mentionner un utiilisateur après la commande."
        if (!args[1]) return message.reply({
          embeds: [embed]
        })
  
        let userToRemove;
        if (message.mentions.members.first()) {
          userToRemove = message.mentions.members.first().user;
        }
        else {
          userToRemove = await client.users.fetch(args[1])
        }
        embed.data.description = "`❌` Utilisateur introuvable ou invalde."
        if (!userToRemove) return message.reply({
          embeds: [embed]
        })
  
        db.pull(`whitelist_${message.guild.id}`, userToRemove.id)
        embed.data.description = "`✅` Membre retiré de la whitelist avec succès."

        if (roleId) {
          const wlRole2 = message.guild.roles.cache.get(roleId)
          const memberToRemove = message.guild.members.cache.get(userToRemove.id)
          if (wlRole2 && memberToRemove && memberToRemove.roles.cache.has(wlRole2.id)) {
            await memberToRemove.roles.remove(wlRole2).catch(() => {
              embed.data.description += "\n`⚠️` Je n'ai pas pu retirer le rôle lié (vérifiez mes permissions/hiérarchie)."
            })
          }
        }

        message.reply({
          embeds: [embed]
        })
  
        break;
  
      case "clear":
        db.delete(`whitelist_${message.guild.id}`)
        embed.data.description = "`✅` Whitelist clear avec succès."
        message.reply({
          embeds: [embed]
        })
  
        break;
    }
  }
