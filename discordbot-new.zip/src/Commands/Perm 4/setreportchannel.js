const db = require("../../../index.js");

exports.help = {
    name: 'setreportchannel',
    aliases: ['reportchannel'],
    description: "Définit le salon qui recevra les signalements (`!report`). Utilise le salon de modlog si non défini.",
    usage: "<#salon/off>",
    example: "#signalements",
    perms: 4,
};

exports.run = async (client, message, args) => {
    const embed = client.template;

    if (!args[0]) {
        embed.data.description = "Vous devez mentionner un salon, ou écrire `off` pour retirer la configuration dédiée.";
        return message.reply({ embeds: [embed] });
    }

    if (args[0] === "off") {
        await db.delete(`reportchannel_${message.guild.id}`);
        embed.data.description = "`✅` Salon de signalement dédié retiré. Les signalements utiliseront le salon de modlog.";
        return message.reply({ embeds: [embed] });
    }

    const channel = message.mentions.channels.first();

    if (!channel || !channel.isTextBased()) {
        embed.data.description = "`❌` Je n'ai pas trouvé ce salon. Mentionnez un salon textuel valide.";
        return message.reply({ embeds: [embed] });
    }

    await db.set(`reportchannel_${message.guild.id}`, channel.id);

    embed.data.description = `\`✅\` Les signalements seront désormais envoyés dans ${channel}.`;
    return message.reply({ embeds: [embed] });
};
