const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    ChannelSelectMenuBuilder,
    ChannelType,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require("discord.js");

exports.help = {
    name: "setconfess",
    description: "Configure le système de confessions anonymes.",
    perms: 4,
};

exports.run = async (client, message) => {
    const db = client.db(message.guildId);
    if (!db.confess) db.confess = {
        enabled: false,
        channel: null,
        dmChannel: null,
        cooldown: 3600,
        requireApproval: false,
        approvalChannel: null,
        blockedWords: []
    };

    const embed = buildEmbed(db, message.guild);
    const components = buildComponents();

    const msg = await message.channel.send({ embeds: [embed], components });
    const collector = msg.createMessageComponentCollector({ time: 300000 });

    collector.on("collect", async interaction => {
        if (interaction.user.id !== message.author.id)
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction.", flags: 64 });

        try {
            await handleInteraction(client, interaction, db, msg, message.guild);
        } catch (error) {
            console.error("[SETCONFESS] Interaction error:", error);
        }
    });

    collector.on("end", () => msg.edit({ components: [] }).catch(() => {}));
};

function buildEmbed(db, guild) {
    const c = db.confess;
    return new EmbedBuilder()
        .setTitle("🤐 Configuration Confessions")
        .setColor(0x5865F2)
        .addFields(
            { name: "Statut", value: c.enabled ? "`✅ Activé`" : "`❌ Désactivé`", inline: true },
            { name: "Salon public", value: c.channel ? `<#${c.channel}>` : "`Non configuré`", inline: true },
            { name: "Salon DM (réception)", value: c.dmChannel ? `<#${c.dmChannel}>` : "`Non configuré`", inline: true },
            { name: "Salon validation", value: c.approvalChannel ? `<#${c.approvalChannel}>` : "`Non configuré`", inline: true },
            { name: "Cooldown", value: `\`${c.cooldown}s\``, inline: true },
            { name: "Validation requise", value: c.requireApproval ? "`✅ Oui`" : "`❌ Non`", inline: true },
            { name: "Mots bloqués", value: c.blockedWords.length > 0 ? c.blockedWords.map(w => `\`${w}\``).join(", ") : "`Aucun`", inline: false }
        );
}

function buildComponents() {
    return [
        new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId("confess_main")
                .setPlaceholder("Choisir une option")
                .addOptions(
                    { label: "Activer/Désactiver", value: "toggle_enabled", emoji: "🔘" },
                    { label: "Salon public", value: "set_channel", emoji: "📝" },
                    { label: "Salon DM (réception)", value: "set_dm_channel", emoji: "📨" },
                    { label: "Salon validation", value: "set_approval_channel", emoji: "✅" },
                    { label: "Cooldown", value: "edit_cooldown", emoji: "⏱️" },
                    { label: "Validation requise", value: "toggle_approval", emoji: "🛡️" },
                    { label: "Ajouter mot bloqué", value: "add_blocked_word", emoji: "➕" },
                    { label: "Supprimer mot bloqué", value: "remove_blocked_word", emoji: "🗑️" },
                    { label: "Poster le panel", value: "post_panel", emoji: "📤" }
                )
        )
    ];
}

async function handleInteraction(client, interaction, db, msg, guild) {
    if (interaction.isStringSelectMenu() && interaction.customId === "confess_main") {
        const value = interaction.values[0];

        if (value === "set_channel" || value === "set_dm_channel" || value === "set_approval_channel") {
            const key = value === "set_channel" ? "channel" : (value === "set_dm_channel" ? "dmChannel" : "approvalChannel");
            await showChannelSelect(interaction, key);
            return;
        }

        if (value === "add_blocked_word") {
            await showBlockedWordModal(client, interaction, db, msg, guild);
            return;
        }

        if (value === "remove_blocked_word") {
            await showRemoveBlockedWordSelect(interaction, db);
            return;
        }

        if (value === "toggle_enabled") {
            db.confess.enabled = !db.confess.enabled;
            client.saveDB();
            await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
            return;
        }

        if (value === "toggle_approval") {
            db.confess.requireApproval = !db.confess.requireApproval;
            client.saveDB();
            await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
            return;
        }

        if (value === "edit_cooldown") {
            await showCooldownModal(client, interaction, db, msg, guild);
            return;
        }

        if (value === "post_panel") {
            await postConfessPanel(client, db, guild, interaction);
            return;
        }

        return;
    }

    if (interaction.isChannelSelectMenu() && interaction.customId.startsWith("confess_channel_")) {
        const key = interaction.customId.replace("confess_channel_", "");
        if (interaction.values[0]) {
            db.confess[key] = interaction.values[0];
            client.saveDB();
        }
        await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        return;
    }

    if (interaction.isStringSelectMenu() && interaction.customId === "remove_blocked_word_select") {
        const index = parseInt(interaction.values[0]);
        db.confess.blockedWords.splice(index, 1);
        client.saveDB();
        await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        return;
    }

    // Modal submissions (confess_cooldown_modal, add_blocked_word_modal) are
    // NOT handled here — see the note in showCooldownModal /
    // showBlockedWordModal below for why.
}

async function showChannelSelect(interaction, key) {
    const { ChannelSelectMenuBuilder, ChannelType } = require("discord.js");
    const selector = new ChannelSelectMenuBuilder()
        .setCustomId(`confess_channel_${key}`)
        .setPlaceholder("Sélectionnez le salon")
        .addChannelTypes(ChannelType.GuildText)
        .setMaxValues(1);

    await interaction.update({
        components: [new ActionRowBuilder().addComponents(selector)]
    });
}

async function showCooldownModal(client, interaction, db, msg, guild) {
    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
    const modal = new ModalBuilder()
        .setCustomId("confess_cooldown_modal")
        .setTitle("Cooldown confessions")
        .addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId("cooldown")
                .setLabel("Secondes (0-86400)")
                .setStyle(TextInputStyle.Short)
                .setPlaceholder("3600")
                .setRequired(true)
        ));
    await interaction.showModal(modal);

    // msg.createMessageComponentCollector() (in exports.run, above) only
    // ever receives MESSAGE_COMPONENT interactions — a modal submission is
    // a completely different interaction type (MODAL_SUBMIT) and is never
    // delivered to that collector. Waiting for it here, right after
    // showModal(), is the only way this submission actually gets picked
    // up.
    const submitted = await interaction.awaitModalSubmit({
        time: 120000,
        filter: i => i.customId === "confess_cooldown_modal" && i.user.id === interaction.user.id
    }).catch(() => null);
    if (!submitted) return;

    const cd = parseInt(submitted.fields.getTextInputValue("cooldown"));
    if (!isNaN(cd) && cd >= 0 && cd <= 86400) {
        db.confess.cooldown = cd;
        client.saveDB();
        await submitted.reply({ content: `✅ Cooldown: ${cd}s`, flags: 64 });
        await msg.edit({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
    } else {
        await submitted.reply({ content: "❌ Valeur invalide (0-86400).", flags: 64 });
    }
}

async function showBlockedWordModal(client, interaction, db, msg, guild) {
    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
    const modal = new ModalBuilder()
        .setCustomId("add_blocked_word_modal")
        .setTitle("Ajouter mot bloqué")
        .addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId("word")
                .setLabel("Mot à bloquer")
                .setStyle(TextInputStyle.Short)
                .setPlaceholder("insulte")
                .setRequired(true)
        ));
    await interaction.showModal(modal);

    const submitted = await interaction.awaitModalSubmit({
        time: 120000,
        filter: i => i.customId === "add_blocked_word_modal" && i.user.id === interaction.user.id
    }).catch(() => null);
    if (!submitted) return;

    const word = submitted.fields.getTextInputValue("word").toLowerCase();
    if (word && !db.confess.blockedWords.includes(word)) {
        db.confess.blockedWords.push(word);
        client.saveDB();
        await submitted.reply({ content: `✅ Mot bloqué ajouté: ${word}`, flags: 64 });
        await msg.edit({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
    } else {
        await submitted.reply({ content: "❌ Mot vide ou déjà bloqué.", flags: 64 });
    }
}

async function showRemoveBlockedWordSelect(interaction, db) {
    if (!db.confess.blockedWords.length) {
        return interaction.reply({ content: "Aucun mot bloqué.", flags: 64 });
    }

    const { StringSelectMenuBuilder, ActionRowBuilder } = require("discord.js");
    const selector = new StringSelectMenuBuilder()
        .setCustomId("remove_blocked_word_select")
        .setPlaceholder("Supprimer un mot bloqué");

    db.confess.blockedWords.forEach((w, i) => {
        selector.addOptions({ label: w, value: i.toString() });
    });

    await interaction.update({
        components: [new ActionRowBuilder().addComponents(selector)]
    });
}

async function postConfessPanel(client, db, guild, interaction) {
    if (!db.confess.channel) {
        return interaction.reply({ content: "❌ Aucun salon public configuré.", flags: 64 });
    }

    const channel = guild.channels.cache.get(db.confess.channel);
    if (!channel) {
        return interaction.reply({ content: "❌ Salon introuvable.", flags: 64 });
    }

    // Reuses the same 📥 button builder that gets attached to every
    // published confession, so the panel and every confession embed all
    // behave identically as entry points.
    const { confessRow } = require("../../Events/Confession/messageCreate.js");

    const embed = new EmbedBuilder()
        .setTitle("🤐 Confessions anonymes")
        .setDescription("Clique sur le bouton ci-dessous pour envoyer une confession anonyme. Ton pseudo n'apparaît jamais publiquement.")
        .setColor(0x5865F2);

    await channel.send({ embeds: [embed], components: [confessRow()] });
    await interaction.reply({ content: "✅ Panel posté !", flags: 64 });
}
