const fs = require('fs');
const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder, PermissionsBitField } = require("discord.js");
const { ComponentType } = require("discord.js"); 
const db = require("../../../index");

exports.help = {
  name: "perms",
  aliases: ["perm"],
  description: "Permet de configurer les permissions.",
  usage: "<add/remove/setrole> <2/3> <user/role>",
  example: "add 3 @sadek",
  perms: 4,
};

const ROLE_DEFAULTS = {
  perms2: {
    name: "Modérateur",
    color: 0x3498db,
    permissions: [
      PermissionsBitField.Flags.KickMembers,
      PermissionsBitField.Flags.ModerateMembers,
      PermissionsBitField.Flags.ManageMessages,
      PermissionsBitField.Flags.ViewAuditLog,
    ]
  },
  perms3: {
    name: "Admin",
    color: 0xe74c3c,
    permissions: [
      PermissionsBitField.Flags.KickMembers,
      PermissionsBitField.Flags.BanMembers,
      PermissionsBitField.Flags.ModerateMembers,
      PermissionsBitField.Flags.ManageMessages,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.ViewAuditLog,
    ]
  }
}

// Récupère le rôle lié à une permission, en le créant automatiquement s'il n'existe pas encore
// (ou s'il a été supprimé depuis).
async function ensureRole(guild, tier, roles) {
  const key = `perms${tier}`;
  let role = roles[key] ? guild.roles.cache.get(roles[key]) : null;

  if (!role) {
    const defaults = ROLE_DEFAULTS[key];
    role = await guild.roles.create({
      name: defaults.name,
      color: defaults.color,
      permissions: defaults.permissions,
      reason: `Rôle créé automatiquement pour la permission ${tier}`
    });
    roles[key] = role.id;
  }

  return role;
}

exports.run = async (client, message, args) => {

  const commands = client.commands
    
    const temp = client.template

    let wl = await db.get(`whitelist_${message.guild.id}`)
    let owner = await message.guild.fetchOwner();
    let data = await db.get(`perms_${message.guild.id}`) || { perms2: [], perms3: []}
    let roles = await db.get(`perms_roles_${message.guild.id}`) || { perms2: null, perms3: null }

    if (args[0] == "setrole") {
      const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])

      temp.data.description = "`❌` Vous devez mentionner un rôle après la commande."
      if (!role) return message.reply({ embeds: [temp] })

      if (args[1] !== "2" && args[1] !== "3") {
        temp.data.description = "`❌` Vous devez spécifier une des permissions suivantes: `2` & `3`."
        return message.reply({ embeds: [temp] })
      }

      if (message.member.roles.highest.position <= role.position && message.guild.ownerId !== message.author.id) {
        temp.data.description = "`❌` Ce rôle est hiérarchiquement supérieur ou égal au vôtre."
        return message.reply({ embeds: [temp] })
      }

      roles[`perms${args[1]}`] = role.id
      await db.set(`perms_roles_${message.guild.id}`, roles)

      temp.data.description = `\`✅\` Le rôle ${role} est maintenant lié à la permission ${args[1]}.`
      return message.reply({ embeds: [temp] })
    }

    if(args[0] == "add") {
      let member = message.mentions.members.first() || message.guild.members.cache.get(args[2])

      temp.data.description = "`❌` Vous devez mentionner quelqu'un après la commande."
      if(!member) return message.reply({ embeds: [temp] })

      switch (args[1]) {
        case "5":
        case "4":
        case "1": 

        temp.data.description = "`❌` Ces permissions ne sont pas configurables !"
        return message.reply({ embeds: [temp] })

          break;
        case "2":
          
        if(data.perms2.includes(member.id)) {
          temp.data.description = "`❌` Cette personne figure déjà dans la permission 2 !"
          return message.reply({ embeds: [temp] })
        }

        data.perms2.push(member.id)
        await db.set(`perms_${message.guild.id}`, { perms2: data.perms2, perms3: data.perms3 })

        temp.data.description = "`✅` Utilisateur ajouté à la permission 2."
        try {
          const role2 = await ensureRole(message.guild, "2", roles)
          await db.set(`perms_roles_${message.guild.id}`, roles)
          await member.roles.add(role2)
          temp.data.description += `\n\`ℹ️\` Rôle ${role2} attribué.`
        } catch (e) {
          temp.data.description += "\n`⚠️` Je n'ai pas pu créer/attribuer le rôle lié (vérifiez mes permissions)."
        }
        return message.reply({ embeds: [temp] })

        break;


        case "3":
          
          if(data.perms3.includes(member.id)) {
            temp.data.description = "`❌` Cette personne figure déjà dans la permission 3 !"
            return message.reply({ embeds: [temp] })
          }

          data.perms3.push(member.id)
          await db.set(`perms_${message.guild.id}`, { perms3: data.perms3, perms2: data.perms2 })

          temp.data.description = "`✅` Utilisateur ajouté à la permission 3."
          try {
            const role3 = await ensureRole(message.guild, "3", roles)
            await db.set(`perms_roles_${message.guild.id}`, roles)
            await member.roles.add(role3)
            temp.data.description += `\n\`ℹ️\` Rôle ${role3} attribué.`
          } catch (e) {
            temp.data.description += "\n`⚠️` Je n'ai pas pu créer/attribuer le rôle lié (vérifiez mes permissions)."
          }
          return message.reply({ embeds: [temp] })

          break;

        default:
          temp.data.description = "`❌` Vous devez spécifiier une des permmissions suivantes: `2` & `3`."
          return message.reply({ embeds: [temp]})
          break;
      
      }
  } else if(args[0] == "remove" || args[0] == "del" || args[0] == "delete")  {
    let member = message.mentions.members.first() || message.guild.members.cache.get(args[2])

      temp.data.description = "`❌` Vous devez mentionner quelqu'un après la commande."
      if(!member) return message.reply({ embeds: [temp] })

    switch (args[1]) {

      case "5":
        case "4":
        case "1": 

        temp.data.description = "`❌` Ces permissions ne sont pas configurables !"
        return message.reply({ embeds: [temp] })

          break;
        case "2":
          
        if(!data.perms2.includes(member.id)) {
          temp.data.description = "`❌` Cette personne ne figure pas dans la permission 2 !"
          return message.reply({ embeds: [temp] })
        }

        data.perms2.splice(data.perms2.indexOf(member.id), 1);
        await db.set(`perms_${message.guild.id}`, { perms2: data.perms2, perms3: data.perms3 })

        temp.data.description = "`✅` Utilisateur retiré de la permission 2."
        if (roles.perms2) {
          const role2r = message.guild.roles.cache.get(roles.perms2)
          if (role2r && member.roles.cache.has(role2r.id)) {
            await member.roles.remove(role2r).catch(() => {
              temp.data.description += "\n`⚠️` Je n'ai pas pu retirer le rôle lié (vérifiez mes permissions/hiérarchie)."
            })
          }
        }
        return message.reply({ embeds: [temp] })

        break;


        case "3":
          
          if(!data.perms3.includes(member.id)) {
            temp.data.description = "`❌` Cette personne ne figure pas dans la permission 3 !"
            return message.reply({ embeds: [temp] })
          }

          data.perms3.splice(data.perms2.indexOf(member.id), 1);
          await db.set(`perms_${message.guild.id}`, { perms3: data.perms3, perms2: data.perms2 })

          temp.data.description = "`✅` Utilisateur retiré de la permission 3."
          if (roles.perms3) {
            const role3r = message.guild.roles.cache.get(roles.perms3)
            if (role3r && member.roles.cache.has(role3r.id)) {
              await member.roles.remove(role3r).catch(() => {
                temp.data.description += "\n`⚠️` Je n'ai pas pu retirer le rôle lié (vérifiez mes permissions/hiérarchie)."
              })
            }
          }
          return message.reply({ embeds: [temp] })

          break;

        default:
          temp.data.description = "`❌` Vous devez spécifiier une des permmissions suivantes: `2` & `3`."
          return message.reply({ embeds: [temp]})
        break;

    }
    
  } else {
    const embed = new EmbedBuilder()
    .setDescription(`Utilisez \`${client.prefix}help [nom de la commande]\` pour plus d'informations sur une commande spécifique.\nLes rôles Modérateur/Admin sont créés automatiquement au premier \`${client.prefix}perms add\`. Utilisez \`${client.prefix}perms setrole <2/3> @role\` pour utiliser un rôle existant à la place.`)
    .addFields(
        { name: "Perm 1 (Public) ", value: commands.filter(cmd => cmd.help.perms == 1 ).map(cmd => `\`${cmd.help.name}\``).join(" - ") + "\n\n@everyone" },
        { name: "Perm 2 (Modérateur) " + (roles.perms2 ? `— <@&${roles.perms2}>` : "— *rôle pas encore créé*"), value: commands.filter(cmd => cmd.help.perms == 2).map(cmd => `\`${cmd.help.name}\``).join(" - ") + "\n\n" + ( data && data.perms2 && data.perms2.length > 0 ? ("<@"+ data.perms2.join(">\n<@") + ">") : "*Personne*") },
        { name: "Perm 3 (Admin) " + (roles.perms3 ? `— <@&${roles.perms3}>` : "— *rôle pas encore créé*"), value: commands.filter(cmd => cmd.help.perms == 3).map(cmd => `\`${cmd.help.name}\``).join(" - ") + "\n\n" + ( data && data.perms3 && data.perms3.length > 0 ? ("<@"+ data.perms3.join(">\n<@") + ">") : "*Personne*") },
        { name: "Perm 4 (Whitelist) ", value: commands.filter(cmd => cmd.help.perms == 4).map(cmd => `\`${cmd.help.name}\``).join(" - ") + "\n\n" + (wl && wl.length > 0 ? ("<@" + wl.join(">\n<@") + ">") : "*Personne*")},
        { name: "Perm 5 (Owner) ", value: commands.filter(cmd => cmd.help.perms == 5).map(cmd => `\`${cmd.help.name}\``).join(" - ") + `\n\n${owner.user}`}
        ) 
    .setFooter({
      text: client.footer,
      iconURL: client.user.displayAvatarURL()
    })
    .setTimestamp()
    .setColor(client.color);
    


    message.reply({ embeds: [embed]});

  }

}
