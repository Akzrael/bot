const { EmbedBuilder, ActionRowBuilder, ChannelSelectMenuBuilder, ChannelType, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, RoleSelectMenuBuilder } = require("discord.js");

exports.help = {
    name: 'modmail',
    description: "Configuration du système modmail. Utilisez `block`/`unblock` <@user> pour gérer les utilisateurs bloqués.",
    usage: "[block/unblock] <user>",
    perms: 4,
}

exports.run = async (client, message, args) => {
    const db = client.db(message.guildId);
    if (!db.modmail)
        db.modmail = {
            enabled: false,
            afkDelete: false,
            afkTime: 24,
            globalStaff: [],
            options: [],
            claimSystem: false,
            transcripts: false,
            transcriptChannel: null,
            blockedUsers: [],
            activeThreads: {},
            activeChannels: []
        };

    if (args[0] === "block" || args[0] === "unblock") {
        const user = message.mentions.users.first() || await client.users.fetch(args[1]).catch(() => null);
        if (!user) return message.channel.send("`❌` Utilisateur introuvable.");

        if (!db.modmail.blockedUsers) db.modmail.blockedUsers = [];

        if (args[0] === "block") {
            if (db.modmail.blockedUsers.includes(user.id))
                return message.channel.send(`❌ ${user} est déjà bloqué du modmail.`);

            db.modmail.blockedUsers.push(user.id);
            client.saveDB();

            const embed = new EmbedBuilder()
                .setTitle("✅ Utilisateur bloqué")
                .setDescription(`${user.tag} a été bloqué du système modmail.`)
                .setColor(0xff0000)
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        }

        if (args[0] === "unblock") {
            if (!db.modmail.blockedUsers.includes(user.id))
                return message.channel.send(`❌ ${user.tag} n'est pas bloqué du modmail.`);

            db.modmail.blockedUsers = db.modmail.blockedUsers.filter(id => id !== user.id);
            client.saveDB();

            const embed = new EmbedBuilder()
                .setTitle("✅ Utilisateur débloqué")
                .setDescription(`${user.tag} a été débloqué du système modmail.`)
                .setColor(0x00ff00)
                .setTimestamp();

            return message.channel.send({ embeds: [embed] });
        }
    }

    const embed = this.createMainEmbed(db, message.guild);
    const components = this.createMainComponents();

    const msg = await message.channel.send({ embeds: [embed], components });
    const collector = msg.createMessageComponentCollector({ time: 1000 * 60 * 10 });

    collector.on('end', () => msg.edit({ components: [] }));
    collector.on('collect', async interaction => {

        if (interaction.user.id !== message.author.id)
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction", flags: 64 });

        this.handleInteraction(client, interaction, db, msg, message.guild);

    });
}

exports.createMainEmbed = (db, guild) => {
        return new EmbedBuilder()
            .setTitle("Configuration du Modmail")
            .setColor(0xffffff)
            .addFields(
                { name: "Modmail Actif", value: db.modmail.enabled ? "`✅`" : "`❌`", inline: true },
                { name: "Supprimer si aucune réponse", value: db.modmail.afkDelete ? "`✅`" : "`❌`", inline: true },
                { name: "Temps AFK", value: `\`${db.modmail.afkTime}h\``, inline: true },
                { name: "Système Claim", value: db.modmail.claimSystem ? "`✅`" : "`❌`", inline: true },
                { name: "Transcripts", value: db.modmail.transcripts ? "`✅`" : "`❌`", inline: true },
                { name: "Salon Transcripts", value: db.modmail.transcriptChannel ? `<#${db.modmail.transcriptChannel}>` : "`❌`", inline: true },
                { name: "Staff Global", value: db.modmail.globalStaff.length > 0 ? db.modmail.globalStaff.map(id => `<@&${id}>`).join(', ') : "`❌`", inline: true },
                { name: "Options", value: db.modmail.options.length > 0 ? db.modmail.options.map(opt => `${opt.emoji || '📧'} **${opt.name}**`).join('\n') : "`❌`", inline: true }
            );
};


exports.createMainComponents = () => {
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('modmail_main')
            .setPlaceholder('Sélectionnez une option')
            .addOptions([
                {
                    label: 'Activer/Désactiver le modmail',
                    value: 'toggle_modmail',
                    emoji: '🔘'
                },
                {
                    label: 'Activer/Désactiver le système AFK',
                    value: 'toggle_afk',
                    emoji: '🚪'
                },
                {
                    label: 'Modifier le temps d\'AFK',
                    value: 'edit_afk_time',
                    emoji: '⏰'
                },
                {
                    label: 'Activer/Désactiver le système Claim',
                    value: 'toggle_claim',
                    emoji: '🔒'
                },
                {
                    label: 'Activer/Désactiver les transcripts',
                    value: 'toggle_transcripts',
                    emoji: '📄'
                },
                {
                    label: 'Définir le salon des transcripts',
                    value: 'set_transcript_channel',
                    emoji: '📁'
                },
                {
                    label: 'Supprimer le salon transcript',
                    value: 'remove_transcript_channel',
                    emoji: '🗑️'
                },
                {
                    label: 'Ajouter un rôle staff global',
                    value: 'add_global_staff',
                    emoji: '👮'
                },
                {
                    label: 'Supprimer les rôles staff globaux',
                    value: 'remove_global_staff',
                    emoji: '🗑️'
                },
                {
                    label: 'Ajouter une option',
                    value: 'add_option',
                    emoji: '➕'
                },
                {
                    label: 'Modifier une option',
                    value: 'edit_option',
                    emoji: '✏️'
                },
                {
                    label: 'Supprimer une option',
                    value: 'delete_option',
                    emoji: '➖'
                }
            ]);

        return [new ActionRowBuilder().addComponents(selectMenu)];
};


exports.handleInteraction = async (client, interaction, db, msg, guild) => {
        if (interaction.isButton()) {
            await interaction.deferUpdate();

            if (interaction.customId === 'back_to_main')
                return await this.updateMainMessage(msg, db, guild);
        }

        if (interaction.isRoleSelectMenu()) {
            await interaction.deferUpdate();

            if (interaction.customId === 'global_staff_selector') {

                db.modmail.globalStaff = interaction.values;
                client.saveDB();

                return this.updateMainMessage(msg, db, guild);
            }

            if (interaction.customId.startsWith('option_staff_')) {
                const optionIndex = parseInt(interaction.customId.split('_')[2]);

                db.modmail.options[optionIndex].staff = interaction.values;
                client.saveDB();

                return this.showOptionConfig(msg, db, optionIndex, guild);
            }

            if (interaction.customId.startsWith('option_allowed_')) {

                const optionIndex = parseInt(interaction.customId.split('_')[2]);
                db.modmail.options[optionIndex].allowedRoles = interaction.values;
                client.saveDB();

                return this.showOptionConfig(msg, db, optionIndex, guild);
            }

            if (interaction.customId.startsWith('option_blocked_')) {

                const optionIndex = parseInt(interaction.customId.split('_')[2]);

                db.modmail.options[optionIndex].blockedRoles = interaction.values;
                client.saveDB();

                return this.showOptionConfig(msg, db, optionIndex, guild);
            }
        }

        if (interaction.isChannelSelectMenu()) {
            if (interaction.customId.startsWith('option_category_')) {

                const optionIndex = parseInt(interaction.customId.split('_')[2]);
                await interaction.deferUpdate();

                db.modmail.options[optionIndex].category = interaction.values[0];
                client.saveDB();

                return this.showOptionConfig(msg, db, optionIndex, guild);
            }

            if (interaction.customId === 'transcript_channel_selector') {

                db.modmail.transcriptChannel = interaction.values[0];
                client.saveDB();

                return this.updateMainMessage(msg, db, guild);

            }
        }

        if (interaction.isModalSubmit()) {
            if (interaction.customId === 'afk_time_modal') {
                const afkTime = parseInt(interaction.fields.getTextInputValue('afk_time'));

                if (isNaN(afkTime) || afkTime < 1)
                    return interaction.reply({ content: '❌ Veuillez entrer un nombre valide (minimum 1 heure).', flags: 64 });

                db.modmail.afkTime = afkTime;
                client.saveDB();

                await interaction.reply({ content: `✅ Temps AFK modifié à ${afkTime} heures.`, flags: 64 });
                await this.updateMainMessage(msg, db, guild);
                return;
            }

            if (interaction.customId === 'add_option_modal') {
                const optionName = interaction.fields.getTextInputValue('option_name');
                const optionEmoji = interaction.fields.getTextInputValue('option_emoji') || null;

                if (!db.modmail.options) db.modmail.options = [];

                const newOption = {
                    name: optionName,
                    emoji: optionEmoji,
                    category: null,
                    staff: [],
                    allowedRoles: [],
                    blockedRoles: []
                };

                db.modmail.options.push(newOption);
                client.saveDB();

                await interaction.reply({ content: `✅ Option "${optionName}" ajoutée avec succès.`, flags: 64 });

                const optionIndex = db.modmail.options.length - 1;
                await this.showOptionConfig(msg, db, optionIndex, guild);
                return;
            }

            if (interaction.customId.startsWith('edit_name_modal_')) {
                const optionIndex = parseInt(interaction.customId.split('_')[3]);
                const newName = interaction.fields.getTextInputValue('option_name');

                db.modmail.options[optionIndex].name = newName;
                client.saveDB();

                await interaction.reply({ content: `✅ Nom de l'option modifié en "${newName}".`, flags: 64 });
                await this.showOptionConfig(msg, db, optionIndex, guild);
                return;
            }

            if (interaction.customId.startsWith('edit_emoji_modal_')) {
                const optionIndex = parseInt(interaction.customId.split('_')[3]);
                const newEmoji = interaction.fields.getTextInputValue('option_emoji');

                db.modmail.options[optionIndex].emoji = newEmoji;
                client.saveDB();

                await interaction.reply({ content: `✅ Emoji de l'option modifié en ${newEmoji}.`, flags: 64 });
                await this.showOptionConfig(msg, db, optionIndex, guild);
                return;
            }
        }

        if (!interaction.isStringSelectMenu()) return;
        if (!interaction.values || !interaction.values[0]) return;

        const value = interaction.values[0];

        if (value === 'edit_afk_time' || value === 'add_option' || value === 'edit_name' || value === 'edit_emoji') {
            switch (value) {
                case 'edit_afk_time':
                    await this.showAfkTimeModal(interaction);
                    break;
                case 'add_option':
                    await this.showAddOptionModal(interaction);
                    break;
                case 'edit_name':
                    const optionIndex1 = parseInt(interaction.customId.split('_')[2]);
                    await this.showEditNameModal(interaction, optionIndex1);
                    break;
                case 'edit_emoji':
                    const optionIndex2 = parseInt(interaction.customId.split('_')[2]);
                    await this.showEditEmojiModal(interaction, optionIndex2);
                    break;
            }
            return;
        }

        await interaction.deferUpdate();

        switch (value) {
            case 'toggle_modmail':
                db.modmail.enabled = !db.modmail.enabled;
                client.saveDB();
                await this.updateMainMessage(msg, db, guild);
                break;

            case 'toggle_afk':
                db.modmail.afkDelete = !db.modmail.afkDelete;
                client.saveDB();
                await this.updateMainMessage(msg, db, guild);
                break;

            case 'toggle_claim':
                db.modmail.claimSystem = !db.modmail.claimSystem;
                client.saveDB();
                await this.updateMainMessage(msg, db, guild);
                break;

            case 'toggle_transcripts':
                db.modmail.transcripts = !db.modmail.transcripts;
                client.saveDB();
                await this.updateMainMessage(msg, db, guild);
                break;

            case 'remove_transcript_channel':
                db.modmail.transcriptChannel = null;
                client.saveDB();
                await this.updateMainMessage(msg, db, guild);
                break;

            case 'set_transcript_channel':
                await this.showTranscriptChannelSelector(msg);
                break;

            case 'add_global_staff':
                await this.showGlobalStaffSelector(msg);
                break;

            case 'remove_global_staff':
                db.modmail.globalStaff = [];
                client.saveDB();
                await this.updateMainMessage(msg, db, guild);
                break;

            case 'edit_option':
                await this.showEditOptionSelector(msg, db);
                break;

            case 'delete_option':
                await this.showDeleteOptionSelector(msg, db);
                break;

            case 'back_to_main':
                await this.updateMainMessage(msg, db, guild);
                break;

            case 'edit_category':
                const optionIndex3 = parseInt(interaction.customId.split('_')[2]);
                await this.showCategorySelector(msg, optionIndex3);
                break;

            case 'remove_category':
                const optionIndex4 = parseInt(interaction.customId.split('_')[2]);
                db.modmail.options[optionIndex4].category = null;
                client.saveDB();
                await this.showOptionConfig(msg, db, optionIndex4, guild);
                break;

            case 'edit_staff':
                const optionIndex5 = parseInt(interaction.customId.split('_')[2]);
                await this.showStaffSelector(msg, optionIndex5);
                break;

            case 'remove_staff':
                const optionIndex6 = parseInt(interaction.customId.split('_')[2]);
                db.modmail.options[optionIndex6].staff = [];
                client.saveDB();
                await this.showOptionConfig(msg, db, optionIndex6, guild);
                break;

            case 'remove_emoji':
                const optionIndex7 = parseInt(interaction.customId.split('_')[2]);
                db.modmail.options[optionIndex7].emoji = null;
                client.saveDB();
                await this.showOptionConfig(msg, db, optionIndex7, guild);
                break;

            case 'edit_allowed':
                const optionIndex8 = parseInt(interaction.customId.split('_')[2]);
                await this.showAllowedRolesSelector(msg, optionIndex8);
                break;

            case 'remove_allowed':
                const optionIndex9 = parseInt(interaction.customId.split('_')[2]);
                db.modmail.options[optionIndex9].allowedRoles = [];
                client.saveDB();
                await this.showOptionConfig(msg, db, optionIndex9, guild);
                break;

            case 'edit_blocked':
                const optionIndex10 = parseInt(interaction.customId.split('_')[2]);
                await this.showBlockedRolesSelector(msg, optionIndex10);
                break;

            case 'remove_blocked':
                const optionIndex11 = parseInt(interaction.customId.split('_')[2]);
                db.modmail.options[optionIndex11].blockedRoles = [];
                client.saveDB();
                await this.showOptionConfig(msg, db, optionIndex11, guild);
                break;

            default:
                if (value.startsWith('edit_option_')) {
                    const optionIndex = parseInt(value.split('_')[2]);
                    await this.showOptionConfig(msg, db, optionIndex, guild);
                } else if (value.startsWith('delete_option_')) {
                    const optionIndex = parseInt(value.split('_')[2]);
                    db.modmail.options.splice(optionIndex, 1);
                    client.saveDB();
                    await this.updateMainMessage(msg, db, guild);
                }
                break;
        }
};


exports.updateMainMessage = async (msg, db, guild) => {
        const embed = this.createMainEmbed(db, guild);
        const components = this.createMainComponents();
        await msg.edit({ embeds: [embed], components });
};


exports.showAfkTimeModal = async (interaction) => {
        const modal = new ModalBuilder()
            .setCustomId('afk_time_modal')
            .setTitle('Modifier le temps AFK')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('afk_time')
                        .setLabel('Temps AFK en heures')
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder('24')
                        .setRequired(true)
                )
            );

        await interaction.showModal(modal);
};


exports.showEditNameModal = async (interaction, optionIndex) => {
        const modal = new ModalBuilder()
            .setCustomId(`edit_name_modal_${optionIndex}`)
            .setTitle('Modifier le nom de l\'option')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('option_name')
                        .setLabel('Nouveau nom de l\'option')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)
                )
            );

        await interaction.showModal(modal);
};


exports.showEditEmojiModal = async (interaction, optionIndex) => {
        const modal = new ModalBuilder()
            .setCustomId(`edit_emoji_modal_${optionIndex}`)
            .setTitle('Modifier l\'emoji de l\'option')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('option_emoji')
                        .setLabel('Nouvel emoji de l\'option')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)
                )
            );

        await interaction.showModal(modal);
};


exports.showGlobalStaffSelector = async (msg) => {
        const selector = new RoleSelectMenuBuilder()
            .setCustomId('global_staff_selector')
            .setPlaceholder('Sélectionnez les rôles staff globaux')
            .setMaxValues(10);

        const row = new ActionRowBuilder().addComponents(selector);

        const embed = new EmbedBuilder()
            .setTitle('Sélection des rôles staff globaux')
            .setDescription('Sélectionnez les rôles qui auront accès à tous les modmails.\n\n💡 **Astuce:** Utilisez l\'option "Supprimer les rôles staff globaux" dans le menu principal pour les retirer.')
            .setColor(0xffffff);

        await msg.edit({
            embeds: [embed],
            components: [row]
        });
};


exports.showAddOptionModal = async (interaction) => {
        const modal = new ModalBuilder()
            .setCustomId('add_option_modal')
            .setTitle('Ajouter une option')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('option_name')
                        .setLabel('Nom de l\'option')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('option_emoji')
                        .setLabel('Emoji de l\'option (optionnel)')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(false)
                )
            );

        await interaction.showModal(modal);
};


exports.showEditOptionSelector = async (msg, db) => {
        if (db.modmail.options.length === 0) {
            const embed = new EmbedBuilder()
                .setTitle('Aucune option')
                .setDescription('Aucune option n\'est configurée.')
                .setColor(0xff0000);

            const backButton = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('back_to_main')
                    .setLabel('Retour')
                    .setStyle(ButtonStyle.Secondary)
            );

            return msg.edit({ embeds: [embed], components: [backButton] });
        }

        const selector = new StringSelectMenuBuilder()
            .setCustomId('edit_option_selector')
            .setPlaceholder('Sélectionnez une option à modifier');

        db.modmail.options.forEach((option, index) => {
            selector.addOptions({
                label: option.name,
                value: `edit_option_${index}`,
                emoji: option.emoji || '📧'
            });
        });

        selector.addOptions({
            label: 'Retour',
            value: 'back_to_main',
        });

        const row = new ActionRowBuilder().addComponents(selector);

        const embed = new EmbedBuilder()
            .setTitle('Modifier une option')
            .setDescription('Veuillez sélectionner une option')
            .setColor(0xffffff);

        await msg.edit({ embeds: [embed], components: [row] });
};


exports.showDeleteOptionSelector = async (msg, db) => {
        if (db.modmail.options.length === 0) {
            const embed = new EmbedBuilder()
                .setTitle('Aucune option')
                .setDescription('Aucune option n\'est configurée.')
                .setColor(0xff0000);

            const backButton = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('back_to_main')
                    .setLabel('Retour')
                    .setStyle(ButtonStyle.Secondary)
            );

            return msg.edit({ embeds: [embed], components: [backButton] });
        }

        const selector = new StringSelectMenuBuilder()
            .setCustomId('delete_option_selector')
            .setPlaceholder('Sélectionnez une option à supprimer');

        db.modmail.options.forEach((option, index) => {
            selector.addOptions({
                label: option.name,
                value: `delete_option_${index}`,
                emoji: option.emoji || '📧'
            });
        });

        selector.addOptions({
            label: 'Retour',
            value: 'back_to_main',
        });

        const row = new ActionRowBuilder().addComponents(selector);

        const embed = new EmbedBuilder()
            .setTitle('Supprimer une option')
            .setDescription('Veuillez sélectionner une option')
            .setColor(0xff0000);

        await msg.edit({ embeds: [embed], components: [row] });
};


exports.showOptionConfig = async (msg, db, optionIndex, guild) => {
        const option = db.modmail.options[optionIndex];
        if (!option) return;

        const embed = new EmbedBuilder()
            .setTitle(`Configuration de l'option: ${option.name}`)
            .setColor(0xffffff)
            .addFields(
                { name: "Nom de l'option", value: `\`${option.name}\``, inline: true },
                { name: "Catégorie de l'option", value: option.category ? `<#${option.category}>` : "`❌`", inline: true },
                { name: "Emoji de l'option", value: option.emoji || "`None`", inline: true },
                { name: "Staff de l'option", value: option.staff && option.staff.length > 0 ? option.staff.map(id => `<@&${id}>`).join(', ') : "`❌`", inline: true },
                { name: "Rôles autorisés", value: option.allowedRoles && option.allowedRoles.length > 0 ? option.allowedRoles.map(id => `<@&${id}>`).join(', ') : "`Tous`", inline: true },
                { name: "Rôles interdits", value: option.blockedRoles && option.blockedRoles.length > 0 ? option.blockedRoles.map(id => `<@&${id}>`).join(', ') : "`Aucun`", inline: true }
            );

        const selector = new StringSelectMenuBuilder()
            .setCustomId(`option_config_${optionIndex}`)
            .setPlaceholder('Modifier les paramètres')
            .addOptions([
                { label: 'Modifier le nom', value: 'edit_name', emoji: '✏️' },
                { label: 'Modifier l\'emoji', value: 'edit_emoji', emoji: '😀' },
                { label: 'Supprimer l\'emoji', value: 'remove_emoji', emoji: '🗑️' },
                { label: 'Modifier la catégorie', value: 'edit_category', emoji: '📁' },
                { label: 'Supprimer la catégorie', value: 'remove_category', emoji: '🗑️' },
                { label: 'Modifier les rôles staff', value: 'edit_staff', emoji: '👮' },
                { label: 'Supprimer les rôles staff', value: 'remove_staff', emoji: '🗑️' },
                { label: 'Modifier les rôles autorisés', value: 'edit_allowed', emoji: '✅' },
                { label: 'Supprimer les rôles autorisés', value: 'remove_allowed', emoji: '🗑️' },
                { label: 'Modifier les rôles interdits', value: 'edit_blocked', emoji: '❌' },
                { label: 'Supprimer les rôles interdits', value: 'remove_blocked', emoji: '🗑️' },
                { label: 'Retour', value: 'back_to_main' }
            ]);

        const row = new ActionRowBuilder().addComponents(selector);

        await msg.edit({ embeds: [embed], components: [row] });
};


exports.showCategorySelector = async (msg, optionIndex) => {
        const selector = new ChannelSelectMenuBuilder()
            .setCustomId(`option_category_${optionIndex}`)
            .setPlaceholder('Sélectionnez une catégorie')
            .addChannelTypes(ChannelType.GuildCategory);

        const row = new ActionRowBuilder().addComponents(selector);

        const embed = new EmbedBuilder()
            .setTitle('Sélection de la catégorie')
            .setDescription('Sélectionnez la catégorie où les tickets de cette option seront créés.')
            .setColor(0xffffff);

        await msg.edit({ embeds: [embed], components: [row] });
};


exports.showStaffSelector = async (msg, optionIndex) => {
        const selector = new RoleSelectMenuBuilder()
            .setCustomId(`option_staff_${optionIndex}`)
            .setPlaceholder('Sélectionnez les rôles staff')
            .setMaxValues(10);

        const row = new ActionRowBuilder().addComponents(selector);

        const embed = new EmbedBuilder()
            .setTitle('Sélection des rôles staff')
            .setDescription('Sélectionnez les rôles qui auront accès aux tickets de cette option.')
            .setColor(0xffffff);

        await msg.edit({ embeds: [embed], components: [row] });
};


exports.showAllowedRolesSelector = async (msg, optionIndex) => {
        const selector = new RoleSelectMenuBuilder()
            .setCustomId(`option_allowed_${optionIndex}`)
            .setPlaceholder('Sélectionnez les rôles autorisés')
            .setMaxValues(10);

        const row = new ActionRowBuilder().addComponents(selector);

        const embed = new EmbedBuilder()
            .setTitle('Sélection des rôles autorisés')
            .setDescription('Sélectionnez les rôles autorisés à utiliser cette option. Si aucun rôle n\'est sélectionné, tous les membres pourront l\'utiliser.')
            .setColor(0xffffff);

        await msg.edit({ embeds: [embed], components: [row] });
};


exports.showBlockedRolesSelector = async (msg, optionIndex) => {
        const selector = new RoleSelectMenuBuilder()
            .setCustomId(`option_blocked_${optionIndex}`)
            .setPlaceholder('Sélectionnez les rôles interdits')
            .setMaxValues(10);

        const row = new ActionRowBuilder().addComponents(selector);

        const embed = new EmbedBuilder()
            .setTitle('Sélection des rôles interdits')
            .setDescription('Sélectionnez les rôles qui ne pourront pas utiliser cette option.')
            .setColor(0xffffff);

        await msg.edit({ embeds: [embed], components: [row] });
};


exports.showTranscriptChannelSelector = async (msg) => {
        const selector = new ChannelSelectMenuBuilder()
            .setCustomId('transcript_channel_selector')
            .setPlaceholder('Sélectionnez le salon des transcripts')
            .addChannelTypes(ChannelType.GuildText);

        const row = new ActionRowBuilder().addComponents(selector);

        const embed = new EmbedBuilder()
            .setTitle('Sélection du salon des transcripts')
            .setDescription('Sélectionnez le salon où les transcripts des modmails seront envoyés.')
            .setColor(0xffffff);

        await msg.edit({ embeds: [embed], components: [row] });
};

