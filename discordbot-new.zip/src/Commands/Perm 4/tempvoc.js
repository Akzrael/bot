const {
    EmbedBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    ActionRowBuilder,
    ComponentType,
    ChannelType,
    ButtonBuilder,
    ButtonStyle
} = require("discord.js");

const db = require("../../../index.js");

exports.help = {
    name: "tempvoc",
    aliases: ["tv", "tempvoice", "jointocreate", "j2c"],
    description: "Configure le système de salons vocaux temporaires (TempVoc).",
    perms: 4,
};

exports.run = async (client, message) => {
    const guild = message.guild;
    const guildId = guild.id;

    async function getData() {
        return await db.get(`tempvoc_${guildId}`) || {
            triggerChannel: null,
            category: null,
            name: "🔊・{username}"
        };
    }

    async function saveData(data) {
        await db.set(`tempvoc_${guildId}`, data);
    }

    function getChannel(id) {
        if (!id) return null;
        return guild.channels.cache.get(id) || null;
    }

    function buildEmbed(data) {
        const trigger = getChannel(data.triggerChannel);
        const category = getChannel(data.category);

        return new EmbedBuilder()
            .setColor(client.color || 0xffffff)
            .setTitle("🎙️ TempVoc - Salons Vocaux Temporaires")
            .setDescription(
                "Configurez votre système **TempVoc** avec le menu ci-dessous.\n" +
                "Les membres rejoignent le salon déclencheur → un salon privé est créé (et ils y sont déplacés) → le panneau de contrôle est envoyé directement dans ce salon vocal."
            )
            .addFields(
                {
                    name: "🎙️ Salon déclencheur",
                    value: trigger ? `${trigger}` : "`Non configuré`",
                    inline: true
                },
                {
                    name: "📁 Catégorie",
                    value: category ? `${category}` : "`Non configurée`",
                    inline: true
                },
                {
                    name: "✏️ Nom des salons",
                    value: `\`${data.name || "🔊・{username}"}\``,
                    inline: false
                },
                {
                    name: "Variables disponibles",
                    value:
                        "`{username}` → nom Discord\n" +
                        "`{displayname}` → pseudo du serveur",
                    inline: false
                }
            );
    }

    function buildMenu(msgId) {
        return new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId(`tempvoc_${msgId}`)
                .setPlaceholder("Choisissez une option")
                .addOptions(
                    new StringSelectMenuOptionBuilder()
                        .setLabel("Modifier le salon déclencheur")
                        .setDescription("Le salon vocal que les membres rejoignent pour créer leur salon")
                        .setValue("trigger")
                        .setEmoji("🎙️"),

                    new StringSelectMenuOptionBuilder()
                        .setLabel("Modifier la catégorie")
                        .setDescription("Catégorie où les salons temporaires seront créés")
                        .setValue("category")
                        .setEmoji("📁"),

                    new StringSelectMenuOptionBuilder()
                        .setLabel("Modifier le nom")
                        .setDescription("Nom des salons temporaires (avec variables)")
                        .setValue("name")
                        .setEmoji("✏️"),

                    new StringSelectMenuOptionBuilder()
                        .setLabel("Actualiser")
                        .setDescription("Rafraîchit l'affichage de la configuration")
                        .setValue("refresh")
                        .setEmoji("🔄"),

                    new StringSelectMenuOptionBuilder()
                        .setLabel("Réinitialiser tout")
                        .setDescription("Supprime toute la configuration TempVoc")
                        .setValue("reset")
                        .setEmoji("🗑️")
                )
        );
    }

    let data = await getData();

    const msg = await message.channel.send({
        embeds: [buildEmbed(data)],
        components: [buildMenu(message.id)]
    });

    await msg.edit({
        components: [buildMenu(msg.id)]
    });

    const collector = msg.createMessageComponentCollector({
        componentType: ComponentType.StringSelect,
        time: 300000,
        filter: interaction =>
            interaction.user.id === message.author.id
    });

    collector.on("collect", async interaction => {
        try {
            const choice = interaction.values[0];

            if (choice === "refresh") {
                data = await getData();
                return interaction.update({
                    embeds: [buildEmbed(data)],
                    components: [buildMenu(msg.id)]
                });
            }

            if (choice === "reset") {
                await db.delete(`tempvoc_${guildId}`);
                await db.delete(`tempvoc_temp_${guildId}`);
                await db.delete(`tempvoc_owners_${guildId}`);
                data = await getData();

                return interaction.update({
                    embeds: [buildEmbed(data)],
                    components: [buildMenu(msg.id)]
                });
            }

            await interaction.deferUpdate();

            if (choice === "trigger") {
                const question = await message.channel.send(
                    "🎙️ **Quel salon vocal doit servir de déclencheur ?**\n\n" +
                    "Mentionnez le salon vocal ou envoyez son ID.\n" +
                    "Tapez `annuler` pour annuler."
                );

                const collected = await message.channel.awaitMessages({
                    filter: m => m.author.id === message.author.id,
                    max: 1,
                    time: 60000
                });

                await question.delete().catch(() => {});

                if (!collected.size) return;

                const answer = collected.first();

                if (answer.content.trim().toLowerCase() === "annuler") {
                    await answer.delete().catch(() => {});
                    return;
                }

                const channel =
                    answer.mentions.channels.first() ||
                    guild.channels.cache.get(answer.content.trim());

                await answer.delete().catch(() => {});

                if (!channel || channel.type !== ChannelType.GuildVoice) {
                    const error = await message.channel.send(
                        "`❌` Vous devez sélectionner un **salon vocal**."
                    );

                    setTimeout(() => {
                        error.delete().catch(() => {});
                    }, 5000);

                    return;
                }

                data.triggerChannel = channel.id;
                await saveData(data);

                await msg.edit({
                    embeds: [buildEmbed(data)],
                    components: [buildMenu(msg.id)]
                });

                return;
            }

            if (choice === "category") {
                const question = await message.channel.send(
                    "📁 **Quelle catégorie doit contenir les salons temporaires ?**\n\n" +
                    "Mentionnez la catégorie ou envoyez son ID.\n" +
                    "Tapez `annuler` pour annuler."
                );

                const collected = await message.channel.awaitMessages({
                    filter: m => m.author.id === message.author.id,
                    max: 1,
                    time: 60000
                });

                await question.delete().catch(() => {});

                if (!collected.size) return;

                const answer = collected.first();

                if (answer.content.trim().toLowerCase() === "annuler") {
                    await answer.delete().catch(() => {});
                    return;
                }

                const category =
                    answer.mentions.channels.first() ||
                    guild.channels.cache.get(answer.content.trim());

                await answer.delete().catch(() => {});

                if (!category || category.type !== ChannelType.GuildCategory) {
                    const error = await message.channel.send(
                        "`❌` Ce n'est pas une **catégorie Discord** valide.\n\n" +
                        "Mentionnez directement la **catégorie**."
                    );

                    setTimeout(() => {
                        error.delete().catch(() => {});
                    }, 5000);

                    return;
                }

                data.category = category.id;
                await saveData(data);

                await msg.edit({
                    embeds: [buildEmbed(data)],
                    components: [buildMenu(msg.id)]
                });

                return;
            }

            if (choice === "name") {
                const question = await message.channel.send(
                    "✏️ **Quel sera le nom des salons temporaires ?**\n\n" +
                    "Exemple : `🔊・{username}`\n\n" +
                    "Variables :\n" +
                    "`{username}` → nom Discord\n" +
                    "`{displayname}` → pseudo serveur\n\n" +
                    "Tapez `annuler` pour annuler."
                );

                const collected = await message.channel.awaitMessages({
                    filter: m => m.author.id === message.author.id,
                    max: 1,
                    time: 60000
                });

                await question.delete().catch(() => {});

                if (!collected.size) return;

                const answer = collected.first();

                if (answer.content.trim().toLowerCase() === "annuler") {
                    await answer.delete().catch(() => {});
                    return;
                }

                const name = answer.content.trim();

                await answer.delete().catch(() => {});

                if (!name || name.length > 100) {
                    const error = await message.channel.send(
                        "`❌` Le nom doit contenir entre 1 et 100 caractères."
                    );

                    setTimeout(() => {
                        error.delete().catch(() => {});
                    }, 5000);

                    return;
                }

                data.name = name;
                await saveData(data);

                await msg.edit({
                    embeds: [buildEmbed(data)],
                    components: [buildMenu(msg.id)]
                });

                return;
            }

        } catch (error) {
            console.error("[TEMPVOC CONFIG ERROR]", error);

            try {
                if (interaction.deferred || interaction.replied) {
                    await interaction.followUp({
                        content: "`❌` Une erreur est survenue.",
                        ephemeral: true
                    });
                }
            } catch {}
        }
    });

    collector.on("end", async () => {
        try {
            await msg.edit({
                components: []
            });
        } catch {}
    });
};
