const { EmbedBuilder } = require("discord.js");
const db = require("../../../index.js");

exports.help = {
    name: "setinvites",
    description: "Ajoute/retire des invitations bonus à un membre (staff).",
    usage: "<@user> <add/remove/set> <nombre>",
    example: "@Sadek add 5",
    perms: 4,
};

exports.run = async (client, message, args) => {
    const target = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!target) {
        return message.channel.send("`❌` Utilisateur introuvable.");
    }

    const action = args[1];
    const amount = parseInt(args[2]);
    if (!action || isNaN(amount)) {
        return message.channel.send("`❌` Usage: `!setinvites @user <add/remove/set> <nombre>`");
    }

    const key = `invites_${message.guild.id}_${target.id}`;
    const data = await db.get(key) || { regular: 0, leaves: 0, fake: 0, bonus: 0 };

    if (action === "add") {
        data.bonus = (data.bonus || 0) + amount;
    } else if (action === "remove") {
        data.bonus = Math.max(0, (data.bonus || 0) - amount);
    } else if (action === "set") {
        data.bonus = amount;
    } else {
        return message.channel.send("`❌` Action invalide: add, remove ou set.");
    }

    await db.set(key, data);

    const total = (data.regular || 0) - (data.leaves || 0) + (data.bonus || 0);
    const embed = new EmbedBuilder()
        .setTitle("✅ Invitations bonus modifiées")
        .setColor(0x57F287)
        .addFields(
            { name: "Membre", value: target.tag, inline: true },
            { name: "Action", value: `${action} ${amount}`, inline: true },
            { name: "Bonus total", value: data.bonus.toString(), inline: true },
            { name: "Total invitations", value: total.toString(), inline: true }
        );

    await message.channel.send({ embeds: [embed] });
};
