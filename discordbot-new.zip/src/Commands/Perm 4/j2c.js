// j2c.js is now a pure alias of tempvoc.js.
//
// Previously this was a full second implementation with its own config key
// (j2c_<guild>) and its own aliases ("j2c", "jointocreate") that collided
// with tempvoc.js's aliases (which already listed "j2c"/"jointocreate" too).
// Command lookup resolves aliases by scanning file-load order, so typing
// "!j2c" almost always landed on THIS file instead of tempvoc.js — meaning
// whichever command a person thought they were configuring, they were
// often silently writing to a config the actual channel-creation engine
// (Events/J2C/voiceStateUpdate.js) either did or didn't read from,
// depending on which one won. That's the "they overwrite themselves" bug.
//
// Now there is exactly one config (tempvoc_<guild>) and exactly one run
// function. No matter which name or alias someone types, they configure
// and see the same system.
const tempvoc = require("./tempvoc.js");

exports.help = {
    name: "jointocreate",
    aliases: ["j2c", "j2", "tempvoc", "tv", "tempvoice"],
    description: "Alias de /tempvoc — configure le système de salons vocaux temporaires (Join To Create / TempVoc).",
    perms: 4,
};

exports.run = tempvoc.run;
