const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require("discord.js");

exports.help = {
    name: "setlevel",
    description: "Configure le système de niveaux/XP.",
    perms: 4,
};

exports.run = async (client, message) => {
    const db = client.db(message.guildId);
    if (!db.level) db.level = {
        enabled: false,
        xpPerMessage: 15,
        xpCooldown: 60,
        ignoredChannels: [],
        ignoredRoles: [],
        roleRewards: [],
        levelUpMessage: true,
        levelUpChannel: null
    };

    const embed = buildEmbed(db, message.guild);
    const components = buildComponents();

    const msg = await message.channel.send({ embeds: [embed], components });
    const collector = msg.createMessageComponentCollector({ time: 300000 });

    collector.on("collect", async interaction => {
        if (interaction.user.id !== message.author.id)
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction.", flags: 64 });

        try {
            await handleInteraction(client, interaction, db, msg, message.guild);
        } catch (error) {
            console.error("[SETLEVEL] Interaction error:", error);
        }
    });

    collector.on("end", () => msg.edit({ components: [] }).catch(() => {}));
};

function buildEmbed(db, guild) {
    const l = db.level;
    const rewards = l.roleRewards?.length > 0
        ? l.roleRewards.map(r => `${r.level} → <@&${r.roleId}>`).join("\n")
        : "Aucun";

    return new EmbedBuilder()
        .setTitle("⚙️ Configuration Niveaux/XP")
        .setColor(0x5865F2)
        .addFields(
            { name: "Statut", value: l.enabled ? "`✅ Activé`" : "`❌ Désactivé`", inline: true },
            { name: "XP par message", value: `\`${l.xpPerMessage}\``, inline: true },
            { name: "Cooldown", value: `\`${l.xpCooldown}s\``, inline: true },
            { name: "Salons ignorés", value: l.ignoredChannels.length > 0 ? l.ignoredChannels.map(c => `<#${c}>`).join(", ") : "`Aucun`", inline: true },
            { name: "Rôles ignorés", value: l.ignoredRoles.length > 0 ? l.ignoredRoles.map(r => `<@&${r}>`).join(", ") : "`Aucun`", inline: true },
            { name: "Message level up", value: l.levelUpMessage ? "`✅`" : "`❌`", inline: true },
            { name: "Salon level up", value: l.levelUpChannel ? `<#${l.levelUpChannel}>` : "`Défaut`", inline: true },
            { name: "Récompenses de rôle", value: rewards, inline: false }
        );
}

function buildComponents() {
    return [
        new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId("level_main")
                .setPlaceholder("Choisir une option")
                .addOptions(
                    { label: "Activer/Désactiver", value: "toggle_enabled", emoji: "🔘" },
                    { label: "XP par message", value: "edit_xp", emoji: "✨" },
                    { label: "Cooldown (secondes)", value: "edit_cooldown", emoji: "⏱️" },
                    { label: "Salons ignorés", value: "edit_ignored_channels", emoji: "🚫" },
                    { label: "Rôles ignorés", value: "edit_ignored_roles", emoji: "🎭" },
                    { label: "Message level up", value: "toggle_levelup_msg", emoji: "📢" },
                    { label: "Salon level up", value: "edit_levelup_channel", emoji: "📝" },
                    { label: "Ajouter récompense", value: "add_reward", emoji: "➕" },
                    { label: "Supprimer récompense", value: "remove_reward", emoji: "🗑️" }
                )
        )
    ];
}

async function handleInteraction(client, interaction, db, msg, guild) {
    if (interaction.isStringSelectMenu() && interaction.customId === "level_main") {
        const value = interaction.values[0];

        if (value === "edit_ignored_channels") {
            await showChannelSelect(interaction, "ignoredChannels");
            return;
        }
        if (value === "edit_ignored_roles") {
            await showRoleSelect(interaction, "ignoredRoles");
            return;
        }
        if (value === "edit_levelup_channel") {
            await showChannelSelect(interaction, "levelUpChannel", true);
            return;
        }
        if (value === "add_reward") {
            await showRewardModal(interaction);
            return;
        }
        if (value === "remove_reward") {
            await showRemoveRewardSelect(interaction, db);
            return;
        }

        // Same bug as setconfess.js / setrules.js: these were unreachable
        // because the handler always returned above the switch that used
        // to sit at the bottom of this function.
        if (value === "toggle_enabled") {
            db.level.enabled = !db.level.enabled;
            client.saveDB();
            await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
            return;
        }
        if (value === "toggle_levelup_msg") {
            db.level.levelUpMessage = !db.level.levelUpMessage;
            client.saveDB();
            await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
            return;
        }
        if (value === "edit_xp") {
            await showXpModal(interaction);
            return;
        }
        if (value === "edit_cooldown") {
            await showCooldownModal(interaction);
            return;
        }

        return;
    }

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith("level_channel_")) {
        const key = interaction.customId.replace("level_channel_", "");
        if (interaction.values[0]) {
            if (key === "levelUpChannel") {
                db.level[key] = interaction.values[0];
            } else {
                if (!db.level[key].includes(interaction.values[0])) {
                    db.level[key].push(interaction.values[0]);
                }
            }
        }
        client.saveDB();
        await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        return;
    }

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith("level_role_")) {
        const key = interaction.customId.replace("level_role_", "");
        if (!db.level[key].includes(interaction.values[0])) {
            db.level[key].push(interaction.values[0]);
        }
        client.saveDB();
        await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        return;
    }

    if (interaction.isStringSelectMenu() && interaction.customId === "remove_reward_select") {
        const index = parseInt(interaction.values[0]);
        db.level.roleRewards.splice(index, 1);
        client.saveDB();
        // Was msg.edit()-ing without ever acknowledging the interaction —
        // Discord showed "This interaction failed" even though it worked.
        await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        return;
    }

    if (interaction.isModalSubmit() && interaction.customId === "level_xp_modal") {
        const xp = parseInt(interaction.fields.getTextInputValue("xp"));
        if (!isNaN(xp) && xp > 0 && xp <= 100) {
            db.level.xpPerMessage = xp;
            client.saveDB();
            await interaction.reply({ content: `✅ XP par message: ${xp}`, flags: 64 });
            await msg.edit({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        } else {
            await interaction.reply({ content: "❌ Valeur invalide (1-100).", flags: 64 });
        }
        return;
    }

    if (interaction.isModalSubmit() && interaction.customId === "level_cooldown_modal") {
        const cd = parseInt(interaction.fields.getTextInputValue("cooldown"));
        if (!isNaN(cd) && cd >= 0 && cd <= 3600) {
            db.level.xpCooldown = cd;
            client.saveDB();
            await interaction.reply({ content: `✅ Cooldown: ${cd}s`, flags: 64 });
            await msg.edit({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        } else {
            await interaction.reply({ content: "❌ Valeur invalide (0-3600).", flags: 64 });
        }
        return;
    }

    if (interaction.isModalSubmit() && interaction.customId === "add_reward_modal") {
        const level = parseInt(interaction.fields.getTextInputValue("level"));
        const roleId = interaction.fields.getTextInputValue("role").replace(/[<@&>]/g, "");
        if (!isNaN(level) && level > 0 && level <= 100 && guild.roles.cache.has(roleId)) {
            if (!db.level.roleRewards) db.level.roleRewards = [];
            db.level.roleRewards.push({ level, roleId });
            db.level.roleRewards.sort((a, b) => a.level - b.level);
            client.saveDB();
            await interaction.reply({ content: `✅ Récompense ajoutée: Niveau ${level} → <@&${roleId}>`, flags: 64 });
            await msg.edit({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        } else {
            await interaction.reply({ content: "❌ Niveau ou rôle invalide.", flags: 64 });
        }
        return;
    }
}

async function showChannelSelect(interaction, key, single = false) {
    const { ChannelSelectMenuBuilder, ChannelType } = require("discord.js");
    const selector = new ChannelSelectMenuBuilder()
        .setCustomId(`level_channel_${key}`)
        .setPlaceholder(`Sélectionnez ${single ? "le salon" : "les salons"}`)
        .addChannelTypes(ChannelType.GuildText)
        .setMaxValues(single ? 1 : 10);

    await interaction.update({
        components: [new ActionRowBuilder().addComponents(selector)]
    });
}

async function showRoleSelect(interaction, key) {
    const { RoleSelectMenuBuilder } = require("discord.js");
    const selector = new RoleSelectMenuBuilder()
        .setCustomId(`level_role_${key}`)
        .setPlaceholder("Sélectionnez les rôles")
        .setMaxValues(10);

    await interaction.update({
        components: [new ActionRowBuilder().addComponents(selector)]
    });
}

async function showXpModal(interaction) {
    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
    const modal = new ModalBuilder()
        .setCustomId("level_xp_modal")
        .setTitle("XP par message")
        .addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId("xp")
                .setLabel("XP (1-100)")
                .setStyle(TextInputStyle.Short)
                .setPlaceholder("15")
                .setRequired(true)
        ));
    await interaction.showModal(modal);
}

async function showCooldownModal(interaction) {
    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
    const modal = new ModalBuilder()
        .setCustomId("level_cooldown_modal")
        .setTitle("Cooldown XP")
        .addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId("cooldown")
                .setLabel("Secondes (0-3600)")
                .setStyle(TextInputStyle.Short)
                .setPlaceholder("60")
                .setRequired(true)
        ));
    await interaction.showModal(modal);
}

async function showRewardModal(interaction) {
    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
    const modal = new ModalBuilder()
        .setCustomId("add_reward_modal")
        .setTitle("Ajouter récompense de rôle")
        .addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("level")
                    .setLabel("Niveau requis (1-100)")
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder("5")
                    .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("role")
                    .setLabel("ID ou mention du rôle")
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder("@Rôle ou 123456789")
                    .setRequired(true)
            )
        );
    await interaction.showModal(modal);
}

async function showRemoveRewardSelect(interaction, db) {
    if (!db.level.roleRewards?.length) {
        return interaction.reply({ content: "Aucune récompense configurée.", flags: 64 });
    }

    const { StringSelectMenuBuilder, ActionRowBuilder } = require("discord.js");
    const selector = new StringSelectMenuBuilder()
        .setCustomId("remove_reward_select")
        .setPlaceholder("Supprimer une récompense");

    db.level.roleRewards.forEach((r, i) => {
        selector.addOptions({ label: `Niveau ${r.level} → <@&${r.roleId}>`, value: i.toString() });
    });

    await interaction.update({
        components: [new ActionRowBuilder().addComponents(selector)]
    });
}
