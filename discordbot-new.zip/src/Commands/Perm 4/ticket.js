const {
    EmbedBuilder, ActionRowBuilder, ChannelSelectMenuBuilder, ChannelType,
    StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, RoleSelectMenuBuilder
} = require("discord.js");

exports.help = {
    name: 'ticket',
    description: "Configuration du système de tickets.",
    perms: 4,
}

function ensureDb(db) {
    if (!db.ticket) {
        db.ticket = {
            enabled: false,
            category: null,
            staffRoles: [],
            claimSystem: false,
            panelChannel: null,
            counter: 0,
            activeTickets: {}
        };
    }
    if (db.ticket.claimSystem === undefined) db.ticket.claimSystem = false;
    return db.ticket;
}

exports.run = async (client, message, args) => {
    const db = client.db(message.guildId);
    ensureDb(db);

    if (args[0] === "panel") {
        const channel = message.mentions.channels.first() || message.channel;

        if (!db.ticket.category) {
            return message.channel.send("`❌` Configurez d'abord une catégorie avec le menu `!ticket` avant de poster le panel.");
        }

        const panelEmbed = new EmbedBuilder()
            .setColor(client.color || 0x2f3136)
            .setTitle("🎫 Support")
            .setDescription("Cliquez sur le bouton ci-dessous pour ouvrir un ticket avec le staff.\nUne fenêtre s'ouvrira pour saisir la raison de votre ticket.")
            .setFooter({ text: client.footer, iconURL: client.user.displayAvatarURL() });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("ticket_create_panel")
                .setLabel("Créer un ticket")
                .setStyle(ButtonStyle.Primary)
                .setEmoji("🎫")
        );

        await channel.send({ embeds: [panelEmbed], components: [row] });
        return message.channel.send(`\`✅\` Panel de tickets posté dans ${channel}.`);
    }

    const embed = this.createMainEmbed(db, message.guild);
    const components = this.createMainComponents();

    const msg = await message.channel.send({ embeds: [embed], components });
    const collector = msg.createMessageComponentCollector({ time: 1000 * 60 * 10 });

    collector.on('end', () => msg.edit({ components: [] }).catch(() => {}));
    collector.on('collect', async interaction => {
        if (interaction.user.id !== message.author.id)
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction", flags: 64 });

        this.handleInteraction(client, interaction, db, msg, message.guild);
    });
}

exports.createMainEmbed = (db, guild) => {
    return new EmbedBuilder()
        .setTitle("Configuration des Tickets")
        .setColor(0xffffff)
        .addFields(
            { name: "Système Actif", value: db.ticket.enabled ? "`✅`" : "`❌`", inline: true },
            { name: "Catégorie", value: db.ticket.category ? `<#${db.ticket.category}>` : "`❌`", inline: true },
            { name: "Système Claim", value: db.ticket.claimSystem ? "`✅`" : "`❌`", inline: true },
            { name: "Rôles Staff", value: db.ticket.staffRoles.length > 0 ? db.ticket.staffRoles.map(id => `<@&${id}>`).join(', ') : "`❌`", inline: true },
            { name: "Tickets ouverts", value: `\`${Object.keys(db.ticket.activeTickets || {}).length}\``, inline: true }
        )
        .setFooter({ text: "Utilisez `!ticket panel [#salon]` pour poster le panel de création." });
};

exports.createMainComponents = () => {
    const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('ticket_main')
        .setPlaceholder('Sélectionnez une option')
        .addOptions([
            { label: 'Activer/Désactiver les tickets', value: 'toggle_ticket', emoji: '🔘' },
            { label: 'Définir la catégorie', value: 'set_category', emoji: '📁' },
            { label: 'Activer/Désactiver le système Claim', value: 'toggle_claim', emoji: '🔒' },
            { label: 'Ajouter des rôles staff', value: 'set_staff', emoji: '👮' },
            { label: 'Supprimer les rôles staff', value: 'remove_staff', emoji: '🗑️' },
        ]);

    return [new ActionRowBuilder().addComponents(selectMenu)];
};

exports.handleInteraction = async (client, interaction, db, msg, guild) => {
    ensureDb(db);

    if (interaction.isRoleSelectMenu()) {
        await interaction.deferUpdate();

        if (interaction.customId === 'ticket_staff_selector') {
            db.ticket.staffRoles = interaction.values;
            client.saveDB();
            return this.updateMainMessage(msg, db, guild);
        }
    }

    if (interaction.isChannelSelectMenu()) {
        if (interaction.customId === 'ticket_category_selector') {
            await interaction.deferUpdate();
            db.ticket.category = interaction.values[0];
            client.saveDB();
            return this.updateMainMessage(msg, db, guild);
        }
    }

    if (!interaction.isStringSelectMenu()) return;
    const value = interaction.values[0];

    if (value === 'set_category') {
        const selector = new ChannelSelectMenuBuilder()
            .setCustomId('ticket_category_selector')
            .setPlaceholder('Sélectionnez la catégorie des tickets')
            .addChannelTypes(ChannelType.GuildCategory);

        return msg.edit({ components: [new ActionRowBuilder().addComponents(selector)] });
    }

    if (value === 'set_staff') {
        const selector = new RoleSelectMenuBuilder()
            .setCustomId('ticket_staff_selector')
            .setPlaceholder('Sélectionnez les rôles staff')
            .setMaxValues(10);

        return msg.edit({ components: [new ActionRowBuilder().addComponents(selector)] });
    }

    await interaction.deferUpdate();

    switch (value) {
        case 'toggle_ticket':
            db.ticket.enabled = !db.ticket.enabled;
            client.saveDB();
            await this.updateMainMessage(msg, db, guild);
            break;

        case 'toggle_claim':
            db.ticket.claimSystem = !db.ticket.claimSystem;
            client.saveDB();
            await this.updateMainMessage(msg, db, guild);
            break;

        case 'remove_staff':
            db.ticket.staffRoles = [];
            client.saveDB();
            await this.updateMainMessage(msg, db, guild);
            break;
    }
};

exports.updateMainMessage = async (msg, db, guild) => {
    const embed = this.createMainEmbed(db, guild);
    const components = this.createMainComponents();
    await msg.edit({ embeds: [embed], components });
};