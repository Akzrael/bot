const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    ChannelSelectMenuBuilder,
    ChannelType,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require("discord.js");

exports.help = {
    name: "setrules",
    description: "Configure le panel de règles avec boutons d'acceptation.",
    perms: 4,
};

exports.run = async (client, message) => {
    const db = client.db(message.guildId);
    if (!db.rules) db.rules = {
        enabled: false,
        channel: null,
        rules: [],
        roleOnAccept: null,
        dmOnAccept: false
    };

    const embed = buildEmbed(db, message.guild);
    const components = buildComponents();

    const msg = await message.channel.send({ embeds: [embed], components });
    const collector = msg.createMessageComponentCollector({ time: 300000 });

    collector.on("collect", async interaction => {
        if (interaction.user.id !== message.author.id)
            return interaction.reply({ content: "Vous ne pouvez pas utiliser cette interaction.", flags: 64 });

        try {
            await handleInteraction(client, interaction, db, msg, message.guild);
        } catch (error) {
            console.error("[SETRULES] Interaction error:", error);
        }
    });

    collector.on("end", () => msg.edit({ components: [] }).catch(() => {}));
};

function buildEmbed(db, guild) {
    const r = db.rules;
    return new EmbedBuilder()
        .setTitle("📜 Configuration Règles")
        .setColor(0x5865F2)
        .addFields(
            { name: "Statut", value: r.enabled ? "`✅ Activé`" : "`❌ Désactivé`", inline: true },
            { name: "Salon", value: r.channel ? `<#${r.channel}>` : "`Non configuré`", inline: true },
            { name: "Rôle à l'acceptation", value: r.roleOnAccept ? `<@&${r.roleOnAccept}>` : "`Aucun`", inline: true },
            { name: "DM à l'acceptation", value: r.dmOnAccept ? "`✅`" : "`❌`", inline: true },
            { name: "Règles", value: r.rules.length > 0 ? r.rules.map((rule, i) => `\`${i + 1}.\` ${rule}`).join("\n") : "`Aucune`", inline: false }
        );
}

function buildComponents() {
    return [
        new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId("rules_main")
                .setPlaceholder("Choisir une option")
                .addOptions(
                    { label: "Activer/Désactiver", value: "toggle_enabled", emoji: "🔘" },
                    { label: "Salon du panel", value: "set_channel", emoji: "📝" },
                    { label: "Ajouter une règle", value: "add_rule", emoji: "➕" },
                    { label: "Supprimer une règle", value: "remove_rule", emoji: "🗑️" },
                    { label: "Rôle à l'acceptation", value: "set_role", emoji: "🎭" },
                    { label: "DM à l'acceptation", value: "toggle_dm", emoji: "📨" },
                    { label: "Poster le panel", value: "post_panel", emoji: "📤" }
                )
        )
    ];
}

async function handleInteraction(client, interaction, db, msg, guild) {
    if (interaction.isStringSelectMenu() && interaction.customId === "rules_main") {
        const value = interaction.values[0];

        if (value === "set_channel") {
            await showChannelSelect(interaction);
            return;
        }
        if (value === "add_rule") {
            await showRuleModal(client, interaction, db, msg, guild);
            return;
        }
        if (value === "remove_rule") {
            await showRemoveRuleSelect(interaction, db);
            return;
        }
        if (value === "set_role") {
            await showRoleSelect(interaction);
            return;
        }
        if (value === "post_panel") {
            await postRulesPanel(client, db, guild, interaction);
            return;
        }

        if (value === "toggle_enabled") {
            db.rules.enabled = !db.rules.enabled;
            client.saveDB();
            await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
            return;
        }
        if (value === "toggle_dm") {
            db.rules.dmOnAccept = !db.rules.dmOnAccept;
            client.saveDB();
            await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
            return;
        }

        return;
    }

    if (interaction.isChannelSelectMenu() && interaction.customId === "rules_channel_select") {
        if (interaction.values[0]) {
            db.rules.channel = interaction.values[0];
            client.saveDB();
        }
        await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        return;
    }

    if (interaction.isRoleSelectMenu() && interaction.customId === "rules_role_select") {
        if (interaction.values[0]) {
            db.rules.roleOnAccept = interaction.values[0];
            client.saveDB();
        }
        await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        return;
    }

    if (interaction.isStringSelectMenu() && interaction.customId === "remove_rule_select") {
        const index = parseInt(interaction.values[0]);
        db.rules.rules.splice(index, 1);
        client.saveDB();
        await interaction.update({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
        return;
    }

    // Modal submission (add_rule_modal) is NOT handled here anymore — see
    // the note in showRuleModal below for why.
}

async function showChannelSelect(interaction) {
    const { ChannelSelectMenuBuilder, ChannelType } = require("discord.js");
    const selector = new ChannelSelectMenuBuilder()
        .setCustomId("rules_channel_select")
        .setPlaceholder("Sélectionnez le salon")
        .addChannelTypes(ChannelType.GuildText)
        .setMaxValues(1);

    await interaction.update({
        components: [new ActionRowBuilder().addComponents(selector)]
    });
}

async function showRoleSelect(interaction) {
    const { RoleSelectMenuBuilder } = require("discord.js");
    const selector = new RoleSelectMenuBuilder()
        .setCustomId("rules_role_select")
        .setPlaceholder("Sélectionnez le rôle")
        .setMaxValues(1);

    await interaction.update({
        components: [new ActionRowBuilder().addComponents(selector)]
    });
}

async function showRuleModal(client, interaction, db, msg, guild) {
    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");
    const modal = new ModalBuilder()
        .setCustomId("add_rule_modal")
        .setTitle("Ajouter une règle")
        .addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId("rule")
                .setLabel("Texte de la règle")
                .setStyle(TextInputStyle.Paragraph)
                .setPlaceholder("1. Respectez tous les membres...")
                .setRequired(true)
                .setMaxLength(1000)
        ));
    await interaction.showModal(modal);

    // msg.createMessageComponentCollector() (in exports.run, above) only
    // ever receives MESSAGE_COMPONENT interactions — a modal submission is
    // a different interaction type (MODAL_SUBMIT) entirely and is never
    // delivered to that collector. Waiting for it here, right after
    // showModal(), is the only way this submission actually gets picked up.
    const submitted = await interaction.awaitModalSubmit({
        time: 120000,
        filter: i => i.customId === "add_rule_modal" && i.user.id === interaction.user.id
    }).catch(() => null);
    if (!submitted) return;

    const rule = submitted.fields.getTextInputValue("rule");
    if (rule) {
        if (!db.rules.rules) db.rules.rules = [];
        db.rules.rules.push(rule);
        client.saveDB();
        await submitted.reply({ content: `✅ Règle ajoutée.`, flags: 64 });
        await msg.edit({ embeds: [buildEmbed(db, guild)], components: buildComponents() });
    } else {
        await submitted.reply({ content: "❌ Règle vide.", flags: 64 });
    }
}

async function showRemoveRuleSelect(interaction, db) {
    if (!db.rules.rules.length) {
        return interaction.reply({ content: "Aucune règle.", flags: 64 });
    }

    const { StringSelectMenuBuilder, ActionRowBuilder } = require("discord.js");
    const selector = new StringSelectMenuBuilder()
        .setCustomId("remove_rule_select")
        .setPlaceholder("Supprimer une règle");

    db.rules.rules.forEach((r, i) => {
        selector.addOptions({ label: `${i + 1}. ${r.substring(0, 80)}`, value: i.toString() });
    });

    await interaction.update({
        components: [new ActionRowBuilder().addComponents(selector)]
    });
}

async function postRulesPanel(client, db, guild, interaction) {
    if (!db.rules.channel) {
        return interaction.reply({ content: "❌ Aucun salon configuré.", flags: 64 });
    }

    const channel = guild.channels.cache.get(db.rules.channel);
    if (!channel) {
        return interaction.reply({ content: "❌ Salon introuvable.", flags: 64 });
    }

    const embed = new EmbedBuilder()
        .setTitle("📜 Règles du serveur")
        .setDescription(db.rules.rules.map((r, i) => `\`${i + 1}.\` ${r}`).join("\n\n") || "Aucune règle")
        .setColor(0x5865F2)
        .setFooter({ text: "Cliquez sur le bouton ci-dessous pour accepter les règles" });

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("rules_accept")
            .setLabel("✅ J'accepte les règles")
            .setStyle(ButtonStyle.Success)
    );

    await channel.send({ embeds: [embed], components: [row] });
    await interaction.reply({ content: "✅ Panel posté !", flags: 64 });
}

module.exports.handleButton = async (client, interaction) => {
    if (!interaction.isButton()) return;
    if (interaction.customId !== "rules_accept") return;

    const db = client.db(interaction.guild.id);
    if (!db.rules || !db.rules.enabled) {
        return interaction.reply({ content: "❌ Système désactivé.", flags: 64 });
    }

    if (db.rules.roleOnAccept) {
        const role = interaction.guild.roles.cache.get(db.rules.roleOnAccept);
        if (role && !interaction.member.roles.cache.has(role.id)) {
            try {
                await interaction.member.roles.add(role, "Acceptation des règles");
            } catch (error) {}
        }
    }

    if (db.rules.dmOnAccept) {
        try {
            await interaction.user.send("✅ Vous avez accepté les règles du serveur !").catch(() => {});
        } catch (error) {}
    }

    await interaction.reply({ content: "✅ Règles acceptées ! Bienvenue !", flags: 64 });
};
