const db = require("../../../index.js");

exports.help = {
    name: 'setmodlog',
    aliases: ['modlogchannel'],
    description: "Définit le salon qui recevra les logs de modération (ban/kick/mute/warn/report).",
    usage: "<#salon/off>",
    example: "#logs",
    perms: 4,
};

exports.run = async (client, message, args) => {
    const embed = client.template;

    if (!args[0]) {
        embed.data.description = "Vous devez mentionner un salon, ou écrire `off` pour désactiver.";
        return message.reply({ embeds: [embed] });
    }

    if (args[0] === "off") {
        await db.delete(`modlog_${message.guild.id}`);
        embed.data.description = "`✅` Le salon de logs de modération a été désactivé.";
        return message.reply({ embeds: [embed] });
    }

    const channel = message.mentions.channels.first();

    if (!channel || !channel.isTextBased()) {
        embed.data.description = "`❌` Je n'ai pas trouvé ce salon. Mentionnez un salon textuel valide.";
        return message.reply({ embeds: [embed] });
    }

    await db.set(`modlog_${message.guild.id}`, channel.id);

    embed.data.description = `\`✅\` Les logs de modération seront désormais envoyés dans ${channel}.`;
    return message.reply({ embeds: [embed] });
};
