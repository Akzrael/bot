const db = require("../../../index.js");
const { sendModLog } = require("../../../src/Structure/ModLog.js");

module.exports = {
    name: "guildMemberAdd",
    async execute(client, member) {
        const guild = member.guild;
        const cache = client.inviteCache?.get(guild.id);
        if (!cache) return;

        try {
            const newInvites = await guild.invites.fetch();
            let usedInvite = null;

            for (const [code, invite] of newInvites) {
                const oldInvite = cache.get(code);
                if (!oldInvite) {
                    usedInvite = invite;
                    break;
                }
                if (invite.uses > oldInvite.uses) {
                    usedInvite = invite;
                    break;
                }
            }

            if (usedInvite) {
                cache.set(usedInvite.code, {
                    uses: usedInvite.uses,
                    inviter: usedInvite.inviter?.id || null,
                    maxUses: usedInvite.maxUses,
                    maxAge: usedInvite.maxAge
                });

                const inviterId = usedInvite.inviter?.id;
                if (inviterId && inviterId !== client.user.id) {
                    const inviteData = await db.get(`invites_${guild.id}_${inviterId}`) || { regular: 0, leaves: 0, fake: 0, bonus: 0 };
                    inviteData.regular = (inviteData.regular || 0) + 1;
                    await db.set(`invites_${guild.id}_${inviterId}`, inviteData);

                    // Record who invited this specific member, independent of the
                    // invite's live use count. Discord never decrements an invite's
                    // uses when someone leaves, so guildMemberRemove can't rely on
                    // comparing uses to detect a leave/attribute it to an inviter —
                    // it has to look this mapping up instead.
                    await db.set(`invitejoin_${guild.id}_${member.id}`, {
                        inviterId,
                        code: usedInvite.code
                    });

                    await sendModLog(client, guild, {
                        title: "📨 Nouveau membre via invitation",
                        color: 0x57F287,
                        fields: [
                            { name: "Membre", value: `${member.user.tag} (\`${member.id}\`)`, inline: true },
                            { name: "Invité par", value: `<@${inviterId}> (\`${inviterId}\`)`, inline: true },
                            { name: "Code", value: usedInvite.code, inline: true },
                            { name: "Utilisations", value: usedInvite.uses.toString(), inline: true }
                        ],
                    });
                }
            }

            client.inviteCache.set(guild.id, cache);
        } catch (error) {
            console.error("[INVITE TRACKER] Error tracking invite:", error);
        }
    }
};
