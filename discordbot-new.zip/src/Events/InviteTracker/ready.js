const db = require("../../../index.js");

module.exports = {
    name: "ready",
    async execute(client) {
        for (const guild of client.guilds.cache.values()) {
            await cacheInvites(guild, client);
        }
        console.log("[INVITE TRACKER] Invites cached for all guilds.");
    }
};

async function cacheInvites(guild, client) {
    try {
        const invites = await guild.invites.fetch();
        const inviteMap = new Map();
        for (const [code, invite] of invites) {
            inviteMap.set(code, {
                uses: invite.uses,
                inviter: invite.inviter?.id || null,
                maxUses: invite.maxUses,
                maxAge: invite.maxAge
            });
        }
        client.inviteCache = client.inviteCache || new Map();
        client.inviteCache.set(guild.id, inviteMap);
    } catch (error) {
        console.error(`[INVITE TRACKER] Failed to cache invites for ${guild.id}:`, error);
    }
}