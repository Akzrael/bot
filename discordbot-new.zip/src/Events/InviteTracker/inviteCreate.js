const db = require("../../../index.js");

module.exports = {
    name: "inviteCreate",
    async execute(client, invite) {
        const cache = client.inviteCache?.get(invite.guild.id);
        if (cache) {
            cache.set(invite.code, {
                uses: invite.uses,
                inviter: invite.inviter?.id || null,
                maxUses: invite.maxUses,
                maxAge: invite.maxAge
            });
        }
    }
};