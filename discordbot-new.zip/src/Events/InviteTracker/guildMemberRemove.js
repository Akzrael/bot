const db = require("../../../index.js");
const { sendModLog } = require("../../../src/Structure/ModLog.js");

module.exports = {
    name: "guildMemberRemove",
    async execute(client, member) {
        const guild = member.guild;

        try {
            // Discord never decrements an invite's `uses` count when a member
            // leaves, so comparing live invite.uses to the cache (as this used to
            // do) can never detect a leave. Instead, look up who invited this
            // specific member from the mapping guildMemberAdd wrote at join time.
            const joinRecord = await db.get(`invitejoin_${guild.id}_${member.id}`);

            if (joinRecord?.inviterId && joinRecord.inviterId !== client.user.id) {
                const inviterId = joinRecord.inviterId;
                const inviteData = await db.get(`invites_${guild.id}_${inviterId}`) || { regular: 0, leaves: 0, fake: 0, bonus: 0 };
                inviteData.leaves = (inviteData.leaves || 0) + 1;
                await db.set(`invites_${guild.id}_${inviterId}`, inviteData);
                await db.delete(`invitejoin_${guild.id}_${member.id}`);

                await sendModLog(client, guild, {
                    title: "👋 Membre parti (invitation)",
                    color: 0xED4245,
                    fields: [
                        { name: "Membre", value: `${member.user.tag} (\`${member.id}\`)`, inline: true },
                        { name: "Avait été invité par", value: `<@${inviterId}> (\`${inviterId}\`)`, inline: true },
                        { name: "Code", value: joinRecord.code || "inconnu", inline: true }
                    ],
                });
            }

            // Still refresh the invite-uses cache so guildMemberAdd's "which
            // invite went up" comparison stays accurate for future joins.
            const cache = client.inviteCache?.get(guild.id);
            if (cache) {
                const newInvites = await guild.invites.fetch();
                for (const [code, invite] of newInvites) {
                    cache.set(code, {
                        uses: invite.uses,
                        inviter: invite.inviter?.id || null,
                        maxUses: invite.maxUses,
                        maxAge: invite.maxAge
                    });
                }
                client.inviteCache.set(guild.id, cache);
            }
        } catch (error) {
            console.error("[INVITE TRACKER] Error on member remove:", error);
        }
    }
};
