module.exports = {
    name: "messageDelete",

    async execute(client, message) {
        try {
            if (!message) return;
            if (!message.guild) return;
            if (!message.channel) return;

            // If the message is partial, try to fetch it.
            if (message.partial) {
                try {
                    message = await message.fetch();
                } catch {
                    // Continue with whatever information is available.
                }
            }

            // Ignore bot messages when author is available.
            if (message.author?.bot) return;

            // Make sure the map exists.
            if (!client.snipeMap) {
                client.snipeMap = new Map();
            }

            const channelId = message.channel.id;

            if (!client.snipeMap.has(channelId)) {
                client.snipeMap.set(channelId, []);
            }

            const snipes = client.snipeMap.get(channelId);

            const deletedMessage = {
                content: message.content || "",
                author: message.author || {
                    tag: "Utilisateur inconnu",
                    displayAvatarURL: () => null
                },
                image: null,
                timestamp: Date.now()
            };

            // Save the first image attachment if there is one.
            if (message.attachments?.size) {
                const attachment = message.attachments.first();

                if (attachment?.contentType?.startsWith("image/")) {
                    deletedMessage.image = attachment.url;
                }
            }

            // Put newest deleted message first.
            snipes.unshift(deletedMessage);

            // Keep the last 20 deleted messages per channel.
            if (snipes.length > 20) {
                snipes.length = 20;
            }

            client.snipeMap.set(channelId, snipes);

            console.log(
                `[SNIPE] Saved message in #${message.channel.name || channelId}`
            );

        } catch (error) {
            // Snipe must NEVER crash the bot.
            console.error("[SNIPE] Error:", error);
        }
    }
};
