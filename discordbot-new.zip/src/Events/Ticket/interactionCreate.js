const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    name: "interactionCreate",

    async execute(client, interaction) {
        if (!interaction.guild) return;

        try {
            const db = client.db(interaction.guild.id);
            if (!db || !db.ticket) return;

            if (interaction.isButton()) {
                // Only "create a new ticket" is gated by the enabled toggle.
                // Buttons on already-open tickets must keep working even if
                // the system gets disabled afterward, otherwise staff lose
                // the ability to close/claim/delete tickets that are still open.
                if (interaction.customId === 'ticket_create_panel') {
                    if (!db.ticket.enabled)
                        return interaction.reply({ content: '❌ Le système de tickets est désactivé.', flags: 64 });
                    return this.handleTicketPanel(interaction, db);
                }
                if (interaction.customId === 'claim_ticket') return this.handleClaimTicket(interaction, db, client);
                if (interaction.customId === 'unclaim_ticket') return this.handleUnclaimTicket(interaction, db, client);
                if (interaction.customId === 'close_ticket') return this.handleCloseTicket(interaction, db);
                if (interaction.customId === 'confirm_close_ticket') return this.handleConfirmCloseTicket(interaction, db, client);
                if (interaction.customId === 'cancel_close_ticket') return this.handleCancelCloseTicket(interaction);
                if (interaction.customId === 'reopen_ticket') return this.handleReopenTicket(interaction, db, client);
                if (interaction.customId === 'delete_ticket') return this.handleDeleteTicket(interaction, db, client);
                if (interaction.customId === 'confirm_delete_ticket') return this.handleConfirmDeleteTicket(interaction, db, client);
                if (interaction.customId === 'cancel_delete_ticket') return this.handleCancelDeleteTicket(interaction);
                if (interaction.customId === 'ticket_transcript') return this.handleTranscript(interaction, db, client);
            }

            if (interaction.isModalSubmit() && interaction.customId === 'ticket_reason_modal')
                return this.handleReasonSubmit(interaction, db, client);

        } catch (error) {
            console.error("[TICKET ERROR]", error);
            if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: '❌ Une erreur est survenue.', flags: 64 }).catch(() => {});
            }
        }
    },

    async handleTicketPanel(interaction, db) {
        const existing = Object.entries(db.ticket.activeTickets || {})
            .find(([, t]) => t.userId === interaction.user.id && !t.closed);

        if (existing)
            return interaction.reply({ content: `❌ Vous avez déjà un ticket ouvert : <#${existing[0]}>`, flags: 64 });

        const modal = new ModalBuilder()
            .setCustomId('ticket_reason_modal')
            .setTitle('Créer un ticket')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('ticket_reason')
                        .setLabel('Raison du ticket')
                        .setStyle(TextInputStyle.Paragraph)
                        .setPlaceholder('Expliquez la raison de votre ticket...')
                        .setRequired(true)
                        .setMaxLength(1000)
                )
            );

        await interaction.showModal(modal);
    },

    async handleReasonSubmit(interaction, db, client) {
        const reason = interaction.fields.getTextInputValue('ticket_reason');

        const category = interaction.guild.channels.cache.get(db.ticket.category);
        if (!category || category.type !== ChannelType.GuildCategory) {
            return interaction.reply({ content: '❌ Catégorie de tickets invalide ou non configurée.', flags: 64 });
        }

        if (!db.ticket.counter) db.ticket.counter = 0;
        db.ticket.counter++;
        const ticketNumber = db.ticket.counter.toString().padStart(4, '0');

        const ticketChannel = await interaction.guild.channels.create({
            name: `ticket-${ticketNumber}-${interaction.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, ''),
            type: ChannelType.GuildText,
            parent: category,
            topic: `Ticket #${ticketNumber} | ${interaction.user.id}`,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: interaction.user.id,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
                },
                {
                    id: client.user.id,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels]
                },
                ...db.ticket.staffRoles.map(roleId => ({
                    id: roleId,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
                }))
            ]
        });

        const infoEmbed = new EmbedBuilder()
            .setTitle(`🎫 Ticket #${ticketNumber}`)
            .setDescription(`**Utilisateur:** ${interaction.user} (${interaction.user.tag})\n**ID:** ${interaction.user.id}`)
            .addFields({ name: '📝 Raison', value: reason })
            .setThumbnail(interaction.user.displayAvatarURL())
            .setColor(0xffffff)
            .setTimestamp();

        const buttons = this.createTicketButtons(db, false, false);

        const infoMessage = await ticketChannel.send({
            content: db.ticket.staffRoles.length > 0 ? db.ticket.staffRoles.map(id => `<@&${id}>`).join(' ') : null,
            embeds: [infoEmbed],
            components: [buttons]
        });

        if (!db.ticket.activeTickets) db.ticket.activeTickets = {};
        db.ticket.activeTickets[ticketChannel.id] = {
            userId: interaction.user.id,
            ticketNumber: ticketNumber,
            reason: reason,
            createdAt: Date.now(),
            claimedBy: null,
            closed: false,
            infoMessageId: infoMessage.id  // remembered explicitly so we always edit the right message
        };
        client.saveDB();

        await interaction.reply({ content: `✅ Ticket créé : ${ticketChannel}`, flags: 64 });
    },

    async handleClaimTicket(interaction, db, client) {
        if (!db.ticket.claimSystem) {
            return interaction.reply({ content: '❌ Le système de claim n\'est pas activé.', flags: 64 });
        }

        const ticketData = db.ticket.activeTickets?.[interaction.channel.id];
        if (!ticketData) {
            return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket valide.', flags: 64 });
        }

        if (ticketData.claimedBy) {
            return interaction.reply({ content: '❌ Ce ticket est déjà claim par quelqu\'un d\'autre.', flags: 64 });
        }

        await interaction.deferUpdate();

        ticketData.claimedBy = interaction.user.id;
        client.saveDB();

        const claimEmbed = new EmbedBuilder()
            .setColor(0x00ff00)
            .setDescription(`${interaction.user} a claim ce ticket`);

        await interaction.channel.send({ embeds: [claimEmbed] });

        try {
            for (const roleId of db.ticket.staffRoles) {
                await interaction.channel.permissionOverwrites.edit(roleId, { ViewChannel: false });
            }
            await interaction.channel.permissionOverwrites.edit(interaction.user.id, {
                ViewChannel: true,
                SendMessages: true,
                ReadMessageHistory: true
            });
        } catch (error) {
            console.error('[TICKET] Erreur lors du claim:', error);
        }

        await this.refreshButtons(interaction.channel, db, ticketData, false);
    },

    async handleUnclaimTicket(interaction, db, client) {
        const ticketData = db.ticket.activeTickets?.[interaction.channel.id];
        if (!ticketData) {
            return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket valide.', flags: 64 });
        }

        if (ticketData.claimedBy !== interaction.user.id) {
            return interaction.reply({ content: '❌ Vous ne pouvez pas unclaim ce ticket.', flags: 64 });
        }

        await interaction.deferUpdate();

        ticketData.claimedBy = null;
        client.saveDB();

        const unclaimEmbed = new EmbedBuilder()
            .setColor(0xff9900)
            .setDescription(`${interaction.user} a unclaim ce ticket`);

        await interaction.channel.send({ embeds: [unclaimEmbed] });

        try {
            for (const roleId of db.ticket.staffRoles) {
                await interaction.channel.permissionOverwrites.edit(roleId, {
                    ViewChannel: true,
                    SendMessages: true,
                    ReadMessageHistory: true
                });
            }
        } catch (error) {
            console.error('[TICKET] Erreur lors du unclaim:', error);
        }

        await this.refreshButtons(interaction.channel, db, ticketData, false);
    },

    async handleCloseTicket(interaction, db) {
        const ticketData = db.ticket.activeTickets?.[interaction.channel.id];
        if (!ticketData) {
            return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket valide.', flags: 64 });
        }

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('confirm_close_ticket')
                .setLabel('Confirmer la fermeture')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('cancel_close_ticket')
                .setLabel('Annuler')
                .setStyle(ButtonStyle.Secondary)
        );

        await interaction.reply({
            content: 'Êtes-vous sûr de vouloir fermer ce ticket ?',
            components: [row],
            flags: 64
        });
    },

    async handleConfirmCloseTicket(interaction, db, client) {
        const ticketData = db.ticket.activeTickets?.[interaction.channel.id];
        if (!ticketData) {
            return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket valide.', flags: 64 });
        }

        await interaction.deferUpdate();

        await interaction.channel.permissionOverwrites.edit(ticketData.userId, {
            ViewChannel: false,
            SendMessages: false
        }).catch(() => {});

        // Kept (not deleted) so Reopen can restore the right user/claim state afterward.
        ticketData.closed = true;
        client.saveDB();

        const closeEmbed = new EmbedBuilder()
            .setTitle('🔒 Ticket fermé')
            .setDescription(`Ticket fermé par ${interaction.user}`)
            .setColor(0xff0000)
            .setTimestamp();

        const reopenButtons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('reopen_ticket')
                .setLabel('Rouvrir')
                .setStyle(ButtonStyle.Success)
                .setEmoji('🔓'),
            new ButtonBuilder()
                .setCustomId('delete_ticket')
                .setLabel('Supprimer')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🗑️'),
            new ButtonBuilder()
                .setCustomId('ticket_transcript')
                .setLabel('Transcript')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('📄')
        );

        // Send the closed-state message and remember IT as the new button-holder,
        // instead of blindly clearing "whatever message happens to be newest".
        const closeMessage = await interaction.channel.send({ embeds: [closeEmbed], components: [reopenButtons] });
        ticketData.infoMessageId = closeMessage.id;
        client.saveDB();
    },

    async handleCancelCloseTicket(interaction) {
        await interaction.update({ content: 'Fermeture annulée.', components: [] });
    },

    async handleReopenTicket(interaction, db, client) {
        const ticketData = db.ticket.activeTickets?.[interaction.channel.id];
        if (!ticketData) {
            return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket valide.', flags: 64 });
        }

        await interaction.deferUpdate();

        ticketData.closed = false;
        client.saveDB();

        await interaction.channel.permissionOverwrites.edit(ticketData.userId, {
            ViewChannel: true,
            SendMessages: true,
            ReadMessageHistory: true
        }).catch(() => {});

        const reopenEmbed = new EmbedBuilder()
            .setColor(0x57F287)
            .setDescription(`🔓 Ticket rouvert par ${interaction.user}`);

        const reopenMessage = await interaction.channel.send({
            embeds: [reopenEmbed],
            components: [this.createTicketButtons(db, false, !!ticketData.claimedBy)]
        });

        ticketData.infoMessageId = reopenMessage.id;
        client.saveDB();
    },

    /**
     * Delete is destructive and irreversible, so both entry points (the button
     * on an open ticket, and the one shown after closing) go through the same
     * confirmation prompt before anything actually gets deleted.
     */
    async handleDeleteTicket(interaction, db, client) {
        const ticketData = db.ticket.activeTickets?.[interaction.channel.id];
        if (!ticketData && !interaction.channel.name.startsWith('ticket-')) {
            return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket valide.', flags: 64 });
        }

        // Check if user is staff
        const member = interaction.member;
        const isStaff = db.ticket.staffRoles.some(roleId => member.roles.cache.has(roleId));
        if (!isStaff && !member.permissions.has('Administrator')) {
            return interaction.reply({ content: '❌ Seul le staff peut supprimer un ticket.', flags: 64 });
        }

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('confirm_delete_ticket')
                .setLabel('Confirmer la suppression')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('cancel_delete_ticket')
                .setLabel('Annuler')
                .setStyle(ButtonStyle.Secondary)
        );

        await interaction.reply({
            content: 'Êtes-vous sûr de vouloir supprimer ce ticket ? Cette action est irréversible.',
            components: [row],
            flags: 64
        });
    },

    async handleConfirmDeleteTicket(interaction, db, client) {
        // Verify staff permission again (in case someone triggers confirm directly)
        const member = interaction.member;
        const isStaff = db.ticket.staffRoles.some(roleId => member.roles.cache.has(roleId));
        if (!isStaff && !member.permissions.has('Administrator')) {
            return interaction.reply({ content: '❌ Seul le staff peut supprimer un ticket.', flags: 64 });
        }

        await interaction.deferUpdate();

        const deleteEmbed = new EmbedBuilder()
            .setTitle('🗑️ Ticket supprimé')
            .setDescription(`Ticket supprimé par ${interaction.user}`)
            .setColor(0x000000)
            .setTimestamp();

        await interaction.channel.send({ embeds: [deleteEmbed] });

        if (db.ticket.activeTickets?.[interaction.channel.id]) {
            delete db.ticket.activeTickets[interaction.channel.id];
            client.saveDB();
        }

        setTimeout(() => {
            interaction.channel.delete().catch(console.error);
        }, 2000);
    },

    async handleCancelDeleteTicket(interaction) {
        await interaction.update({ content: 'Suppression annulée.', components: [] });
    },

    async handleTranscript(interaction, db, client) {
        await interaction.deferReply({ flags: 64 });

        const messages = await interaction.channel.messages.fetch({ limit: 100 });
        const sortedMessages = messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);

        const ticketData = db.ticket.activeTickets?.[interaction.channel.id];
        let transcript = `=== TRANSCRIPT TICKET ===\n`;
        transcript += `Salon: ${interaction.channel.name}\n`;
        if (ticketData) {
            transcript += `Ticket #${ticketData.ticketNumber}\n`;
            transcript += `Utilisateur: ${ticketData.userId}\n`;
            if (ticketData.reason) transcript += `Raison: ${ticketData.reason}\n`;
        }
        transcript += `Généré le: ${new Date().toLocaleString('fr-FR')}\n`;
        transcript += `Généré par: ${interaction.user.tag}\n\n`;
        transcript += `=== MESSAGES ===\n\n`;

        for (const message of sortedMessages.values()) {
            if (message.author.bot && !message.webhookId) continue;

            const timestamp = new Date(message.createdTimestamp).toLocaleString('fr-FR');
            const author = message.webhookId ? message.author.username : message.author.tag;

            transcript += `[${timestamp}] ${author}: ${message.content || '*Message sans contenu*'}\n`;

            if (message.attachments.size > 0) {
                transcript += `   Pièces jointes: ${Array.from(message.attachments.values()).map(att => att.url).join(', ')}\n`;
            }
            transcript += '\n';
        }

        const buffer = Buffer.from(transcript, 'utf-8');
        const attachment = {
            attachment: buffer,
            name: `transcript-${interaction.channel.name}-${Date.now()}.txt`
        };

        const transcriptEmbed = new EmbedBuilder()
            .setTitle('📄 Transcript du ticket')
            .setColor(0xffffff)
            .addFields([
                { name: '📅 Date', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                { name: '👮 Généré par', value: interaction.user.tag, inline: true },
                { name: '🎫 Salon', value: interaction.channel.name, inline: true }
            ])
            .setTimestamp();

        await interaction.editReply({ content: '✅ Transcript généré.', files: [attachment], embeds: [transcriptEmbed] });
    },

    /**
     * Edits the ticket's remembered info/status message to reflect current
     * claim state. Falls back to doing nothing (instead of guessing at "the
     * most recent message") if the remembered message no longer exists.
     */
    async refreshButtons(channel, db, ticketData, isClosed) {
        const buttons = this.createTicketButtons(db, isClosed, !!ticketData.claimedBy);

        if (ticketData.infoMessageId) {
            const message = await channel.messages.fetch(ticketData.infoMessageId).catch(() => null);
            if (message) {
                await message.edit({ components: [buttons] }).catch(() => {});
            }
        }
    },

    createTicketButtons(db, isClosed = false, isClaimed = false) {
        const buttons = [];

        if (!isClosed) {
            buttons.push(
                new ButtonBuilder()
                    .setCustomId('close_ticket')
                    .setLabel('Fermer')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId('delete_ticket')
                    .setLabel('Supprimer')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🗑️')
            );

            if (db.ticket.claimSystem) {
                if (!isClaimed) {
                    buttons.push(
                        new ButtonBuilder()
                            .setCustomId('claim_ticket')
                            .setLabel('Claim')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji('🔒')
                    );
                } else {
                    buttons.push(
                        new ButtonBuilder()
                            .setCustomId('unclaim_ticket')
                            .setLabel('Unclaim')
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji('🔓')
                    );
                }
            }

            buttons.push(
                new ButtonBuilder()
                    .setCustomId('ticket_transcript')
                    .setLabel('Transcript')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('📄')
            );
        } else {
            buttons.push(
                new ButtonBuilder()
                    .setCustomId('reopen_ticket')
                    .setLabel('Rouvrir')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('🔓'),
                new ButtonBuilder()
                    .setCustomId('delete_ticket')
                    .setLabel('Supprimer')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🗑️'),
                new ButtonBuilder()
                    .setCustomId('ticket_transcript')
                    .setLabel('Transcript')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('📄')
            );
        }

        return new ActionRowBuilder().addComponents(buttons);
    }
};
