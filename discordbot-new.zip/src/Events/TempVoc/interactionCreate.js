const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    UserSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    PermissionFlagsBits,
    ChannelType
} = require("discord.js");

const db = require("../../../index.js");

// Safe reply/followUp helper — every branch below used to call
// interaction.reply(...) directly. Since these buttons live inside the
// temp voice channel's own text chat, actions that delete the channel
// (or a channel that got emptied and auto-deleted a split second before
// the click landed) mean Discord can no longer route a reply into it
// (DiscordAPIError 10003: Unknown Channel). That failure used to escape
// the outer try/catch's own fallback reply too, which threw all the way
// out as an unhandled rejection. Routing every reply through this helper
// means a dead channel just fails silently instead of cascading.
async function safeRespond(interaction, payload) {
    try {
        if (interaction.replied || interaction.deferred) {
            return await interaction.followUp(payload);
        }
        return await interaction.reply(payload);
    } catch (error) {
        console.error("[TempVoc REPLY ERROR]", error.message || error);
        return null;
    }
}

module.exports = {
    name: "interactionCreate",

    async execute(client, interaction) {
        if (!interaction.guild) return;

        if (interaction.isButton()) {
            const customId = interaction.customId;

            if (customId.startsWith("tempvoc_")) {
                await this.handleTempVocButton(interaction, customId);
                return;
            }
        }

        if (interaction.isStringSelectMenu()) {
            if (interaction.customId.startsWith("tempvoc_rename_")) {
                await this.handleRenameSelect(interaction);
                return;
            }
        }

        if (interaction.isUserSelectMenu()) {
            if (interaction.customId.startsWith("tempvoc_transfer_")) {
                await this.handleTransferSelect(interaction);
                return;
            }
        }

        if (interaction.isModalSubmit()) {
            if (interaction.customId.startsWith("tempvoc_limit_modal_")) {
                await this.handleLimitModal(interaction);
                return;
            }
            if (interaction.customId.startsWith("tempvoc_rename_modal_")) {
                await this.handleRenameModal(interaction);
                return;
            }
        }
    },

    async handleTempVocButton(interaction, customId) {
        const parts = customId.split("_");
        const action = parts[1];
        const channelId = parts[2];

        const guild = interaction.guild;
        const channel = guild.channels.cache.get(channelId);

        if (!channel || channel.type !== ChannelType.GuildVoice) {
            return safeRespond(interaction, { content: "❌ Salon vocal introuvable.", flags: 64 });
        }

        const guildId = guild.id;
        const owners = await db.get(`tempvoc_owners_${guildId}`) || {};
        const ownerId = owners[channelId];

        const isOwner = ownerId === interaction.user.id;
        const isStaff = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels);

        if (!isOwner && !isStaff) {
            return safeRespond(interaction, { content: "❌ Seul le propriétaire du salon ou le staff peut utiliser ces contrôles.", flags: 64 });
        }

        try {
            switch (action) {
                case "lock":
                    await channel.permissionOverwrites.edit(guild.roles.everyone, {
                        Connect: false
                    });
                    return safeRespond(interaction, { content: "🔒 Salon verrouillé - personne ne peut rejoindre.", flags: 64 });

                case "unlock":
                    await channel.permissionOverwrites.edit(guild.roles.everyone, {
                        Connect: true
                    });
                    return safeRespond(interaction, { content: "🔓 Salon déverrouillé - tout le monde peut rejoindre.", flags: 64 });

                case "hide":
                    await channel.permissionOverwrites.edit(guild.roles.everyone, {
                        ViewChannel: false
                    });
                    return safeRespond(interaction, { content: "🙈 Salon caché - invisible pour les membres.", flags: 64 });

                case "unhide":
                    await channel.permissionOverwrites.edit(guild.roles.everyone, {
                        ViewChannel: true
                    });
                    return safeRespond(interaction, { content: "👁️ Salon visible à nouveau.", flags: 64 });

                case "mute":
                    for (const member of channel.members.values()) {
                        await member.voice.setMute(true, "TempVoc: Mute all by owner").catch(() => {});
                    }
                    return safeRespond(interaction, { content: "🔇 Tous les membres ont été rendus muets.", flags: 64 });

                case "demute":
                    for (const member of channel.members.values()) {
                        await member.voice.setMute(false, "TempVoc: Demute all by owner").catch(() => {});
                    }
                    return safeRespond(interaction, { content: "🔊 Tous les membres ont été démute.", flags: 64 });

                case "limit":
                    const limitModal = new ModalBuilder()
                        .setCustomId(`tempvoc_limit_modal_${channelId}`)
                        .setTitle("Définir la limite d'utilisateurs")
                        .addComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId("limit_value")
                                    .setLabel("Limite (0 = illimité, max 99)")
                                    .setStyle(TextInputStyle.Short)
                                    .setPlaceholder("0")
                                    .setRequired(true)
                                    .setMinLength(1)
                                    .setMaxLength(2)
                            )
                        );
                    return interaction.showModal(limitModal).catch(err => console.error("[TempVoc MODAL ERROR]", err.message || err));

                case "rename":
                    const renameModal = new ModalBuilder()
                        .setCustomId(`tempvoc_rename_modal_${channelId}`)
                        .setTitle("Renommer le salon")
                        .addComponents(
                            new ActionRowBuilder().addComponents(
                                new TextInputBuilder()
                                    .setCustomId("new_name")
                                    .setLabel("Nouveau nom")
                                    .setStyle(TextInputStyle.Short)
                                    .setPlaceholder(channel.name)
                                    .setRequired(true)
                                    .setMaxLength(100)
                            )
                        );
                    return interaction.showModal(renameModal).catch(err => console.error("[TempVoc MODAL ERROR]", err.message || err));

                case "kick":
                    const kickSelect = new UserSelectMenuBuilder()
                        .setCustomId(`tempvoc_kick_select_${channelId}`)
                        .setPlaceholder("Sélectionnez les membres à expulser")
                        .setMinValues(1)
                        .setMaxValues(10);

                    const kickRow = new ActionRowBuilder().addComponents(kickSelect);
                    return safeRespond(interaction, { content: "Sélectionnez les membres à kick :", components: [kickRow], flags: 64 });

                case "transfer":
                    const transferSelect = new UserSelectMenuBuilder()
                        .setCustomId(`tempvoc_transfer_${channelId}`)
                        .setPlaceholder("Sélectionnez le nouveau propriétaire")
                        .setMinValues(1)
                        .setMaxValues(1);

                    const transferRow = new ActionRowBuilder().addComponents(transferSelect);
                    return safeRespond(interaction, { content: "Sélectionnez le nouveau propriétaire :", components: [transferRow], flags: 64 });

                case "claim":
                    if (owners[channelId]) {
                        return safeRespond(interaction, { content: "❌ Ce salon a déjà un propriétaire.", flags: 64 });
                    }
                    owners[channelId] = interaction.user.id;
                    await db.set(`tempvoc_owners_${guildId}`, owners);

                    try {
                        await channel.permissionOverwrites.edit(interaction.user.id, {
                            ViewChannel: true,
                            Connect: true,
                            Speak: true,
                            Stream: true,
                            UseVAD: true,
                            ManageChannels: true,
                            MoveMembers: true,
                            MuteMembers: true,
                            DeafenMembers: true,
                            PrioritySpeaker: true
                        });
                    } catch (error) {
                        console.error("[TempVoc CLAIM PERMS ERROR]", error);
                    }

                    return safeRespond(interaction, { content: `🏷️ Vous êtes maintenant propriétaire de **${channel.name}** !`, flags: 64 });

                case "delete":
                    if (!isOwner && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                        return safeRespond(interaction, { content: "❌ Seul le propriétaire ou un administrateur peut supprimer le salon.", flags: 64 });
                    }

                    // Reply BEFORE deleting. The panel lives inside the
                    // voice channel's own text chat, so the moment the
                    // channel is gone, Discord can no longer route any
                    // reply into it (Unknown Channel / 10003) — replying
                    // first, then deleting, avoids that entirely.
                    await safeRespond(interaction, { content: "🗑️ Salon supprimé.", flags: 64 });

                    const tempChannels = await db.get(`tempvoc_temp_${guildId}`) || [];
                    await db.set(`tempvoc_temp_${guildId}`, tempChannels.filter(id => id !== channelId));
                    delete owners[channelId];
                    await db.set(`tempvoc_owners_${guildId}`, owners);

                    await channel.delete("TempVoc: Supprimé par le propriétaire").catch(() => {});
                    return;

                default:
                    return safeRespond(interaction, { content: "❌ Action inconnue.", flags: 64 });
            }
        } catch (error) {
            console.error("[TempVoc BUTTON ERROR]", error);
            return safeRespond(interaction, { content: "❌ Une erreur est survenue.", flags: 64 });
        }
    },

    async handleLimitModal(interaction) {
        const customId = interaction.customId;
        const channelId = customId.split("_")[3];
        const limit = parseInt(interaction.fields.getTextInputValue("limit_value"));

        if (isNaN(limit) || limit < 0 || limit > 99) {
            return safeRespond(interaction, { content: "❌ Limite invalide (0-99).", flags: 64 });
        }

        const guild = interaction.guild;
        const channel = guild.channels.cache.get(channelId);

        if (!channel) {
            return safeRespond(interaction, { content: "❌ Salon introuvable.", flags: 64 });
        }

        try {
            await channel.setUserLimit(limit);
            const limitText = limit === 0 ? "illimitée" : limit.toString();
            return safeRespond(interaction, { content: `✅ Limite définie sur **${limitText}** utilisateur(s).`, flags: 64 });
        } catch (error) {
            console.error("[TempVoc LIMIT ERROR]", error);
            return safeRespond(interaction, { content: "❌ Impossible de modifier la limite.", flags: 64 });
        }
    },

    async handleRenameModal(interaction) {
        const customId = interaction.customId;
        const channelId = customId.split("_")[3];
        const newName = interaction.fields.getTextInputValue("new_name");

        if (!newName.trim()) {
            return safeRespond(interaction, { content: "❌ Le nom ne peut pas être vide.", flags: 64 });
        }

        const guild = interaction.guild;
        const channel = guild.channels.cache.get(channelId);

        if (!channel) {
            return safeRespond(interaction, { content: "❌ Salon introuvable.", flags: 64 });
        }

        try {
            await channel.setName(newName.slice(0, 100));
            return safeRespond(interaction, { content: `✅ Salon renommé en **${newName}**.`, flags: 64 });
        } catch (error) {
            console.error("[TempVoc RENAME ERROR]", error);
            return safeRespond(interaction, { content: "❌ Impossible de renommer le salon.", flags: 64 });
        }
    },

    async handleTransferSelect(interaction) {
        const customId = interaction.customId;
        const channelId = customId.split("_")[2];
        const newOwnerId = interaction.values[0];

        const guild = interaction.guild;
        const channel = guild.channels.cache.get(channelId);
        const newOwner = guild.members.cache.get(newOwnerId);

        if (!channel || !newOwner) {
            return safeRespond(interaction, { content: "❌ Salon ou membre introuvable.", flags: 64 });
        }

        const guildId = guild.id;
        const owners = await db.get(`tempvoc_owners_${guildId}`) || {};
        const oldOwnerId = owners[channelId];

        if (oldOwnerId && oldOwnerId !== interaction.user.id && !interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return safeRespond(interaction, { content: "❌ Seul le propriétaire actuel ou le staff peut transférer.", flags: 64 });
        }

        try {
            if (oldOwnerId) {
                await channel.permissionOverwrites.edit(oldOwnerId, {
                    ManageChannels: false,
                    MoveMembers: false,
                    MuteMembers: false,
                    DeafenMembers: false
                }).catch(() => {});
            }

            owners[channelId] = newOwnerId;
            await db.set(`tempvoc_owners_${guildId}`, owners);

            await channel.permissionOverwrites.edit(newOwnerId, {
                ViewChannel: true,
                Connect: true,
                Speak: true,
                Stream: true,
                UseVAD: true,
                ManageChannels: true,
                MoveMembers: true,
                MuteMembers: true,
                DeafenMembers: true,
                PrioritySpeaker: true
            }).catch(() => {});

            await safeRespond(interaction, { content: `👑 **${newOwner.user.tag}** est maintenant propriétaire de **${channel.name}** !` });

            try {
                const dmEmbed = new EmbedBuilder()
                    .setTitle("👑 Transfert de propriété")
                    .setDescription(`Vous êtes maintenant propriétaire du salon **${channel.name}** (transféré par ${interaction.user.tag}).`)
                    .setColor(0x57F287);
                await newOwner.send({ embeds: [dmEmbed] }).catch(() => {});
            } catch (error) {}

        } catch (error) {
            console.error("[TempVoc TRANSFER ERROR]", error);
            return safeRespond(interaction, { content: "❌ Impossible de transférer la propriété.", flags: 64 });
        }
    }
};
