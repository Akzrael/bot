const db = require("../../../index.js");
const { sendModLog } = require("../../../src/Structure/ModLog.js");

const xpCooldowns = new Map();

function calculateLevel(xp) {
    return Math.floor(0.1 * Math.sqrt(xp)) + 1;
}

function calculateXpForLevel(level) {
    return Math.pow((level - 1) / 0.1, 2);
}

module.exports = {
    name: "messageCreate",
    async execute(client, message) {
        if (!message.guild || message.author.bot) return;

        // Level config (enabled, xpPerMessage, etc.) lives in the fs-based client.db() store.
        const guildConfig = client.db(message.guild.id);
        if (!guildConfig.level || !guildConfig.level.enabled) return;

        if (guildConfig.level.ignoredChannels?.includes(message.channel.id)) return;
        if (message.member.roles.cache.some(r => guildConfig.level.ignoredRoles?.includes(r.id))) return;

        const cooldownKey = `${message.guild.id}-${message.author.id}`;
        const now = Date.now();
        const cooldownMs = (guildConfig.level.xpCooldown || 60) * 1000;

        if (xpCooldowns.has(cooldownKey)) {
            const lastXp = xpCooldowns.get(cooldownKey);
            if (now - lastXp < cooldownMs) return;
        }
        xpCooldowns.set(cooldownKey, now);

        const xpGain = guildConfig.level.xpPerMessage || 15;
        // Per-user XP data lives in quick.db, not the fs-based client.db() store
        // (which is a plain object with no .get()/.set() methods).
        const userKey = `level_${message.guild.id}_${message.author.id}`;
        let userData = await db.get(userKey) || { xp: 0, level: 1, messages: 0 };

        const oldLevel = userData.level;
        userData.xp += xpGain;
        userData.messages = (userData.messages || 0) + 1;
        userData.level = calculateLevel(userData.xp);

        await db.set(userKey, userData);

        if (userData.level > oldLevel) {
            await handleLevelUp(client, message, userData, oldLevel, guildConfig);
        }
    }
};

async function handleLevelUp(client, message, userData, oldLevel, guildConfig) {
    const newLevel = userData.level;
    const member = message.member;
    const guild = message.guild;

    for (const reward of guildConfig.level.roleRewards || []) {
        if (newLevel >= reward.level && oldLevel < reward.level) {
            const role = guild.roles.cache.get(reward.roleId);
            if (role && !member.roles.cache.has(role.id)) {
                try {
                    await member.roles.add(role, `Level up: atteint niveau ${newLevel}`);
                } catch (error) {
                    console.error("[LEVEL] Failed to add role:", error);
                }
            }
        }
    }

    if (!guildConfig.level.levelUpMessage) return;

    const channel = guildConfig.level.levelUpChannel
        ? guild.channels.cache.get(guildConfig.level.levelUpChannel)
        : message.channel;

    if (!channel) return;

    const embed = {
        title: "🎉 Level Up !",
        description: `Félicitations ${member} ! Vous êtes maintenant **niveau ${newLevel}** !`,
        color: 0x57F287,
        thumbnail: { url: member.displayAvatarURL() },
        fields: [
            { name: "XP Total", value: userData.xp.toString(), inline: true },
            { name: "Messages", value: userData.messages.toString(), inline: true }
        ],
        timestamp: new Date().toISOString()
    };

    try {
        await channel.send({ content: `${member}`, embeds: [embed] });
    } catch (error) {}
}
