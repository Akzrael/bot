const cooldowns = new Map();
const db = require("../../../index")

const TIER_LABELS = {
  6: "propriétaire du bot",
  5: "propriétaire du serveur",
  4: "whitelist (ou supérieur)",
  3: "permission 3 (Admin), whitelist ou propriétaire",
  2: "permission 2 (Modérateur), whitelist ou propriétaire",
  1: "accès public",
};

module.exports = {
  name: "messageCreate",
  async execute(client, message) {
    if (message.author.bot) return;
    if (message.channel.type === "DM") return;

    const prefix = client.prefix || "!";

    let embed = client.template;
    embed.data.description = "`🚨` Mon prefix actuel est **`" + prefix + "`**.";
    if (message.content == `${client.user}`) return message.reply({ embeds: [embed] });

    if (!message.content.startsWith(prefix)) return;

    const messageArray = message.content.split(" ");
    const cmd = messageArray[0].slice(prefix.length).toLowerCase();
    const args = messageArray.slice(1);

    const commandFile = client.commands.get(cmd) || client.commands.find(c => c.help.aliases && c.help.aliases.includes(cmd));
    if (!commandFile) return;

      let wlData = await db.get(`whitelist_${message.guild.id}`) || [];
    let owner = await message.guild.fetchOwner();
    let perms = await db.get(`perms_${message.guild.id}`) || { perms2: [], perms3: []}

    const denyEmbed = client.template;
    function denyAccess(tier) {
      denyEmbed.data.description = `\`❌\` Vous n'avez pas la permission d'utiliser cette commande. Il faut : **${TIER_LABELS[tier] || "permission suffisante"}**.`;
      return message.reply({ embeds: [denyEmbed] }).catch(() => {});
    }

let userPerm = 0;

if (client.config.owners.includes(message.author.id)) {
    // Bot owner
    userPerm = 6;
} else if (message.author.id === owner.id) {
    // Server owner
    userPerm = 5;
} else if (wlData.includes(message.author.id)) {
    // Whitelisted
    userPerm = 4;
} else if (perms.perms3.includes(message.author.id)) {
    userPerm = 3;
} else if (perms.perms2.includes(message.author.id)) {
    userPerm = 2;
} else if (await db.get(`public_${message.guild.id}`)) {
    userPerm = 1;
}

const requiredPerm = commandFile.help.perms || 1;

if (userPerm < requiredPerm) {
    return denyAccess(requiredPerm);
}

    const now = Date.now();
    const cooldownAmount = (commandFile.help.cooldown || 3) * 1000;

    if (cooldowns.has(message.author.id)) {
      const expirationTime = cooldowns.get(message.author.id) + cooldownAmount;

      if (now < expirationTime) {
        embed.data.description = `Merci d'attendre jusqu'à <t:${Math.floor(expirationTime / 1000)}:R> avant de réutiliser la commande \`${cmd}\`.`
        return message.reply({ embeds: [embed]})
        .then((m) => {
            setTimeout(() => m.delete(), 3000);
        })
      }
    }

    cooldowns.set(message.author.id, now);
    setTimeout(() => cooldowns.delete(message.author.id), cooldownAmount);

    commandFile.run(client, message, args).catch(err => {
      console.error(`[CMD ERROR] ${cmd}:`, err);
      embed.data.description = "`❌` Une erreur est survenue pendant l'exécution de cette commande.";
      message.reply({ embeds: [embed] }).catch(() => {});
    });
  }
};
