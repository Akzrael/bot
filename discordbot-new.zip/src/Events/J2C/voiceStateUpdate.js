const {
    ChannelType,
    PermissionFlagsBits,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    UserSelectMenuBuilder
} = require("discord.js");

const db = require("../../../index.js");

module.exports = {
    name: "voiceStateUpdate",

    async execute(client, oldState, newState) {
        try {
            const guild = newState.guild || oldState.guild;

            if (!guild) return;

            const guildId = guild.id;

            // Single source of truth: the config saved by tempvoc.js
            // (aliased as j2c/jointocreate too — there used to be a
            // separate j2c_<guild> config written by a standalone j2c.js,
            // which this listener also used to read from. That meant
            // configuring via "!tempvoc" silently did nothing here, since
            // this engine was watching a different key entirely. j2c.js is
            // now just an alias for tempvoc.js, so there's only ever one
            // config to read.
            const config = await db.get(`tempvoc_${guildId}`);

            if (!config) return;
            if (!config.triggerChannel) return;

            /*
             * ==========================================
             * MEMBER JOINS THE TRIGGER CHANNEL
             * ==========================================
             */

            if (
                newState.channelId === config.triggerChannel &&
                oldState.channelId !== newState.channelId
            ) {
                const member = newState.member;

                if (!member) return;

                const trigger =
                    guild.channels.cache.get(config.triggerChannel);

                if (!trigger) {
                    console.error(
                        `[TempVoc] Trigger channel ${config.triggerChannel} does not exist.`
                    );

                    return;
                }

                /*
                 * Resolve the configured category.
                 */
                let category = null;

                if (config.category) {
                    const configuredCategory =
                        guild.channels.cache.get(config.category);

                    if (!configuredCategory) {
                        console.error(
                            `[TempVoc] Category ${config.category} was not found.`
                        );
                    } else if (
                        configuredCategory.type !== ChannelType.GuildCategory
                    ) {
                        console.error(
                            `[TempVoc] ${config.category} exists but is not a category.`
                        );
                    } else {
                        category = configuredCategory;
                    }
                }

                /*
                 * Generate the channel name.
                 */
                let channelName =
                    config.name || "🔊・{username}";

                channelName = channelName
                    .replace(
                        /\{username\}/gi,
                        member.user.username
                    )
                    .replace(
                        /\{displayname\}/gi,
                        member.displayName
                    )
                    .slice(0, 100);

                /*
                 * Create the temporary voice channel.
                 */
                const channel = await guild.channels.create({
                    name: channelName,
                    type: ChannelType.GuildVoice,
                    reason:
                        `TempVoc - Salon de ${member.user.tag}`
                });

                /*
                 * Put the channel inside the configured category.
                 */
                if (category) {
                    try {
                        await channel.setParent(
                            category.id,
                            {
                                lockPermissions: true,
                                reason:
                                    "TempVoc - placement dans la catégorie"
                            }
                        );
                    } catch (error) {
                        console.error(
                            "[TempVoc CATEGORY ERROR]",
                            error
                        );

                        await channel.delete(
                            "TempVoc - catégorie impossible"
                        ).catch(() => {});

                        return;
                    }
                }

                /*
                 * Set owner permissions (manage channel, move members, etc.)
                 */
                try {
                    await channel.permissionOverwrites.edit(member.id, {
                        ViewChannel: true,
                        Connect: true,
                        Speak: true,
                        Stream: true,
                        UseVAD: true,
                        ManageChannels: true,
                        MoveMembers: true,
                        MuteMembers: true,
                        DeafenMembers: true,
                        PrioritySpeaker: true
                    });
                } catch (error) {
                    console.error("[TempVoc PERMS ERROR]", error);
                }

                /*
                 * Save the temporary channel ID.
                 */
                const tempChannels =
                    await db.get(`tempvoc_temp_${guildId}`) || [];

                if (!tempChannels.includes(channel.id)) {
                    tempChannels.push(channel.id);
                }

                await db.set(
                    `tempvoc_temp_${guildId}`,
                    tempChannels
                );

                /*
                 * Save owner mapping.
                 */
                const owners = await db.get(`tempvoc_owners_${guildId}`) || {};
                owners[channel.id] = member.id;
                await db.set(`tempvoc_owners_${guildId}`, owners);

                /*
                 * Move the member into the new channel.
                 */
                try {
                    await member.voice.setChannel(channel);
                } catch (error) {
                    console.error(
                        "[TempVoc MOVE ERROR]",
                        error
                    );

                    await channel.delete(
                        "TempVoc - impossible de déplacer le membre"
                    ).catch(() => {});

                    const updated =
                        await db.get(`tempvoc_temp_${guildId}`) || [];

                    await db.set(
                        `tempvoc_temp_${guildId}`,
                        updated.filter(
                            id => id !== channel.id
                        )
                    );

                    const ownersUpdate = await db.get(`tempvoc_owners_${guildId}`) || {};
                    delete ownersUpdate[channel.id];
                    await db.set(`tempvoc_owners_${guildId}`, ownersUpdate);

                    return;
                }

                /*
                 * Send the control panel straight into the new voice
                 * channel's own text chat — no separate panel-channel
                 * config needed anymore, it always lands where the member
                 * actually landed.
                 */
                await this.sendControlPanel(client, channel, member);

                return;
            }

            /*
             * ==========================================
             * OWNER TRANSFER ON DISCONNECT
             * ==========================================
             */
            if (
                oldState.channelId &&
                oldState.channelId !== newState.channelId
            ) {
                const tempChannels =
                    await db.get(`tempvoc_temp_${guildId}`) || [];

                if (
                    !tempChannels.includes(
                        oldState.channelId
                    )
                ) {
                    return;
                }

                const oldChannel =
                    guild.channels.cache.get(
                        oldState.channelId
                    );

                if (!oldChannel) {
                    await db.set(
                        `tempvoc_temp_${guildId}`,
                        tempChannels.filter(
                            id => id !== oldState.channelId
                        )
                    );

                    const ownersUpdate = await db.get(`tempvoc_owners_${guildId}`) || {};
                    delete ownersUpdate[oldState.channelId];
                    await db.set(`tempvoc_owners_${guildId}`, ownersUpdate);

                    return;
                }

                const owners = await db.get(`tempvoc_owners_${guildId}`) || {};
                const ownerId = owners[oldState.channelId];

                if (ownerId === oldState.id && oldChannel.members.size > 0) {
                    const newOwner = oldChannel.members.first();
                    if (newOwner && !newOwner.user.bot) {
                        owners[oldState.channelId] = newOwner.id;
                        await db.set(`tempvoc_owners_${guildId}`, owners);

                        try {
                            await oldChannel.permissionOverwrites.edit(ownerId, {
                                ManageChannels: false,
                                MoveMembers: false,
                                MuteMembers: false,
                                DeafenMembers: false
                            });
                            await oldChannel.permissionOverwrites.edit(newOwner.id, {
                                ViewChannel: true,
                                Connect: true,
                                Speak: true,
                                Stream: true,
                                UseVAD: true,
                                ManageChannels: true,
                                MoveMembers: true,
                                MuteMembers: true,
                                DeafenMembers: true,
                                PrioritySpeaker: true
                            });
                        } catch (error) {
                            console.error("[TempVoc TRANSFER ERROR]", error);
                        }

                        try {
                            const newOwnerMember = await guild.members.fetch(newOwner.id);
                            const dmEmbed = new EmbedBuilder()
                                .setTitle("👑 Transfert de propriété")
                                .setDescription(`Vous êtes maintenant propriétaire du salon **${oldChannel.name}** (l'ancien propriétaire est parti).`)
                                .setColor(0x57F287);
                            await newOwnerMember.send({ embeds: [dmEmbed] }).catch(() => {});
                        } catch (error) {}
                    }
                }

                /*
                 * Delete only when completely empty.
                 */
                if (oldChannel.members.size === 0) {
                    await oldChannel.delete(
                        "TempVoc - salon temporaire vide"
                    ).catch(error => {
                        console.error(
                            "[TempVoc DELETE ERROR]",
                            error
                        );
                    });

                    const updated =
                        await db.get(`tempvoc_temp_${guildId}`) || [];

                    await db.set(
                        `tempvoc_temp_${guildId}`,
                        updated.filter(
                            id => id !== oldState.channelId
                        )
                    );

                    const ownersUpdate = await db.get(`tempvoc_owners_${guildId}`) || {};
                    delete ownersUpdate[oldState.channelId];
                    await db.set(`tempvoc_owners_${guildId}`, ownersUpdate);
                }
            }

        } catch (error) {
            console.error(
                "[TempVoc VOICE EVENT ERROR]",
                error
            );
        }
    },

    async sendControlPanel(client, voiceChannel, owner) {
        try {
            const embed = new EmbedBuilder()
                .setTitle("🎛️ Panneau de contrôle vocal")
                .setDescription(`**Salon:** ${voiceChannel}\n**Propriétaire:** ${owner}`)
                .setColor(0x5865F2)
                .setThumbnail(owner.displayAvatarURL())
                .setFooter({ text: "Ces boutons contrôlent votre salon vocal temporaire" });

            const row1 = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`tempvoc_lock_${voiceChannel.id}`)
                    .setLabel("🔒 Lock")
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId(`tempvoc_unlock_${voiceChannel.id}`)
                    .setLabel("🔓 Unlock")
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId(`tempvoc_hide_${voiceChannel.id}`)
                    .setLabel("🙈 Hide")
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId(`tempvoc_unhide_${voiceChannel.id}`)
                    .setLabel("👁️ Unhide")
                    .setStyle(ButtonStyle.Secondary)
            );

            const row2 = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`tempvoc_mute_${voiceChannel.id}`)
                    .setLabel("🔇 Mute All")
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId(`tempvoc_demute_${voiceChannel.id}`)
                    .setLabel("🔊 Demute All")
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId(`tempvoc_limit_${voiceChannel.id}`)
                    .setLabel("👥 Limit")
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId(`tempvoc_rename_${voiceChannel.id}`)
                    .setLabel("✏️ Rename")
                    .setStyle(ButtonStyle.Primary)
            );

            const row3 = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`tempvoc_kick_${voiceChannel.id}`)
                    .setLabel("👢 Kick")
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId(`tempvoc_transfer_${voiceChannel.id}`)
                    .setLabel("👑 Transfer")
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId(`tempvoc_claim_${voiceChannel.id}`)
                    .setLabel("🏷️ Claim")
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId(`tempvoc_delete_${voiceChannel.id}`)
                    .setLabel("🗑️ Delete")
                    .setStyle(ButtonStyle.Danger)
            );

            // Voice channels have their own built-in text chat in
            // discord.js — .send() works directly on them, so the panel
            // always lands exactly where the member landed instead of a
            // separately configured text channel.
            await voiceChannel.send({
                content: `${owner}`,
                embeds: [embed],
                components: [row1, row2, row3]
            }).catch(() => {});

        } catch (error) {
            console.error("[TempVoc PANEL ERROR]", error);
        }
    }
};
