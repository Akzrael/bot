const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, RoleSelectMenuBuilder, ChannelSelectMenuBuilder, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder } = require('discord.js')

module.exports = {
    name: "interactionCreate",
    /**
     * @param {Client} client
     * @param {Interaction} interaction 
    */
    async execute(client, interaction) {
        if (interaction.guild) {
            const db = client.db(interaction.guild.id);
            if (db && db.modmail) {
                await this.handleModmailInteractions(client, interaction, db);
            }
        }
    },


    async handleModmailInteractions(client, interaction, db) {
        if (interaction.isButton()) {
            if (interaction.customId.startsWith('close_modmail_')) {
                const userId = interaction.customId.split('_')[2];
                await this.handleCloseModmail(client, interaction, userId);
                return;
            }

            if (interaction.customId.startsWith('block_user_')) {
                const userId = interaction.customId.split('_')[2];
                await this.handleBlockUser(client, interaction, userId);
                return;
            }

            if (interaction.customId.startsWith('claim_modmail_')) {
                const userId = interaction.customId.split('_')[2];
                await this.handleClaimModmail(client, interaction, userId);
                return;
            }

            if (interaction.customId.startsWith('unclaim_modmail_')) {
                const userId = interaction.customId.split('_')[2];
                await this.handleUnclaimModmail(client, interaction, userId);
                return;
            }

            if (interaction.customId.startsWith('reopen_modmail_')) {
                const userId = interaction.customId.split('_')[2];
                await this.handleReopenModmail(client, interaction, userId);
                return;
            }

            if (interaction.customId.startsWith('delete_modmail_')) {
                const userId = interaction.customId.split('_')[2];
                await this.handleDeleteModmail(client, interaction, userId);
                return;
            }
        }

        if (interaction.isModalSubmit()) {
            try {
                if (interaction.customId === 'afk_time_modal') {
                    const afkTime = parseInt(interaction.fields.getTextInputValue('afk_time'));

                    if (isNaN(afkTime) || afkTime < 1) {
                        return interaction.reply({ content: '❌ Veuillez entrer un nombre valide (minimum 1 heure).', flags: 64 });
                    }

                    db.modmail.afkTime = afkTime;
                    client.saveDB();

                    await interaction.reply({ content: `✅ Temps AFK modifié à ${afkTime} heures.`, flags: 64 });

                    const embed = this.createMainEmbed(db, interaction.guild);
                    const components = this.createMainComponents();
                    await interaction.message.edit({ embeds: [embed], components });
                }

                if (interaction.customId === 'add_option_modal') {
                    const optionName = interaction.fields.getTextInputValue('option_name');
                    const optionEmoji = interaction.fields.getTextInputValue('option_emoji') || null;

                    if (!db.modmail.options) db.modmail.options = [];

                    const newOption = {
                        name: optionName,
                        emoji: optionEmoji,
                        category: null,
                        staff: [],
                        allowedRoles: [],
                        blockedRoles: []
                    };

                    db.modmail.options.push(newOption);
                    client.saveDB();

                    await interaction.reply({ content: `✅ Option "${optionName}" ajoutée avec succès.`, flags: 64 });

                    const optionIndex = db.modmail.options.length - 1;
                    await this.showOptionConfig(interaction.message, db, optionIndex, interaction.guild);
                }

                if (interaction.customId.startsWith('edit_name_modal_')) {
                    const optionIndex = parseInt(interaction.customId.split('_')[3]);
                    const newName = interaction.fields.getTextInputValue('option_name');

                    if (!newName.trim()) {
                        return interaction.reply({ content: '❌ Le nom ne peut pas être vide.', flags: 64 });
                    }

                    db.modmail.options[optionIndex].name = newName.trim();
                    client.saveDB();

                    await interaction.reply({ content: `✅ Nom modifié en "${newName}".`, flags: 64 });
                    await this.showOptionConfig(interaction.message, db, optionIndex, interaction.guild);
                }

                if (interaction.customId.startsWith('edit_emoji_modal_')) {
                    const optionIndex = parseInt(interaction.customId.split('_')[3]);
                    const newEmoji = interaction.fields.getTextInputValue('option_emoji');

                    db.modmail.options[optionIndex].emoji = newEmoji.trim() || null;
                    client.saveDB();

                    await interaction.reply({ content: `✅ Emoji modifié${newEmoji ? ` en "${newEmoji}"` : ' (supprimé)'}.`, flags: 64 });
                    await this.showOptionConfig(interaction.message, db, optionIndex, interaction.guild);
                }
            } catch (error) {
                console.log('Erreur lors du traitement du modal:', error.message);
                if (!interaction.replied && !interaction.deferred) {
                    try {
                        await interaction.reply({ content: '❌ Une erreur est survenue lors de la modification.', flags: 64 });
                    } catch (e) {
                        console.log('Impossible de répondre à l\'interaction modal');
                    }
                }
            }
            return;
        }
    },

    createMainEmbed(db, guild) {
        return new EmbedBuilder()
            .setTitle("Configuration du Modmail")
            .setColor(0xffffff)
            .addFields(
                { name: "Modmail Actif", value: db.modmail.enabled ? "`✅`" : "`❌`", inline: true },
                { name: "Supprimer si aucune réponse", value: db.modmail.afkDelete ? "`✅`" : "`❌`", inline: true },
                { name: "Temps AFK", value: `\`${db.modmail.afkTime}h\``, inline: true },
                { name: "Système Claim", value: db.modmail.claimSystem ? "`✅`" : "`❌`", inline: true },
                { name: "Transcripts", value: db.modmail.transcripts ? "`✅`" : "`❌`", inline: true },
                { name: "Salon Transcripts", value: db.modmail.transcriptChannel ? `<#${db.modmail.transcriptChannel}>` : "`❌`", inline: true },
                { name: "Staff Global", value: db.modmail.globalStaff && db.modmail.globalStaff.length > 0 ? db.modmail.globalStaff.map(id => `<@&${id}>`).join(', ') : "`❌`", inline: true },
                { name: "Options", value: db.modmail.options && db.modmail.options.length > 0 ? db.modmail.options.map(opt => `${opt.emoji || '📧'} **${opt.name}**`).join('\n') : "`❌`", inline: true }
            );
    },

    createMainComponents() {
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('modmail_main')
            .setPlaceholder('Sélectionnez une option')
            .addOptions([
                {
                    label: 'Activer/Désactiver le modmail',
                    value: 'toggle_modmail',
                    emoji: '🔘'
                },
                {
                    label: 'Activer/Désactiver le système AFK',
                    value: 'toggle_afk',
                    emoji: '🚪'
                },
                {
                    label: 'Modifier le temps d\'AFK',
                    value: 'edit_afk_time',
                    emoji: '⏰'
                },
                {
                    label: 'Activer/Désactiver le système Claim',
                    value: 'toggle_claim',
                    emoji: '🔒'
                },
                {
                    label: 'Activer/Désactiver les transcripts',
                    value: 'toggle_transcripts',
                    emoji: '📄'
                },
                {
                    label: 'Définir le salon des transcripts',
                    value: 'set_transcript_channel',
                    emoji: '📁'
                },
                {
                    label: 'Supprimer le salon transcript',
                    value: 'remove_transcript_channel',
                    emoji: '🗑️'
                },
                {
                    label: 'Ajouter un rôle staff global',
                    value: 'add_global_staff',
                    emoji: '👮'
                },
                {
                    label: 'Supprimer les rôles staff globaux',
                    value: 'remove_global_staff',
                    emoji: '🗑️'
                },
                {
                    label: 'Ajouter une option',
                    value: 'add_option',
                    emoji: '➕'
                },
                {
                    label: 'Modifier une option',
                    value: 'edit_option',
                    emoji: '✏️'
                },
                {
                    label: 'Supprimer une option',
                    value: 'delete_option',
                    emoji: '➖'
                }
            ]);

        return [new ActionRowBuilder().addComponents(selectMenu)];
    },

    async updateMainMessage(msg, db, guild) {
        const embed = this.createMainEmbed(db, guild);
        const components = this.createMainComponents();
        await msg.edit({ embeds: [embed], components });
    },

    async showAfkTimeModal(interaction) {
        const modal = new ModalBuilder()
            .setCustomId('afk_time_modal')
            .setTitle('Modifier le temps AFK')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('afk_time')
                        .setLabel('Temps AFK en heures')
                        .setStyle(TextInputStyle.Short)
                        .setPlaceholder('24')
                        .setRequired(true)
                )
            );

        await interaction.showModal(modal);
    },

    async showAddOptionModal(interaction) {
        const modal = new ModalBuilder()
            .setCustomId('add_option_modal')
            .setTitle('Ajouter une option')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('option_name')
                        .setLabel('Nom de l\'option')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('option_emoji')
                        .setLabel('Emoji de l\'option (optionnel)')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(false)
                )
            );

        await interaction.showModal(modal);
    },

    async showOptionConfig(msg, db, optionIndex, guild) {
        const option = db.modmail.options[optionIndex];
        if (!option) return;

        const embed = new EmbedBuilder()
            .setTitle(`Configuration de l'option: ${option.name}`)
            .setColor(0xffffff)
            .addFields(
                { name: "Nom de l'option", value: `\`${option.name}\``, inline: true },
                { name: "Catégorie de l'option", value: option.category ? `<#${option.category}>` : "`❌`", inline: true },
                { name: "Emoji de l'option", value: option.emoji ? `${option.emoji}` : "`❌`", inline: true },
                { name: "Staff de l'option", value: option.staff && option.staff.length > 0 ? option.staff.map(id => `<@&${id}>`).join(', ') : "`❌`", inline: true },
                { name: "Rôles autorisés", value: option.allowedRoles && option.allowedRoles.length > 0 ? option.allowedRoles.map(id => `<@&${id}>`).join(', ') : "`Tous`", inline: true },
                { name: "Rôles interdits", value: option.blockedRoles && option.blockedRoles.length > 0 ? option.blockedRoles.map(id => `<@&${id}>`).join(', ') : "`Aucun`", inline: true }
            );

        const selector = new StringSelectMenuBuilder()
            .setCustomId(`option_config_${optionIndex}`)
            .setPlaceholder('Modifier les paramètres')
            .addOptions([
                { label: 'Modifier le nom', value: 'edit_name', emoji: '✏️' },
                { label: 'Modifier l\'emoji', value: 'edit_emoji', emoji: '😀' },
                { label: 'Supprimer l\'emoji', value: 'remove_emoji', emoji: '🗑️' },
                { label: 'Modifier la catégorie', value: 'edit_category', emoji: '📁' },
                { label: 'Supprimer la catégorie', value: 'remove_category', emoji: '🗑️' },
                { label: 'Modifier les rôles staff', value: 'edit_staff', emoji: '👮' },
                { label: 'Supprimer les rôles staff', value: 'remove_staff', emoji: '🗑️' },
                { label: 'Modifier les rôles autorisés', value: 'edit_allowed', emoji: '✅' },
                { label: 'Supprimer les rôles autorisés', value: 'remove_allowed', emoji: '🗑️' },
                { label: 'Modifier les rôles interdits', value: 'edit_blocked', emoji: '❌' },
                { label: 'Supprimer les rôles interdits', value: 'remove_blocked', emoji: '🗑️' },
                { label: 'Retour au menu principal', value: 'back_to_main', emoji: '↩️' }
            ]);

        const row = new ActionRowBuilder().addComponents(selector);

        await msg.edit({ embeds: [embed], components: [row] });
    },

    async handleCloseModmail(client, interaction, userId) {
        const db = client.db(interaction.guild.id);
        if (!db.modmail || !db.modmail.activeThreads)
            return interaction.reply({ content: '❌ Aucun modmail actif trouvé.', flags: 64 });

        const threadKey = `${interaction.guild.id}_${userId}`;
        const thread = db.modmail.activeThreads[threadKey];

        if (!thread || thread.channelId !== interaction.channel.id)
            return interaction.reply({ content: '❌ Thread de modmail introuvable.', flags: 64 });

        await interaction.deferUpdate();

        await interaction.channel.permissionOverwrites.edit(userId, { ViewChannel: false });
        delete db.modmail.activeThreads[threadKey];

        if (db.modmail.activeChannels)
            db.modmail.activeChannels = db.modmail.activeChannels.filter(id => id !== interaction.channel.id);

        client.saveDB();

        if (client.modmailThreads)
            client.modmailThreads.delete(threadKey);

        const closeEmbed = new EmbedBuilder()
            .setTitle('🔒 Modmail fermé')
            .setDescription(`Modmail fermé par ${interaction.user}`)
            .setColor(0xff0000)
            .setTimestamp();

        await interaction.channel.send({ embeds: [closeEmbed] });

        if (db.modmail && db.modmail.transcripts && db.modmail.transcriptChannel)
            await this.createModmailTranscript(client, interaction, userId, thread);

        try {
            const user = await client.users.fetch(userId);
            const dmEmbed = new EmbedBuilder()
                .setTitle('🔒 Modmail fermé')
                .setDescription(`Votre modmail sur **${interaction.guild.name}** a été fermé par le staff.`)
                .setColor(0xff0000);

            await user.send({ embeds: [dmEmbed] });
        } catch (error) {
            console.log('Impossible d\'envoyer le DM de fermeture');
        }

        const closedButtons = this.createModmailButtons(db, userId, true, false);

        await interaction.message.edit({ components: [closedButtons] });
    },

    async handleBlockUser(client, interaction, userId) {
        const db = client.db(interaction.guild.id);
        if (!db.modmail) return interaction.reply({ content: '❌ Modmail non configuré.', flags: 64 });

        if (!db.modmail.blockedUsers) db.modmail.blockedUsers = [];

        if (db.modmail.blockedUsers.includes(userId))
            return interaction.reply({ flags: 64, content: '❌ Cet utilisateur est déjà bloqué.' });

        await interaction.deferUpdate();

        db.modmail.blockedUsers.push(userId);
        client.saveDB();

        if (db.modmail.activeThreads) {
            const threadKey = `${interaction.guild.id}_${userId}`;
            const thread = db.modmail.activeThreads[threadKey];

            if (thread && thread.channelId === interaction.channel.id) {
                try {
                    await interaction.channel.permissionOverwrites.edit(userId, { ViewChannel: false });
                } catch (error) {
                    console.error('Erreur lors de la suppression des permissions:', error);
                }

                delete db.modmail.activeThreads[threadKey];
                if (db.modmail.activeChannels)
                    db.modmail.activeChannels = db.modmail.activeChannels.filter(id => id !== interaction.channel.id);

                client.saveDB();

                if (client.modmailThreads)
                    client.modmailThreads.delete(threadKey);

                const blockEmbed = new EmbedBuilder()
                    .setTitle('🚫 Utilisateur bloqué')
                    .setDescription(`Utilisateur bloqué par ${interaction.user} et modmail fermé.`)
                    .setColor(0x000000)
                    .setTimestamp();

                await interaction.channel.send({ embeds: [blockEmbed] });
            }
        }

        try {
            const user = await client.users.fetch(userId);
            const dmEmbed = new EmbedBuilder()
                .setTitle('🚫 Accès bloqué')
                .setDescription(`Vous avez été bloqué du système modmail de **${interaction.guild.name}**.`)
                .setColor(0x000000);

            await user.send({ embeds: [dmEmbed] });
        } catch (error) { }

        await interaction.followUp({ content: '✅ Utilisateur bloqué avec succès.', flags: 64 });
    },

    async handleClaimModmail(client, interaction, userId) {
        const db = client.db(interaction.guild.id);
        if (!db.modmail || !db.modmail.activeThreads)
            return interaction.reply({ flags: 64, content: '❌ Aucun modmail actif trouvé.' });

        const threadKey = `${interaction.guild.id}_${userId}`;
        const thread = db.modmail.activeThreads[threadKey];

        if (!thread || thread.channelId !== interaction.channel.id)
            return interaction.reply({ flags: 64, content: '❌ Thread de modmail introuvable.' });

        if (thread.claimedBy)
            return interaction.reply({ flags: 64, content: '❌ Ce modmail est déjà claim.' });

        await interaction.deferUpdate();

        thread.claimedBy = interaction.user.id;
        db.modmail.activeThreads[threadKey] = thread;
        client.saveDB();

        if (!client.modmailThreads) client.modmailThreads = new Map();
        client.modmailThreads.set(threadKey, thread);

        const claimEmbed = new EmbedBuilder()
            .setColor(0x00ff00)
            .setDescription(`${interaction.user} a claim ce modmail`);

        await interaction.channel.send({ embeds: [claimEmbed] });

        try {
            const option = db.modmail.options.find(opt => opt.name === thread.optionName);

            if (option && option.staff) {
                for (const roleId of option.staff)
                    await interaction.channel.permissionOverwrites.edit(roleId, { ViewChannel: false });
            }

            if (db.modmail.globalStaff) {
                for (const roleId of db.modmail.globalStaff)
                    await interaction.channel.permissionOverwrites.edit(roleId, { ViewChannel: false });
            }

            await interaction.channel.permissionOverwrites.edit(interaction.user.id, {
                ViewChannel: true,
                SendMessages: true,
                ReadMessageHistory: true
            });
        } catch (error) { }

        const newControlButtons = this.createModmailButtons(db, userId, false, true);
        await interaction.message.edit({ components: [newControlButtons] });
    },

    async handleUnclaimModmail(client, interaction, userId) {
        const db = client.db(interaction.guild.id);
        if (!db.modmail || !db.modmail.activeThreads)
            return interaction.reply({ flags: 64, content: '❌ Aucun modmail actif trouvé.' });

        const threadKey = `${interaction.guild.id}_${userId}`;
        const thread = db.modmail.activeThreads[threadKey];

        if (!thread || thread.channelId !== interaction.channel.id)
            return interaction.reply({ flags: 64, content: '❌ Thread de modmail introuvable.' });

        if (thread.claimedBy !== interaction.user.id)
            return interaction.reply({ flags: 64, content: '❌ Vous ne pouvez pas unclaim ce modmail.' });

        await interaction.deferUpdate();

        thread.claimedBy = null;
        db.modmail.activeThreads[threadKey] = thread;
        client.saveDB();

        if (!client.modmailThreads) client.modmailThreads = new Map();
        client.modmailThreads.set(threadKey, thread);

        const unclaimEmbed = new EmbedBuilder()
            .setColor(0xff9900)
            .setDescription(`${interaction.user} a unclaim ce modmail`);

        await interaction.channel.send({ embeds: [unclaimEmbed] });

        try {
            const option = db.modmail.options.find(opt => opt.name === thread.optionName);

            if (option && option.staff) {
                for (const roleId of option.staff)
                    await interaction.channel.permissionOverwrites.edit(roleId, {
                        ViewChannel: true,
                        SendMessages: true,
                        ReadMessageHistory: true
                    });
            }

            if (db.modmail.globalStaff) {
                for (const roleId of db.modmail.globalStaff)
                    await interaction.channel.permissionOverwrites.edit(roleId, {
                        ViewChannel: true,
                        SendMessages: true,
                        ReadMessageHistory: true
                    });
            }
        } catch (error) { }

        const newControlButtons = this.createModmailButtons(db, userId, false, false);
        await interaction.message.edit({ components: [newControlButtons] });
    },

    async handleReopenModmail(client, interaction, userId) {
        const db = client.db(interaction.guild.id);
        if (!db.modmail)
            return interaction.reply({ content: '❌ Modmail non configuré.', flags: 64 });

        if (db.modmail.blockedUsers && db.modmail.blockedUsers.includes(userId))
            return interaction.reply({ content: '❌ Impossible de rouvrir : utilisateur bloqué.', flags: 64 });

        const threadKey = `${interaction.guild.id}_${userId}`;

        if (db.modmail.activeThreads && db.modmail.activeThreads[threadKey])
            return interaction.reply({ content: '❌ Ce modmail est déjà ouvert.', flags: 64 });

        await interaction.deferUpdate();

        try {
            await interaction.channel.permissionOverwrites.edit(userId, {
                ViewChannel: true,
                SendMessages: true,
                ReadMessageHistory: true
            });
        } catch (error) {
            console.error('Erreur lors de la restauration des permissions:', error);
        }

        if (!db.modmail.activeThreads) db.modmail.activeThreads = {};
        if (!db.modmail.activeChannels) db.modmail.activeChannels = [];

        const newThread = {
            userId: userId,
            channelId: interaction.channel.id,
            createdAt: Date.now(),
            lastActivity: Date.now(),
            optionName: 'Général',
            claimedBy: null
        };

        db.modmail.activeThreads[threadKey] = newThread;
        if (!db.modmail.activeChannels.includes(interaction.channel.id)) {
            db.modmail.activeChannels.push(interaction.channel.id);
        }

        client.saveDB();

        if (!client.modmailThreads) client.modmailThreads = new Map();
        client.modmailThreads.set(threadKey, newThread);

        const reopenEmbed = new EmbedBuilder()
            .setTitle('🔓 Modmail rouvert')
            .setDescription(`Modmail rouvert par ${interaction.user}`)
            .setColor(0x00ff00)
            .setTimestamp();

        await interaction.channel.send({ embeds: [reopenEmbed] });

        try {
            const user = await client.users.fetch(userId);
            const dmEmbed = new EmbedBuilder()
                .setTitle('🔓 Modmail rouvert')
                .setDescription(`Votre modmail sur **${interaction.guild.name}** a été rouvert par le staff. Vous pouvez à nouveau envoyer des messages.`)
                .setColor(0x00ff00);

            await user.send({ embeds: [dmEmbed] });
        } catch (error) {
            console.log('Impossible d\'envoyer le DM de réouverture');
        }

        const controlButtons = this.createModmailButtons(db, userId, false, false);
        await interaction.message.edit({ components: [controlButtons] });
    },

    async handleDeleteModmail(client, interaction, userId) {
        await interaction.deferUpdate();

        const deleteEmbed = new EmbedBuilder()
            .setTitle('🗑️ Modmail supprimé')
            .setDescription(`Modmail supprimé par ${interaction.user}`)
            .setColor(0x000000)
            .setTimestamp();

        await interaction.channel.send({ embeds: [deleteEmbed] });

        setTimeout(() => {
            interaction.channel.delete().catch(console.error);
        }, 2000);

        await interaction.followUp({
            content: '✅ Le salon sera supprimé dans 2 secondes...',
            flags: 64
        });
    },

    async createModmailTranscript(client, interaction, userId, thread) {
        const db = client.db(interaction.guild.id);
        if (!db.modmail || !db.modmail.transcripts || !db.modmail.transcriptChannel) return;

        try {
            const transcriptChannel = await interaction.guild.channels.fetch(db.modmail.transcriptChannel).catch(() => null);
            if (!transcriptChannel) return;

            // Fallback vers transcript texte simple
            const messages = await interaction.channel.messages.fetch({ limit: 100 });
            const sortedMessages = messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);

            let transcript = `=== TRANSCRIPT MODMAIL ===\n`;
            transcript += `Utilisateur: ${thread.userId}\n`;
            transcript += `Salon: ${interaction.channel.name}\n`;
            transcript += `Créé le: ${new Date(thread.createdAt).toLocaleString('fr-FR')}\n`;
            transcript += `Fermé le: ${new Date().toLocaleString('fr-FR')}\n`;
            transcript += `Fermé par: ${interaction.user.tag}\n`;
            if (thread.claimedBy) {
                const claimedUser = await client.users.fetch(thread.claimedBy).catch(() => null);
                transcript += `Claim par: ${claimedUser ? claimedUser.tag : 'Utilisateur introuvable'}\n`;
            }
            transcript += `\n=== MESSAGES ===\n\n`;

            for (const message of sortedMessages.values()) {
                if (message.author.bot && !message.webhookId) continue;

                const timestamp = new Date(message.createdTimestamp).toLocaleString('fr-FR');
                const author = message.webhookId ? message.author.username : message.author.tag;

                transcript += `[${timestamp}] ${author}: ${message.content || '*Message sans contenu*'}\n`;

                if (message.attachments.size > 0) {
                    transcript += `   Pièces jointes: ${Array.from(message.attachments.values()).map(att => att.url).join(', ')}\n`;
                }
                transcript += '\n';
            }

            const buffer = Buffer.from(transcript, 'utf-8');
            const attachment = {
                attachment: buffer,
                name: `modmail-${userId}-${Date.now()}.txt`
            };

            const user = await client.users.fetch(userId).catch(() => null);
            const transcriptEmbed = new EmbedBuilder()
                .setTitle('📄 Transcript Modmail')
                .setColor(0xffffff)
                .addFields([
                    {
                        name: '👤 Utilisateur',
                        value: user ? `${user.tag} (${userId})` : `ID: ${userId}`,
                        inline: true
                    },
                    {
                        name: '📅 Fermé le',
                        value: `<t:${Math.floor(Date.now() / 1000)}:F>`,
                        inline: true
                    },
                    {
                        name: '👮 Fermé par',
                        value: interaction.user.tag,
                        inline: true
                    }
                ])
                .setTimestamp();

            if (thread.claimedBy) {
                const claimedUser = await client.users.fetch(thread.claimedBy).catch(() => null);
                transcriptEmbed.addFields([{
                    name: '🔒 Claim par',
                    value: claimedUser ? claimedUser.tag : 'Utilisateur introuvable',
                    inline: true
                }]);
            }

            await transcriptChannel.send({
                embeds: [transcriptEmbed],
                files: [attachment]
            });

        } catch (error) {
            console.error('Erreur lors de la création du transcript:', error);
        }
    },

    createModmailButtons(db, userId, isClosed = false, isClaimed = false) {
        const buttons = [];

        if (!isClosed) {
            // Boutons pour modmail ouvert
            buttons.push(
                new ButtonBuilder()
                    .setCustomId(`close_modmail_${userId}`)
                    .setLabel('Fermer')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒')
            );

            // Bouton claim seulement si le système est activé
            if (db.modmail && db.modmail.claimSystem) {
                if (!isClaimed) {
                    buttons.push(
                        new ButtonBuilder()
                            .setCustomId(`claim_modmail_${userId}`)
                            .setLabel('Claim')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji('🔒')
                    );
                } else {
                    buttons.push(
                        new ButtonBuilder()
                            .setCustomId(`unclaim_modmail_${userId}`)
                            .setLabel('Unclaim')
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji('🔓')
                    );
                }
            }

            buttons.push(
                new ButtonBuilder()
                    .setCustomId(`block_user_${userId}`)
                    .setLabel('Bloquer')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🚫'),
                new ButtonBuilder()
                    .setCustomId(`reopen_modmail_${userId}`)
                    .setLabel('Rouvrir')
                    .setStyle(ButtonStyle.Success)
                    .setDisabled(true)
                    .setEmoji('🔓'),
                new ButtonBuilder()
                    .setCustomId(`delete_modmail_${userId}`)
                    .setLabel('Supprimer')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(true)
                    .setEmoji('🗑️')
            );
        } else {
            // Boutons pour modmail fermé
            buttons.push(
                new ButtonBuilder()
                    .setCustomId('closed_fermer')
                    .setLabel('Fermé')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🔒')
                    .setDisabled(true)
            );

            // Bouton claim désactivé seulement si le système était activé
            if (db.modmail && db.modmail.claimSystem) {
                buttons.push(
                    new ButtonBuilder()
                        .setCustomId('closed_claim')
                        .setLabel('Claim')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🔒')
                        .setDisabled(true)
                );
            }

            buttons.push(
                new ButtonBuilder()
                    .setCustomId(`block_user_${userId}`)
                    .setLabel('Bloquer')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🚫'),
                new ButtonBuilder()
                    .setCustomId(`reopen_modmail_${userId}`)
                    .setLabel('Rouvrir')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('🔓'),
                new ButtonBuilder()
                    .setCustomId(`delete_modmail_${userId}`)
                    .setLabel('Supprimer')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🗑️')
            );
        }

        return new ActionRowBuilder().addComponents(buttons);
    },};
