const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js')

module.exports = {
    name: "messageCreate",
    /**
     * @param {Client} client
     * @param {Message} message 
    */
    async execute(client, message) {
        // Gestion des DM pour le modmail
        if (message.channel.type === ChannelType.DM && !message.author.bot) {
            await this.handleModmailDM(client, message);
            return;
        }

        // Gestion des messages dans les salons de modmail
        if (message.inGuild() && !message.author.bot) {
            await this.handleModmailChannel(client, message);
        }
    },


    async handleModmailDM(client, message) {
        if (!client.modmailThreads) client.modmailThreads = new Map();

        let activeThread = null;
        let activeGuild = null;
        let activeDb = null;
        let threadKey = null;

        for (const guild of client.guilds.cache.values()) {
            const db = client.db(guild.id);
            if (!db || !db.modmail || !db.modmail.activeThreads) continue;

            for (const [key, thread] of Object.entries(db.modmail.activeThreads)) {
                if (thread.userId === message.author.id) {
                    const channel = guild.channels.cache.get(thread.channelId);
                    if (channel) {
                        if (!activeThread || thread.lastActivity > activeThread.lastActivity) {
                            activeThread = thread;
                            activeGuild = guild;
                            activeDb = db;
                            threadKey = key;
                        }
                    } else {
                        delete db.modmail.activeThreads[key];
                        if (db.modmail.activeChannels) {
                            db.modmail.activeChannels = db.modmail.activeChannels.filter(id => id !== thread.channelId);
                        }
                        client.saveDB();
                    }
                }
            }
        }

        if (activeThread && activeGuild && activeDb) {
            const channel = activeGuild.channels.cache.get(activeThread.channelId);

            activeThread.lastActivity = Date.now();
            activeDb.modmail.activeThreads[threadKey] = activeThread;
            client.saveDB();

            client.modmailThreads.set(threadKey, activeThread);

            try {
                let webhook = await this.getOrCreateWebhook(channel);

                let messageContent = message.content || '';

                if (message.attachments.size > 0 && !messageContent) {
                    messageContent = '*Image/Fichier envoyé*';
                }

                await webhook.send({
                    content: messageContent,
                    username: message.author.displayName || message.author.username,
                    avatarURL: message.author.displayAvatarURL(),
                    files: Array.from(message.attachments.values())
                });

                await message.react('✅');
                return;
            } catch (error) {
                console.error('Erreur lors du transfert du message:', error);
                await message.react('❌');
                return;
            }
        }

        const guilds = client.guilds.cache.filter(guild => {
            const member = guild.members.cache.get(message.author.id);
            if (!member) return false;

            const db = client.db(guild.id);
            return db && db.modmail && db.modmail.enabled;
        });

        if (guilds.size === 0) return;

        if (guilds.size === 1) {
            const guild = guilds.first();
            const db = client.db(guild.id);
            return this.createModmailSelector(client, message, guild, db);
        }

        const guildSelector = new StringSelectMenuBuilder()
            .setCustomId('guild_selector')
            .setPlaceholder('Sélectionnez un serveur')
            .addOptions(
                guilds.map(guild => ({
                    label: guild.name,
                    value: guild.id,
                    description: `${guild.memberCount} membres`
                }))
            );

        const row = new ActionRowBuilder().addComponents(guildSelector);
        const embed = new EmbedBuilder()
            .setTitle('📧 Modmail')
            .setDescription('Sélectionnez le serveur pour lequel vous souhaitez ouvrir un modmail.')
            .setColor(0xffffff);

        await message.reply({ embeds: [embed], components: [row] });

        const collector = message.channel.createMessageComponentCollector({ time: 60000 });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== message.author.id) return;

            if (interaction.customId === 'guild_selector') {
                const guildId = interaction.values[0];
                const guild = client.guilds.cache.get(guildId);
                const db = client.db(guildId);

                await interaction.deferUpdate();
                await this.createModmailSelector(client, message, guild, db, interaction);
            }
        });

        collector.on('end', () => {
            message.edit({ components: [] }).catch(() => { });
        });
    },

    async handleModmailChannel(client, message) {
        const db = client.db(message.guild.id);
        if (!db || !db.modmail || !db.modmail.enabled) return;

        if (!db.modmail.activeChannels || !db.modmail.activeChannels.includes(message.channel.id)) return;

        if (!client.modmailThreads) client.modmailThreads = new Map();

        if (!db.modmail.activeThreads) return;

        let thread = null;
        let threadKey = null;

        for (const [key, threadData] of Object.entries(db.modmail.activeThreads)) {
            if (threadData.channelId === message.channel.id) {
                thread = threadData;
                threadKey = key;
                break;
            }
        }

        if (!thread) return;

        thread.lastActivity = Date.now();
        db.modmail.activeThreads[threadKey] = thread;
        client.saveDB();

        client.modmailThreads.set(threadKey, thread);

        if (message.author.id === thread.userId) return;

        const member = message.guild.members.cache.get(message.author.id);
        const isGlobalStaff = db.modmail.globalStaff.some(roleId => member.roles.cache.has(roleId));

        const option = db.modmail.options.find(opt => opt.name === thread.optionName);
        const isOptionStaff = option && option.staff.some(roleId => member.roles.cache.has(roleId));

        if (!isGlobalStaff && !isOptionStaff && !member.permissions.has('Administrator')) return;

        try {
            const user = await client.users.fetch(thread.userId);

            let messageContent = message.content || '';

            if (message.attachments.size > 0 && !messageContent) {
                messageContent = '*Image/Fichier envoyé*';
            }

            const staffInfo = `**${message.author.displayName || message.author.username}** (${message.guild.name})`;
            const fullMessage = `${staffInfo}:\n${messageContent}`;

            await user.send({
                content: fullMessage,
                files: Array.from(message.attachments.values())
            });

            await message.react('✅');

        } catch (error) {
            console.error('Erreur lors de l\'envoi du message DM:', error);
            await message.react('❌');

            const errorEmbed = new EmbedBuilder()
                .setDescription('❌ Impossible d\'envoyer le message à l\'utilisateur (DM fermés ou utilisateur introuvable)')
                .setColor(0xff0000);

            await message.reply({ embeds: [errorEmbed] });
        }
    },
    async createModmailSelector(client, message, guild, db, interaction = null) {
        if (db.modmail.blockedUsers && db.modmail.blockedUsers.includes(message.author.id)) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Accès refusé')
                .setDescription('Vous êtes bloqué du système modmail de ce serveur.')
                .setColor(0xff0000);

            if (interaction) {
                return interaction.editReply({ embeds: [embed], components: [] });
            } else {
                return message.reply({ embeds: [embed] });
            }
        }

        if (!db.modmail.options || db.modmail.options.length === 0) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Aucune option configurée')
                .setDescription('Le modmail est activé mais aucune option n\'est configurée sur ce serveur.')
                .setColor(0xff0000);

            if (interaction) {
                return interaction.editReply({ embeds: [embed], components: [] });
            } else {
                return message.reply({ embeds: [embed] });
            }
        }

        const member = guild.members.cache.get(message.author.id);
        const availableOptions = db.modmail.options.filter(option => {
            if (option.blockedRoles && option.blockedRoles.length > 0) {
                const hasBlockedRole = option.blockedRoles.some(roleId => member.roles.cache.has(roleId));
                if (hasBlockedRole) return false;
            }

            if (option.allowedRoles && option.allowedRoles.length > 0) {
                const hasAllowedRole = option.allowedRoles.some(roleId => member.roles.cache.has(roleId));
                if (!hasAllowedRole) return false;
            }

            return true;
        });

        if (availableOptions.length === 0) {
            const embed = new EmbedBuilder()
                .setTitle('❌ Aucune option disponible')
                .setDescription('Vous n\'avez accès à aucune option de modmail sur ce serveur.')
                .setColor(0xff0000);

            if (interaction) {
                return interaction.editReply({ embeds: [embed], components: [] });
            } else {
                return message.reply({ embeds: [embed] });
            }
        }

        const optionSelector = new StringSelectMenuBuilder()
            .setCustomId(`modmail_option_${guild.id}`)
            .setPlaceholder('Sélectionnez le type de votre demande')
            .addOptions(
                availableOptions.map((option, index) => ({
                    label: option.name,
                    value: index.toString(),
                    emoji: option.emoji || '📧'
                }))
            );

        const row = new ActionRowBuilder().addComponents(optionSelector);
        const embed = new EmbedBuilder()
            .setTitle(`📧 Modmail - ${guild.name}`)
            .setDescription('Sélectionnez le type de votre demande :')
            .setColor(0xffffff)
            .setThumbnail(guild.iconURL());

        if (interaction) {
            await interaction.editReply({ embeds: [embed], components: [row] });
        } else {
            await message.reply({ embeds: [embed], components: [row] });
        }

        const optionCollector = message.channel.createMessageComponentCollector({ time: 300000 });

        optionCollector.on('collect', async optionInteraction => {
            if (optionInteraction.user.id !== message.author.id) return;

            if (optionInteraction.customId === `modmail_option_${guild.id}`) {
                const optionIndex = parseInt(optionInteraction.values[0]);
                const selectedOption = availableOptions[optionIndex];

                await optionInteraction.deferUpdate();
                await this.createModmailThread(client, message, guild, db, selectedOption, optionInteraction);
            }
        });

        optionCollector.on('end', () => {
            if (interaction) {
                interaction.editReply({ components: [] }).catch(() => { });
            } else {
                message.edit({ components: [] }).catch(() => { });
            }
        });
    },

    async createModmailThread(client, message, guild, db, option, interaction) {
        try {
            if (!client.modmailThreads) client.modmailThreads = new Map();

            const threadKey = `${guild.id}_${message.author.id}`;
            let existingThread = null;

            if (db.modmail.activeThreads && db.modmail.activeThreads[threadKey]) {
                existingThread = db.modmail.activeThreads[threadKey];
                const channel = guild.channels.cache.get(existingThread.channelId);
                if (channel) {
                    const embed = new EmbedBuilder()
                        .setTitle('❌ Modmail déjà ouvert')
                        .setDescription(`Vous avez déjà un modmail ouvert : ${channel}`)
                        .setColor(0xff0000);

                    return interaction.editReply({ embeds: [embed], components: [] });
                } else {
                    delete db.modmail.activeThreads[threadKey];
                    if (db.modmail.activeChannels) {
                        db.modmail.activeChannels = db.modmail.activeChannels.filter(id => id !== existingThread.channelId);
                    }
                    client.saveDB();
                }
            }

            const category = guild.channels.cache.get(option.category);
            const channelName = `modmail-${message.author.username}`.toLowerCase().replace(/[^a-z0-9-]/g, '');

            const modmailChannel = await guild.channels.create({
                name: channelName,
                type: ChannelType.GuildText,
                parent: category,
                topic: `Modmail de ${message.author.tag} (${message.author.id}) - ${option.name}`,
                permissionOverwrites: [
                    {
                        id: guild.id,
                        deny: [PermissionFlagsBits.ViewChannel]
                    },
                    {
                        id: message.author.id,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
                    },
                    ...db.modmail.globalStaff.map(roleId => ({
                        id: roleId,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
                    })),
                    ...option.staff.map(roleId => ({
                        id: roleId,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
                    }))
                ]
            });

            if (!db.modmail.activeThreads) db.modmail.activeThreads = {};
            if (!db.modmail.activeChannels) db.modmail.activeChannels = [];

            db.modmail.activeThreads[`${guild.id}_${message.author.id}`] = {
                channelId: modmailChannel.id,
                userId: message.author.id,
                guildId: guild.id,
                optionName: option.name,
                createdAt: Date.now(),
                lastActivity: Date.now(),
                claimedBy: null
            };

            db.modmail.activeChannels.push(modmailChannel.id);
            client.saveDB();

            if (!client.modmailThreads) client.modmailThreads = new Map();
            client.modmailThreads.set(`${guild.id}_${message.author.id}`, db.modmail.activeThreads[`${guild.id}_${message.author.id}`]);

            const infoEmbed = new EmbedBuilder()
                .setTitle(`📧 Nouveau Modmail - ${option.name}`)
                .setDescription(`**Utilisateur:** ${message.author} (${message.author.tag})\n**ID:** ${message.author.id}\n**Type:** ${option.name}`)
                .setThumbnail(message.author.displayAvatarURL())
                .setColor(0xffffff)
                .setTimestamp();

            const controlButtons = this.createModmailButtons(db, message.author.id, false, false);

            await modmailChannel.send({
                embeds: [infoEmbed],
                components: [controlButtons],
                content: option.staff.length > 0 ? option.staff.map(id => `<@&${id}>`).join(' ') : (db.modmail.globalStaff.length > 0 ? db.modmail.globalStaff.map(id => `<@&${id}>`).join(' ') : null)
            });

            if (message.content || message.attachments.size > 0) {
                try {
                    let webhook = await this.getOrCreateWebhook(modmailChannel);

                    let messageContent = message.content || '';
                    if (message.attachments.size > 0 && !messageContent)
                        messageContent = '*Image/Fichier envoyé*';

                    if (message.attachments.size == 0 && !messageContent) return;

                    await webhook.send({
                        content: messageContent,
                        username: message.author.displayName || message.author.username,
                        avatarURL: message.author.displayAvatarURL(),
                        files: Array.from(message.attachments.values())
                    });
                } catch (error) { }
            }

            const confirmEmbed = new EmbedBuilder()
                .setTitle('✅ Modmail créé')
                .setDescription(`Votre modmail a été créé avec succès sur **${guild.name}**.\nType: **${option.name}**\n\nVous pouvez maintenant envoyer vos messages ici, ils seront transmis au staff.`)
                .setColor(0x00ff00);

            await interaction.editReply({ embeds: [confirmEmbed], components: [] });

            if (db.modmail.afkDelete)
                setTimeout(() => {
                    this.checkAndCloseInactiveModmail(client, guild.id, message.author.id, db.modmail.afkTime);
                }, db.modmail.afkTime * 60 * 60 * 1000);

        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Erreur')
                .setDescription('Une erreur est survenue lors de la création du modmail.')
                .setColor(0xff0000);

            await interaction.editReply({ embeds: [errorEmbed], components: [] });
        }
    },

    async checkAndCloseInactiveModmail(client, guildId, userId, afkTimeHours) {
        const guild = client.guilds.cache.get(guildId);
        if (!guild) return;

        const db = client.db(guildId);
        if (!db || !db.modmail || !db.modmail.activeThreads) return;

        const threadKey = `${guildId}_${userId}`;
        const thread = db.modmail.activeThreads[threadKey];

        if (!thread) return;

        const channel = guild.channels.cache.get(thread.channelId);
        if (!channel) {
            delete db.modmail.activeThreads[threadKey];
            if (db.modmail.activeChannels) {
                db.modmail.activeChannels = db.modmail.activeChannels.filter(id => id !== thread.channelId);
            }
            client.saveDB();
            if (client.modmailThreads) {
                client.modmailThreads.delete(threadKey);
            }
            return;
        }

        const timeSinceLastActivity = Date.now() - thread.lastActivity;
        const afkTimeMs = afkTimeHours * 60 * 60 * 1000;

        if (timeSinceLastActivity >= afkTimeMs) {
            const messages = await channel.messages.fetch({ limit: 50 });
            const userMessages = messages.filter(msg =>
                msg.author.id === userId &&
                msg.createdTimestamp > thread.lastActivity
            );

            if (userMessages.size === 0) {
                const closeEmbed = new EmbedBuilder()
                    .setTitle('⏰ Modmail fermé automatiquement')
                    .setDescription(`Ce modmail a été fermé automatiquement après ${afkTimeHours}h d'inactivité.`)
                    .setColor(0xff9900)
                    .setTimestamp();

                await channel.send({ embeds: [closeEmbed] });

                await channel.permissionOverwrites.edit(userId, { ViewChannel: false });

                delete db.modmail.activeThreads[threadKey];
                if (db.modmail.activeChannels) {
                    db.modmail.activeChannels = db.modmail.activeChannels.filter(id => id !== thread.channelId);
                }
                client.saveDB();

                if (client.modmailThreads) {
                    client.modmailThreads.delete(threadKey);
                }

                try {
                    const user = await client.users.fetch(userId);
                    const dmEmbed = new EmbedBuilder()
                        .setTitle('⏰ Modmail fermé')
                        .setDescription(`Votre modmail sur **${guild.name}** a été fermé automatiquement après ${afkTimeHours}h d'inactivité.`)
                        .setColor(0xff9900);

                    await user.send({ embeds: [dmEmbed] });
                } catch (error) {
                    console.log('Impossible d\'envoyer le DM de fermeture automatique');
                }
            }
        }
    },

    async getOrCreateWebhook(channel) {
        try {
            const webhooks = await channel.fetchWebhooks();
            let webhook = webhooks.find(wh => wh.name === 'Modmail Webhook');

            if (!webhook) {
                webhook = await channel.createWebhook({
                    name: 'Modmail Webhook',
                    avatar: null,
                    reason: 'Webhook pour le système modmail'
                });
            }

            return webhook;
        } catch (error) {
            console.error('Erreur lors de la création/récupération du webhook:', error);
            throw error;
        }
    },

    createModmailButtons(db, userId, isClosed = false, isClaimed = false) {
        const buttons = [];

        if (!isClosed) {
            // Boutons pour modmail ouvert - Maximum 4 boutons pour éviter les erreurs
            buttons.push(
                new ButtonBuilder()
                    .setCustomId(`close_modmail_${userId}`)
                    .setLabel('Fermer')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒')
            );

            // Bouton claim seulement si le système est activé
            if (db.modmail && db.modmail.claimSystem) {
                if (!isClaimed) {
                    buttons.push(
                        new ButtonBuilder()
                            .setCustomId(`claim_modmail_${userId}`)
                            .setLabel('Claim')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji('🔒')
                    );
                } else {
                    buttons.push(
                        new ButtonBuilder()
                            .setCustomId(`unclaim_modmail_${userId}`)
                            .setLabel('Unclaim')
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji('🔓')
                    );
                }
            }

            buttons.push(
                new ButtonBuilder()
                    .setCustomId(`block_user_${userId}`)
                    .setLabel('Bloquer')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🚫')
            );

            // Ajouter les boutons désactivés seulement s'il y a de la place (max 5 boutons)
            if (buttons.length <= 3) {
                buttons.push(
                    new ButtonBuilder()
                        .setCustomId(`reopen_modmail_${userId}`)
                        .setLabel('Rouvrir')
                        .setStyle(ButtonStyle.Success)
                        .setDisabled(true)
                        .setEmoji('🔓')
                );
            }
            if (buttons.length <= 4) {
                buttons.push(
                    new ButtonBuilder()
                        .setCustomId(`delete_modmail_${userId}`)
                        .setLabel('Supprimer')
                        .setStyle(ButtonStyle.Danger)
                        .setDisabled(true)
                        .setEmoji('🗑️')
                );
            }
        } else {
            // Boutons pour modmail fermé
            buttons.push(
                new ButtonBuilder()
                    .setCustomId('closed_fermer')
                    .setLabel('Fermé')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🔒')
                    .setDisabled(true)
            );

            // Bouton claim désactivé seulement si le système était activé
            if (db.modmail && db.modmail.claimSystem) {
                buttons.push(
                    new ButtonBuilder()
                        .setCustomId('closed_claim')
                        .setLabel('Claim')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🔒')
                        .setDisabled(true)
                );
            }

            buttons.push(
                new ButtonBuilder()
                    .setCustomId(`block_user_${userId}`)
                    .setLabel('Bloquer')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🚫'),
                new ButtonBuilder()
                    .setCustomId(`reopen_modmail_${userId}`)
                    .setLabel('Rouvrir')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('🔓'),
                new ButtonBuilder()
                    .setCustomId(`delete_modmail_${userId}`)
                    .setLabel('Supprimer')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🗑️')
            );
        }

        return new ActionRowBuilder().addComponents(buttons);
    }
};