const { getVectorConfig, registerHit, punish } = require("../../../Structure/AntiNuke.js");

// No 'g' flag: this regex is a shared module-level constant used with .test()
// on every message. With 'g', .test() advances lastIndex on each match and
// resumes from there next call, causing intermittent false-negatives once
// lastIndex drifts past the end of a later message's content.
const LINK_REGEX = /https?:\/\/[^\s]+/i;

module.exports = {
    name: "messageCreate",
    async execute(client, message) {
        if (!message.guild || message.author.bot) return;
        if (message.member?.permissions.has("Administrator")) return;

        const config = await getVectorConfig(message.guild.id, "anti_link");
        if (!config.enabled) return;

        if (LINK_REGEX.test(message.content)) {
            try { await message.delete(); } catch {}

            if (registerHit(message.guild.id, message.author.id, "anti_link", config.window, config.threshold)) {
                await punish(client, message.guild, message.author.id, "anti_link", config, `Lien détecté dans #${message.channel.name}`);
            }
        }
    }
};
