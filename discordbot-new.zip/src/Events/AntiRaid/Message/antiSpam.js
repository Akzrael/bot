const { getVectorConfig, registerHit, punish } = require("../../../Structure/AntiNuke.js");

const recentMessages = new Map();

module.exports = {
    name: "messageCreate",
    async execute(client, message) {
        if (!message.guild || message.author.bot) return;
        if (message.member?.permissions.has("Administrator")) return;

        const config = await getVectorConfig(message.guild.id, "anti_spam");
        if (!config.enabled) return;

        const key = `${message.guild.id}-${message.author.id}`;
        const now = Date.now();
        const windowMs = config.window * 1000;

        if (!recentMessages.has(key)) recentMessages.set(key, []);
        const msgs = recentMessages.get(key).filter(t => now - t < windowMs);
        msgs.push(now);
        recentMessages.set(key, msgs);

        if (msgs.length >= config.threshold) {
            try {
                await message.delete();
            } catch {}

            if (registerHit(message.guild.id, message.author.id, "anti_spam", config.window, config.threshold)) {
                await punish(client, message.guild, message.author.id, "anti_spam", config, `${msgs.length} messages en ${config.window}s dans #${message.channel.name}`);
            }
        }
    }
};