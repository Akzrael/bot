const { getVectorConfig, registerHit, punish } = require("../../../Structure/AntiNuke.js");

module.exports = {
    name: "messageCreate",
    async execute(client, message) {
        if (!message.guild || message.author.bot) return;
        if (message.member?.permissions.has("Administrator")) return;

        const config = await getVectorConfig(message.guild.id, "anti_mention");
        if (!config.enabled) return;

        const mentionCount = message.mentions.users.size + message.mentions.roles.size;
        if (mentionCount >= config.threshold) {
            try { await message.delete(); } catch {}

            if (registerHit(message.guild.id, message.author.id, "anti_mention", config.window, config.threshold)) {
                await punish(client, message.guild, message.author.id, "anti_mention", config, `${mentionCount} mentions dans #${message.channel.name}`);
            }
        }
    }
};
