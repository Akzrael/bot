const { getVectorConfig, registerHit, punish } = require("../../../Structure/AntiNuke.js");

module.exports = {
    name: "messageCreate",
    async execute(client, message) {
        if (!message.guild || message.author.bot) return;
        if (message.member?.permissions.has("Administrator")) return;

        const config = await getVectorConfig(message.guild.id, "anti_everyone");
        if (!config.enabled) return;

        if (message.mentions.everyone || message.mentions.here) {
            try { await message.delete(); } catch {}

            if (registerHit(message.guild.id, message.author.id, "anti_everyone", config.window, config.threshold)) {
                await punish(client, message.guild, message.author.id, "anti_everyone", config, `@everyone/@here dans #${message.channel.name}`);
            }
        }
    }
};