const { getVectorConfig, registerHit, punish } = require("../../../Structure/AntiNuke.js");

// No 'g' flag — see antiLink.js for why: a shared regex with 'g' used via
// .test() leaks lastIndex state across messages and causes intermittent
// false-negatives.
const INVITE_REGEX = /(discord\.gg\/|discordapp\.com\/invite\/|discord\.com\/invite\/)[a-zA-Z0-9]+/i;

module.exports = {
    name: "messageCreate",
    async execute(client, message) {
        if (!message.guild || message.author.bot) return;
        if (message.member?.permissions.has("Administrator")) return;

        const config = await getVectorConfig(message.guild.id, "anti_invite");
        if (!config.enabled) return;

        if (INVITE_REGEX.test(message.content)) {
            try { await message.delete(); } catch {}

            if (registerHit(message.guild.id, message.author.id, "anti_invite", config.window, config.threshold)) {
                await punish(client, message.guild, message.author.id, "anti_invite", config, `Invitation détectée dans #${message.channel.name}`);
            }
        }
    }
};
