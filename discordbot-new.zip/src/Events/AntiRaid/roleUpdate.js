const { AuditLogEvent } = require("discord.js");
const { getVectorConfig, findExecutor, registerHit, punish } = require("../../Structure/AntiNuke.js");

module.exports = {
    name: "roleUpdate",
    async execute(client, oldRole, newRole) {
        const config = await getVectorConfig(newRole.guild.id, "role_update");
        if (!config.enabled) return;

        const executorId = await findExecutor(newRole.guild, AuditLogEvent.RoleUpdate, newRole.id);
        if (!executorId) return;
        if (executorId === client.user.id) return;

        const member = newRole.guild.members.cache.get(executorId);
        if (member?.permissions.has("Administrator")) return;

        if (registerHit(newRole.guild.id, executorId, "role_update", config.window, config.threshold)) {
            await punish(client, newRole.guild, executorId, "role_update", config, `Rôle: ${newRole.name}`);
        }
    }
};