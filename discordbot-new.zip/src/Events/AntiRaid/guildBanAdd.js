const { AuditLogEvent } = require("discord.js");
const { getVectorConfig, findExecutor, registerHit, punish } = require("../../Structure/AntiNuke.js");

module.exports = {
    name: "guildBanAdd",
    async execute(client, ban) {
        const config = await getVectorConfig(ban.guild.id, "mass_ban");
        if (!config.enabled) return;

        const executorId = await findExecutor(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
        if (!executorId) return;
        if (executorId === client.user.id) return;

        const member = ban.guild.members.cache.get(executorId);
        if (member?.permissions.has("Administrator")) return;

        if (registerHit(ban.guild.id, executorId, "mass_ban", config.window, config.threshold)) {
            await punish(client, ban.guild, executorId, "mass_ban", config, `Banni: ${ban.user.tag}`);
        }
    }
};