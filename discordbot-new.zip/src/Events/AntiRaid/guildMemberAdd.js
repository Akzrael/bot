const { AuditLogEvent } = require("discord.js");
const { getVectorConfig, findExecutor, registerHit, punish } = require("../../Structure/AntiNuke.js");

module.exports = {
    name: "guildMemberAdd",
    async execute(client, member) {
        if (!member.user.bot) return;

        const config = await getVectorConfig(member.guild.id, "bot_add");
        if (!config.enabled) return;

        const executorId = await findExecutor(member.guild, AuditLogEvent.BotAdd, member.id);
        if (!executorId) return;
        if (executorId === client.user.id) return;

        const executor = member.guild.members.cache.get(executorId);
        if (executor?.permissions.has("Administrator")) return;

        if (registerHit(member.guild.id, executorId, "bot_add", config.window, config.threshold)) {
            await punish(client, member.guild, executorId, "bot_add", config, `Bot ajouté: ${member.user.tag}`);
        }
    }
};
