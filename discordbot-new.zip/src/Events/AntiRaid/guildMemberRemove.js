const { AuditLogEvent } = require("discord.js");
const { getVectorConfig, findExecutor, registerHit, punish } = require("../../Structure/AntiNuke.js");

module.exports = {
    name: "guildMemberRemove",
    async execute(client, member) {
        const config = await getVectorConfig(member.guild.id, "mass_kick");
        if (!config.enabled) return;

        const executorId = await findExecutor(member.guild, AuditLogEvent.MemberKick, member.id);
        if (!executorId) return;
        if (executorId === client.user.id) return;

        const executor = member.guild.members.cache.get(executorId);
        if (executor?.permissions.has("Administrator")) return;

        if (registerHit(member.guild.id, executorId, "mass_kick", config.window, config.threshold)) {
            await punish(client, member.guild, executorId, "mass_kick", config, `Expulsé: ${member.user.tag}`);
        }
    }
};