const { AuditLogEvent } = require("discord.js");
const { getVectorConfig, findExecutor, registerHit, punish } = require("../../Structure/AntiNuke.js");

module.exports = {
    name: "channelDelete",
    async execute(client, channel) {
        if (!channel.guild) return;
        if (channel.type === 4) return;

        const config = await getVectorConfig(channel.guild.id, "channel_delete");
        if (!config.enabled) return;

        const executorId = await findExecutor(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
        if (!executorId) return;
        if (executorId === client.user.id) return;

        const member = channel.guild.members.cache.get(executorId);
        if (member?.permissions.has("Administrator")) return;

        if (registerHit(channel.guild.id, executorId, "channel_delete", config.window, config.threshold)) {
            await punish(client, channel.guild, executorId, "channel_delete", config, `Salon: ${channel.name}`);
        }
    }
};