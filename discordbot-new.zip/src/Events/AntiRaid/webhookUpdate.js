const { AuditLogEvent } = require("discord.js");
const { getVectorConfig, findExecutor, registerHit, punish } = require("../../Structure/AntiNuke.js");

module.exports = {
    name: "webhookUpdate",
    // discord.js v14 passes the TextChannel/NewsChannel whose webhooks changed,
    // not a Webhook instance — there is no direct reference to the webhook itself.
    async execute(client, channel) {
        const config = await getVectorConfig(channel.guild.id, "webhook_update");
        if (!config.enabled) return;

        // The attack this vector needs to catch is mass webhook *creation* (spam),
        // which is AuditLogEvent.WebhookCreate — WebhookUpdate only fires for edits
        // to an existing webhook's settings and would never see a creation raid.
        // We don't have the created webhook's id from the channel param, so we
        // don't restrict by targetId — findExecutor already falls back to matching
        // the most recent entry within its time window.
        const executorId = await findExecutor(channel.guild, AuditLogEvent.WebhookCreate, null);
        if (!executorId) return;
        if (executorId === client.user.id) return;

        const member = channel.guild.members.cache.get(executorId);
        if (member?.permissions.has("Administrator")) return;

        if (registerHit(channel.guild.id, executorId, "webhook_update", config.window, config.threshold)) {
            await punish(client, channel.guild, executorId, "webhook_update", config, `Salon: ${channel.name}`);
        }
    }
};
