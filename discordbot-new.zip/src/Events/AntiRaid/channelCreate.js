const { AuditLogEvent } = require("discord.js");
const { getVectorConfig, findExecutor, registerHit, punish } = require("../../Structure/AntiNuke.js");

module.exports = {
    name: "channelCreate",
    async execute(client, channel) {
        if (!channel.guild) return;
        if (channel.type === 4) return; // Category created separately

        const config = await getVectorConfig(channel.guild.id, "channel_create");
        if (!config.enabled) return;

        const executorId = await findExecutor(channel.guild, AuditLogEvent.ChannelCreate, channel.id);
        if (!executorId) return;
        if (executorId === client.user.id) return;

        const member = channel.guild.members.cache.get(executorId);
        if (member?.permissions.has("Administrator")) return;

        if (registerHit(channel.guild.id, executorId, "channel_create", config.window, config.threshold)) {
            await punish(client, channel.guild, executorId, "channel_create", config, `Salon: ${channel.name}`);
        }
    }
};