const { AuditLogEvent } = require("discord.js");
const { getVectorConfig, findExecutor, registerHit, punish } = require("../../Structure/AntiNuke.js");

module.exports = {
    name: "roleDelete",
    async execute(client, role) {
        const config = await getVectorConfig(role.guild.id, "role_delete");
        if (!config.enabled) return;

        const executorId = await findExecutor(role.guild, AuditLogEvent.RoleDelete, role.id);
        if (!executorId) return;
        if (executorId === client.user.id) return;

        const member = role.guild.members.cache.get(executorId);
        if (member?.permissions.has("Administrator")) return;

        if (registerHit(role.guild.id, executorId, "role_delete", config.window, config.threshold)) {
            await punish(client, role.guild, executorId, "role_delete", config, `Rôle: ${role.name}`);
        }
    }
};