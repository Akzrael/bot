const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require("discord.js");
const db = require("../../../index.js"); // quick.db instance — used only for per-user cooldown timestamps

module.exports = {
    name: "messageCreate",
    async execute(client, message) {
        if (!message.guild || message.author.bot) return;

        const guildConfig = client.db(message.guild.id);
        if (!guildConfig.confess || !guildConfig.confess.enabled) return;
        if (!guildConfig.confess.channel) return;
        if (message.channel.id !== guildConfig.confess.channel) return;

        // Confessions are submitted through the 📥 Confesser button's modal
        // now, not by typing in this channel — typing here would show your
        // name and message right in the channel, which is exactly what
        // broke anonymity before (and made the cooldown reply fire on
        // completely unrelated chat like "je me goon"). Clean it up and
        // redirect instead of treating it as a confession.
        await message.delete().catch(() => {});

        // The redirect message carries its own button (rather than just
        // pointing at "the" button) — if the panel was never posted, or has
        // scrolled out of view, there needs to be something actually
        // clickable right here, not just a name-drop of a button that might
        // not exist anywhere visible.
        const notice = await message.channel.send({
            content: `${message.author}, utilise le bouton ci-dessous pour envoyer une confession anonyme.`,
            components: [confessRow()]
        }).catch(() => null);
        if (notice) setTimeout(() => notice.delete().catch(() => {}), 15000);
    }
};

function confessRow() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("confess_open")
            .setLabel("Confesser")
            .setEmoji("📥")
            .setStyle(ButtonStyle.Secondary)
    );
}
module.exports.confessRow = confessRow;

async function publishConfession(client, guild, guildConfig, authorId, content) {
    const publicChannel = guild.channels.cache.get(guildConfig.confess.channel);
    if (!publicChannel) return null;

    const embed = new EmbedBuilder()
        .setTitle("🤐 Confession anonyme")
        .setDescription(content)
        .setColor(0x5865F2)
        .setTimestamp();

    // The 📥 button goes on every published confession, not just the panel
    // message — so there's always a fresh entry point to confess again,
    // instead of everyone having to scroll back to one static message.
    const sent = await publicChannel.send({ embeds: [embed], components: [confessRow()] });

    if (guildConfig.confess.dmChannel) {
        const dmChannel = guild.channels.cache.get(guildConfig.confess.dmChannel);
        if (dmChannel) {
            const author = await guild.members.fetch(authorId).catch(() => null);
            const logEmbed = new EmbedBuilder()
                .setTitle("📥 Confession reçue")
                .setDescription(content)
                .addFields({ name: "Auteur", value: author ? `${author.user.tag} (\`${authorId}\`)` : `\`${authorId}\``, inline: true })
                .setColor(0x5865F2)
                .setTimestamp();
            await dmChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
    }

    return sent;
}
module.exports.publishConfession = publishConfession;

module.exports.handleInteraction = async (client, interaction) => {
    // The 📥 Confesser button — posted on the panel, on every published
    // confession, and on the stray-message redirect notice. Opens the
    // modal so the submission never appears as a visible channel message.
    if (interaction.isButton() && interaction.customId === "confess_open") {
        const guildConfig = client.db(interaction.guild.id);
        if (!guildConfig.confess || !guildConfig.confess.enabled) {
            return interaction.reply({ content: "❌ Les confessions sont désactivées.", flags: 64 });
        }

        // Checked before the modal opens so people aren't asked to write a
        // whole confession just to be told to wait afterwards.
        const cooldownKey = `confess_${interaction.guild.id}_${interaction.user.id}`;
        const cooldownMs = (guildConfig.confess.cooldown || 3600) * 1000;
        const lastConfess = await db.get(cooldownKey) || 0;
        if (Date.now() - lastConfess < cooldownMs) {
            const remaining = Math.ceil((lastConfess + cooldownMs - Date.now()) / 1000);
            return interaction.reply({ content: `⏳ Attendez ${remaining}s avant la prochaine confession.`, flags: 64 });
        }

        // Stamped immediately, not after the modal is submitted. The
        // "Confesser" button appears on the panel AND on every published
        // confession, so without this a user could click several of those
        // buttons back-to-back — each click would pass the cooldown check
        // above since none of the earlier clicks had written a timestamp
        // yet — then submit all the modals afterwards and post multiple
        // confessions inside what should have been a single cooldown
        // window. Stamping here closes that race. Cancelled/blocked/failed
        // attempts refund it below so people aren't penalized for a
        // confession that never actually got posted.
        await db.set(cooldownKey, Date.now());

        const modal = new ModalBuilder()
            .setCustomId("confess_modal")
            .setTitle("Confession anonyme")
            .addComponents(new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("content")
                    .setLabel("Votre confession")
                    .setStyle(TextInputStyle.Paragraph)
                    .setMaxLength(2000)
                    .setRequired(true)
            ));
        await interaction.showModal(modal);

        // This button lives on standalone messages (panel / each confession
        // embed / redirect notice) routed here by index.js's global
        // interactionCreate listener — there's no per-command collector
        // watching it, so (same as the setrules/setconfess admin panel
        // modals) the submission has to be awaited right here or nothing
        // will ever catch it.
        const submitted = await interaction.awaitModalSubmit({
            time: 300000,
            filter: i => i.customId === "confess_modal" && i.user.id === interaction.user.id
        }).catch(() => null);
        if (!submitted) {
            // They never actually submitted anything — refund the cooldown
            // stamp so the timed-out/cancelled attempt doesn't cost them
            // their next real confession.
            await db.set(cooldownKey, lastConfess);
            return;
        }

        const content = submitted.fields.getTextInputValue("content");

        for (const word of guildConfig.confess.blockedWords || []) {
            if (content.toLowerCase().includes(word.toLowerCase())) {
                await db.set(cooldownKey, lastConfess);
                return submitted.reply({ content: "❌ Ce message contient un mot interdit.", flags: 64 });
            }
        }

        if (guildConfig.confess.requireApproval && guildConfig.confess.approvalChannel) {
            const approvalChannel = interaction.guild.channels.cache.get(guildConfig.confess.approvalChannel);
            if (!approvalChannel) {
                await db.set(cooldownKey, lastConfess);
                return submitted.reply({ content: "❌ Salon de validation introuvable.", flags: 64 });
            }

            // Pending confessions are stored keyed by a generated id rather
            // than a real message id, since a modal submission has no
            // origin channel message to fetch back later the way the old
            // typed-message flow did.
            if (!guildConfig.confess.pending) guildConfig.confess.pending = {};
            const pendingId = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
            guildConfig.confess.pending[pendingId] = { content, authorId: interaction.user.id };
            client.saveDB();

            const embed = new EmbedBuilder()
                .setTitle("🤐 Nouvelle confession (en attente)")
                .setDescription(content)
                .setColor(0xFAA61A)
                .setFooter({ text: `Auteur: ${interaction.user.id}` })
                .setTimestamp();

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`confess_approve_${pendingId}`).setLabel("✅ Approuver").setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId(`confess_reject_${pendingId}`).setLabel("❌ Rejeter").setStyle(ButtonStyle.Danger)
            );

            await approvalChannel.send({ embeds: [embed], components: [row] });
            await submitted.reply({ content: "📨 Confession envoyée pour validation.", flags: 64 });
        } else {
            await publishConfession(client, interaction.guild, guildConfig, interaction.user.id, content);
            await submitted.reply({ content: "✅ Confession publiée anonymement.", flags: 64 });
        }

        return;
    }

    if (!interaction.isButton()) return;
    if (!interaction.customId.startsWith("confess_approve_") && !interaction.customId.startsWith("confess_reject_")) return;

    if (!interaction.member.permissions.has("ManageMessages")) {
        return interaction.reply({ content: "❌ Permission insuffisante.", flags: 64 });
    }

    const isApprove = interaction.customId.startsWith("confess_approve_");
    const pendingId = interaction.customId.replace(isApprove ? "confess_approve_" : "confess_reject_", "");

    const guildConfig = client.db(interaction.guild.id);
    const pending = guildConfig.confess && guildConfig.confess.pending && guildConfig.confess.pending[pendingId];
    if (!pending) {
        return interaction.update({ content: "❌ Confession introuvable ou déjà traitée.", components: [], embeds: [] }).catch(() => {});
    }

    delete guildConfig.confess.pending[pendingId];
    client.saveDB();

    if (isApprove) {
        await publishConfession(client, interaction.guild, guildConfig, pending.authorId, pending.content);
        await interaction.update({ content: "✅ Confession approuvée et publiée.", components: [], embeds: [] });
    } else {
        await interaction.update({ content: "❌ Confession rejetée.", components: [], embeds: [] });
    }
};
