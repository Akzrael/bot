const { EmbedBuilder } = require("discord.js");
const db = require("../../index.js");

/**
 * Sends an embed to the guild's configured mod-log channel, if one is set.
 * Safe no-op if not configured or if the send fails (missing perms, deleted channel, etc).
 */
async function sendModLog(client, guild, { title, description, color, fields, footer }) {
    try {
        const channelId = await db.get(`modlog_${guild.id}`);
        if (!channelId) return;

        const channel = guild.channels.cache.get(channelId);
        if (!channel || !channel.isTextBased()) return;

        const embed = new EmbedBuilder()
            .setColor(color || 0x5865F2)
            .setTimestamp();

        if (title) embed.setTitle(title);
        if (description) embed.setDescription(description);
        if (fields) embed.addFields(fields);
        if (footer !== false) {
            embed.setFooter({ text: client.footer || guild.name, iconURL: client.user.displayAvatarURL() });
        }

        await channel.send({ embeds: [embed] }).catch(() => {});
    } catch (error) {
        console.error("[MODLOG ERROR]", error);
    }
}

module.exports = { sendModLog };
