const { AuditLogEvent } = require("discord.js");
const db = require("../../index.js");
const { sendModLog } = require("./ModLog.js");

const VECTORS = {
    join_rate: { event: "guildMemberAdd", threshold: 5, window: 10, action: "strip" },
    channel_create: { event: "channelCreate", threshold: 3, window: 10, action: "ban" },
    channel_delete: { event: "channelDelete", threshold: 3, window: 10, action: "ban" },
    role_create: { event: "roleCreate", threshold: 3, window: 10, action: "ban" },
    role_delete: { event: "roleDelete", threshold: 3, window: 10, action: "ban" },
    role_update: { event: "roleUpdate", threshold: 5, window: 10, action: "strip" },
    webhook_update: { event: "webhookUpdate", threshold: 3, window: 10, action: "ban" },
    mass_ban: { event: "guildBanAdd", threshold: 3, window: 10, action: "ban" },
    mass_kick: { event: "guildMemberRemove", threshold: 3, window: 10, action: "ban" },
    anti_invite: { event: "messageCreate", threshold: 2, window: 10, action: "ban" },
    anti_link: { event: "messageCreate", threshold: 3, window: 10, action: "strip" },
    anti_everyone: { event: "messageCreate", threshold: 2, window: 10, action: "strip" },
    anti_mention: { event: "messageCreate", threshold: 5, window: 10, action: "strip" },
    anti_spam: { event: "messageCreate", threshold: 5, window: 10, action: "strip" },
    bot_add: { event: "guildMemberAdd", threshold: 3, window: 30, action: "ban" },
};

const DEFAULT_VECTOR_CONFIG = {
    enabled: false,
    threshold: 3,
    window: 10,
    action: "ban"
};

const hits = new Map();

async function getVectorConfig(guildId, vector) {
    const config = await db.get(`antiraid_${guildId}`) || {};
    const protections = config.protections || {};
    const defaults = VECTORS[vector] || {};
    return { ...DEFAULT_VECTOR_CONFIG, ...defaults, ...(protections[vector] || {}) };
}

async function findExecutor(guild, auditLogEvent, targetId) {
    try {
        if (!guild.members.me.permissions.has("ViewAuditLog")) return null;

        const eventType = auditLogEvent === 0 ? null : auditLogEvent;
        const logs = await guild.fetchAuditLogs({ type: eventType, limit: 5 });
        const entry = logs.entries.find(e =>
            (!targetId || e.target?.id === targetId) &&
            (Date.now() - e.createdTimestamp) < 10000
        );

        return entry ? entry.executor?.id : null;
    } catch (error) {
        console.error("[ANTINUKE] Impossible de lire les audit logs :", error.message);
        return null;
    }
}

function registerHit(guildId, executorId, vector, windowSeconds, threshold) {
    if (!hits.has(guildId)) hits.set(guildId, new Map());
    const guildHits = hits.get(guildId);

    if (!guildHits.has(executorId)) guildHits.set(executorId, new Map());
    const userHits = guildHits.get(executorId);

    const now = Date.now();
    const windowMs = windowSeconds * 1000;

    let timestamps = (userHits.get(vector) || []).filter(t => now - t < windowMs);
    timestamps.push(now);
    userHits.set(vector, timestamps);

    return timestamps.length >= threshold;
}

function clearHits(guildId, executorId, vector) {
    hits.get(guildId)?.get(executorId)?.set(vector, []);
}

async function punish(client, guild, executorId, vector, config, extra = "") {
    const member = guild.members.cache.get(executorId)
        || await guild.members.fetch(executorId).catch(() => null);

    const reason = `AntiNuke: seuil dépassé sur ${vector} (${config.threshold} actions en ${config.window}s)${extra ? " — " + extra : ""}`;

    let actionTaken = "aucune (membre introuvable ou non gérable)";

    if (member) {
        try {
            if (config.action === "ban" && member.bannable) {
                await member.ban({ reason });
                actionTaken = "🔨 Banni";
            } else if (config.action === "kick" && member.kickable) {
                await member.kick(reason);
                actionTaken = "👢 Expulsé";
            } else if (config.action === "strip" && member.manageable) {
                const roles = member.roles.cache.filter(r => r.id !== guild.id && r.editable);
                await member.roles.remove(roles, reason);
                actionTaken = "🧹 Rôles retirés";
            } else if (member.manageable) {
                const roles = member.roles.cache.filter(r => r.id !== guild.id && r.editable);
                await member.roles.remove(roles, reason);
                actionTaken = "🧹 Rôles retirés (action configurée impossible)";
            }
        } catch (error) {
            console.error(`[ANTINUKE] Échec de la sanction pour ${executorId}:`, error.message);
            actionTaken = `échec (${error.message})`;
        }
    }

    await sendModLog(client, guild, {
        title: "🛡️ AntiNuke déclenché",
        color: 0xED4245,
        description: `Activité suspecte détectée : **${vector}**`,
        fields: [
            { name: "Utilisateur", value: `<@${executorId}> (\`${executorId}\`)`, inline: true },
            { name: "Vecteur", value: vector, inline: true },
            { name: "Action", value: actionTaken, inline: true },
        ],
    });
}

function getAllVectors() {
    return Object.keys(VECTORS);
}

module.exports = { getVectorConfig, findExecutor, registerHit, clearHits, punish, DEFAULT_VECTOR_CONFIG, VECTORS, getAllVectors };