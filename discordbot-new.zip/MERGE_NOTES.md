# Merge notes — modmail + giveaways ported into corbeau

Ported the two features shibuya_uhq had that corbeau didn't, from
`bot-modmail` and `bot-giveaway`. Everything else about corbeau
(moderation, autorole, greet, snipe, fun commands, perm tiers) is
untouched. This was an actual code port — I converted each file's
export style to match corbeau's convention, ran `node --check` on
every file, and load-tested each new command/event against a mocked
Discord client to confirm they execute without throwing (couldn't
fully `npm install` in this environment since `better-sqlite3`
needs a native compile step this sandbox can't reach — that's a
pre-existing corbeau dependency, unrelated to the merge. It'll build
fine on your machine).

## What was added

**Giveaways** (`src/Commands/Perm 2/`):
- `giveaway.js` — interactive panel to configure and launch a giveaway
- `gend.js`, `glist.js`, `gpause.js`, `greroll.js`, `gunpause.js` — end/list/pause/reroll/unpause
  (renamed with a `g` prefix so they don't collide with any existing corbeau command names)

**Modmail** (`src/Commands/Perm 4/modmail.js` + `src/Events/Modmail/`):
- `+modmail` — opens a config panel (enable/disable, AFK auto-close, claim system,
  transcripts, staff roles, categories/options)
- `+modmail block @user` / `+modmail unblock @user` — merged in from the original's
  slash-only subcommands, since corbeau doesn't do slash commands
- `messageCreate.js` / `interactionCreate.js` in `src/Events/Modmail/` handle the
  actual DM-relay-to-channel-thread logic and all the buttons/modals

## Two real bugs fixed during the port (not just style changes)

1. **`giveaway.js` called `client.ms(...)` to parse durations like `"12h"` into
   milliseconds — but `client.ms` was never defined anywhere in the original
   shibuya code.** Setting a giveaway's duration would have thrown
   `client.ms is not a function` the moment anyone used it. Fixed by adding the
   real `ms` npm package and calling it directly instead of through `client`.
2. **The `edit()` helper in `giveaway.js` called `client.db(message.guildId)`
   and never used the result** — dead code left over from a copy-paste, and it
   would've thrown too since `bot-giveaway` never defined `client.db` either.
   Removed.

## Plumbing changes in `index.js`

- Added `Partials: [Channel, Message, User, GuildMember, Reaction]` to the
  Discord client — required for DMs (modmail) to work reliably with users who
  aren't already cached.
- Added a small fs-based `modmail-db.json` store (`client.db(guildId)` /
  `client.saveDB()`), separate from corbeau's existing `quick.db` usage — this
  is exactly how the original modmail bot stored its config, so it was ported
  as-is rather than force-migrated to quick.db.
- Instantiated `client.giveawaysManager` from `discord-giveaways` (it persists
  its own `giveaways.json` automatically).

## New dependencies added to `package.json`

- `discord-giveaways` — the giveaway engine
- `ms` — duration string parsing (`"12h"` → milliseconds), fixing bug #1 above

## Perm tiers used

- Giveaway commands: **Perm 2** (Moderator) — matches corbeau's existing
  ban/kick/mute tier, and matches the `ManageMessages`-level permission the
  original slash commands required.
- `modmail` config command: **Perm 4** (Whitelist) — matches the
  Administrator-level permission the original required.

Run `npm install` before starting — the new dependencies need to be pulled in.

## Role sync for perms/whitelist (added after initial merge)

`+perms add/remove` and `+whitelist add/remove` previously only updated the
bot's internal permission list — no visible Discord role, no real Discord
permissions, nothing showing on the member. Fixed with **auto-created roles**:

- The first time `+perms add 2 @user` is run on a server, the bot creates a
  `Modérateur` role itself (blue, with Kick Members / Moderate Members /
  Manage Messages / View Audit Log) and assigns it immediately. `+perms add 3`
  does the same for an `Admin` role (red, with Kick/Ban/Moderate/Manage
  Messages/Manage Roles/Manage Channels/View Audit Log). `+whitelist add`
  does the same for a grey `Whitelist` role (no extra permissions, just a
  visible marker).
- Every subsequent `add` for that tier reuses the same role — it only gets
  created once per server, and every user for that tier ends up on the same
  role (tested: two different users added to tier 2 both land on the same
  single auto-created role, not two separate ones).
- `remove` takes the role back off the user (bot list + Discord role, both).
- If you'd rather use a role you make yourself instead of the auto-created
  one, `+perms setrole <2/3> @role` / `+whitelist setrole @role` is still
  there as a manual override — point it at your own role once, and future
  `add`s use that instead of creating a new one.
- The `+perms` panel embed shows which role (if any) is currently linked to
  each tier.

## Silent command failures fixed

Three bugs in the original `CommandHandler/messageCreate.js` (pre-existing
in corbeau, not introduced by the merge) meant a lot of commands would
appear completely broken — no reply, no console output, nothing:

1. **Every permission check did a bare `return` on denial.** If you weren't
   the server owner, whitelisted, or added via `+perms add`, the command
   just vanished with zero feedback. This is almost certainly what you were
   hitting with `+renew` — it's Perm 3. Now it replies telling you exactly
   which permission tier you're missing.
2. **The Perm 6 (bot owner) check referenced `client.config.owner`**
   (singular) — but the config only defines `owners` (plural array), so this
   was `undefined.includes(...)`, which throws. Fixed to `client.config.owners`.
3. **The Perm 1 check referenced an undefined `data.perms3`** (should've been
   `perms.perms3`) — also throws if a server ever enables "private mode" via
   `setpublic`. Fixed.
4. **Bonus:** `commandFile.run(...)` was called with no error handling at
   all — if a command threw, it became a silent unhandled promise rejection
   with no user-facing feedback. Now errors are caught, logged to console
   with the command name, and the user gets an error reply instead of dead
   silence.

Tested all three scenarios (unauthorized user, authorized owner, a command
that throws) against a mocked client — confirmed correct behavior in each case.
