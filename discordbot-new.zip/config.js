require('dotenv').config();

module.exports = {
    clients: {
        token: process.env.BOT_TOKEN,
        owners: process.env.OWNER_IDS
            ? process.env.OWNER_IDS.split(",").map(id => id.trim())
            : []
    }
}
