require('./src/Structure/AntiNuke.js');
console.log('OK');